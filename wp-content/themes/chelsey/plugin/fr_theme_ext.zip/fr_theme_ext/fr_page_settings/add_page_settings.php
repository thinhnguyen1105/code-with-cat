<?php

add_action("admin_init", "concept_blog_meta");
function concept_blog_meta(){
	add_meta_box('concept_blog_page_settings', esc_html__('Page Setup', 'chelsey' ), 'concept_blog_settings', 'page', 'side');
}


add_action( 'save_post', 'concept_blog_save_post_data', 10, 2 );
function concept_blog_save_post_data( $concept_blog_post_id, $post ){
	global $pagenow, $concept_blog_post_bgcolor;

	if ( 'post.php' != $pagenow ) return $concept_blog_post_id;

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
		return $concept_blog_post_id;

	$post_type = get_post_type_object( $post->post_type );
	if ( ! current_user_can( $post_type->cap->edit_post, $concept_blog_post_id ) )
		return $concept_blog_post_id;

	if ( !isset( $_POST['concept_blog_settings_nonce'] ) || ! wp_verify_nonce( $_POST['concept_blog_settings_nonce'], basename( __FILE__ ) ) )
        return $concept_blog_post_id;

	if ( in_array( $_POST['post_type'], array( 'post', 'page' ) ) ) {
		if ( isset( $_POST['concept_blog_post_bgcolor'] ) )
			update_post_meta( $concept_blog_post_id, 'concept_blog_post_bgcolor', sanitize_text_field( $_POST['concept_blog_post_bgcolor'] ) );
		else
			delete_post_meta( $concept_blog_post_id, '_concept_blog_post_bgcolor' );

	} 
}

if ( ! function_exists( 'concept_blog_settings' ) ){
	function concept_blog_settings($callback_args) {
		global $post;
		$temp_array = array();

		$temp_array = maybe_unserialize(get_post_meta($post->ID,'chelsey_page_setup',true));
		
		$chelsey_fullwidth_page = isset( $temp_array['chelsey_fullwidth_page'] ) ? (bool) $temp_array['chelsey_fullwidth_page'] : false;
		$concept_blog_columns_count = isset( $temp_array['concept_blog_columns_count'] ) ? (int) $temp_array['concept_blog_columns_count'] : 1;
		
		$chelsey_categories = isset( $temp_array['chelsey_categories'] ) ? (array) $temp_array['chelsey_categories'] : array();
		$chelsey_posts_num = isset( $temp_array['chelsey_posts_num'] ) ? (int) $temp_array['chelsey_posts_num'] : 5;		
		?>
		
		<?php wp_nonce_field( 'concept_blog_page_nonce', '_wpnonce_save' ); ?>
		
		<!-- Blog Settings -->	
		<div style="margin: 10px 0 10px 5px; display: none;" class="blog_page blog_color_page portfolio contact_page">
			<label class="selectit" for="chelsey_fullwidth_page">
				<input type="checkbox" name="chelsey_fullwidth_page" id="chelsey_fullwidth_page" value=""<?php checked( $chelsey_fullwidth_page ); ?> /> <?php esc_html_e( 'Set the fullwidth page', 'chelsey' ); ?></label><br/>
		</div>
		
		<div style="margin: 13px 0 11px 4px; display: none;" class="blog_page left_menu_page masonry_page block_layout">
			<label for="chelsey_posts_num" style="font-weight: bold;"> <?php esc_html_e('Number of posts per page', 'chelsey' ) ; ?> </label>
			<input type="text" class="small-text" value="<?php echo esc_attr( $chelsey_posts_num ); ?>" id="chelsey_posts_num" name="chelsey_posts_num" size="2" />
		</div>
		
		<div style="margin: 10px 0 10px 5px; display: none;" class="blog_page left_menu_page masonry_page block_layout">
			<h4><?php esc_html_e('Choose a blog categories', 'chelsey' ); ?></h4>
			<?php $categories_array = get_categories('hide_empty=0');
			$site_cats = array();
			foreach ($categories_array as $categs) {
				$checked = '';
				
				if (!empty($chelsey_categories)) {
					if (in_array($categs->cat_ID, $chelsey_categories)) $checked = "checked=\"checked\"";
				} ?>
				
				<label style="padding-bottom: 5px; display: block;" for="<?php echo esc_attr( 'chelsey_categories-' . $categs->cat_ID ); ?>">
					<input type="checkbox" name="chelsey_categories[]" id="<?php echo esc_attr( 'chelsey_categories-' . $categs->cat_ID ); ?>" value="<?php echo esc_attr($categs->cat_ID); ?>" <?php echo esc_attr( $checked ); ?> />
					<?php echo esc_html( $categs->cat_name ); ?>
				</label>							
			<?php } ?>
		</div>
		<!-- Blog Settings -->
<?php }
}

add_action( 'save_post', 'concept_blog_save_data', 10, 2 );
function concept_blog_save_data( $concept_blog_post_id, $post ){
	global $pagenow;
	if ( 'post.php' != $pagenow ) return $concept_blog_post_id;

	if ( 'page' != $post->post_type )
		return $concept_blog_post_id;
			
	if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) 
		return $concept_blog_post_id;
		
	if ( 'page' == $_POST['post_type'] ) {  
		if ( !current_user_can( 'edit_page', $concept_blog_post_id ) )  
		  return $concept_blog_post_id;  
	  } else {  
		if ( !current_user_can( 'edit_post', $concept_blog_post_id ) )  
		  return $concept_blog_post_id;  
	  } 
	
	if ( ! isset( $_POST['_wpnonce_save'] ) || ! wp_verify_nonce( $_POST['_wpnonce_save'], 'concept_blog_page_nonce' ) )
        return $concept_blog_post_id;

	if ( !isset( $_POST["page_template"] ) )
		return $concept_blog_post_id;
		
	if ( !in_array( $_POST["page_template"], array('page-standart-layout.php', 'page-list-layout.php', 'page-masonry-layout.php', 'firs-post-grid-layout.php', 'page-block-layout.php', 'page-search.php', 'page-masonry-three-columns.php' ) ) )
		return $concept_blog_post_id;
		
	$temp_array = array();
	
	$temp_array['chelsey_fullwidth_page'] = isset( $_POST["chelsey_fullwidth_page"] ) ? 1 : 0;
	
	if ( 'page-standart-layout.php' == $_POST["page_template"] ) {
		if (isset($_POST["chelsey_categories"])) $temp_array['chelsey_categories'] = (array) $_POST["chelsey_categories"];
		if (isset($_POST["chelsey_posts_num"])) $temp_array['chelsey_posts_num'] = (int) $_POST["chelsey_posts_num"];
	}
	
	if ( 'page-list-layout.php' == $_POST["page_template"] ) {
		if (isset($_POST["chelsey_categories"])) $temp_array['chelsey_categories'] = (array) $_POST["chelsey_categories"];
		if (isset($_POST["chelsey_posts_num"])) $temp_array['chelsey_posts_num'] = (int) $_POST["chelsey_posts_num"];
	}
	
	if ( 'firs-post-grid-layout.php' == $_POST["page_template"] ) {
		if (isset($_POST["chelsey_categories"])) $temp_array['chelsey_categories'] = (array) $_POST["chelsey_categories"];
		if (isset($_POST["chelsey_posts_num"])) $temp_array['chelsey_posts_num'] = (int) $_POST["chelsey_posts_num"];
	}
	
	if ( 'page-masonry-layout.php' == $_POST["page_template"] ) {
		if (isset($_POST["chelsey_categories"])) $temp_array['chelsey_categories'] = (array) $_POST["chelsey_categories"];
		if (isset($_POST["chelsey_posts_num"])) $temp_array['chelsey_posts_num'] = (int) $_POST["chelsey_posts_num"];
	}
	
	if ( 'page-masonry-three-columns.php' == $_POST["page_template"] ) {
		if (isset($_POST["chelsey_categories"])) $temp_array['chelsey_categories'] = (array) $_POST["chelsey_categories"];
		if (isset($_POST["chelsey_posts_num"])) $temp_array['chelsey_posts_num'] = (int) $_POST["chelsey_posts_num"];
	}
	
	update_post_meta( $concept_blog_post_id, "chelsey_page_setup", $temp_array );
	
	}
?>