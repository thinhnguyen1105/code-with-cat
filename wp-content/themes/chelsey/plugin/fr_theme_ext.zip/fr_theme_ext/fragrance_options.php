<?php

require_once( 'fragrance_options/options_fragrance.php' );

require_once( 'fragrance_options/features.php' );

// ADMIN
function fragrance_admin_script() {
	
	wp_enqueue_script('jquery-ui-tabs');
	wp_enqueue_script('jquery-form');
	wp_register_script( 'fragrance_functions_init', plugins_url( 'fragrance_options/js/functions-init.js', __FILE__ ), array(), '201004', 'all' ); 
	wp_enqueue_script('fragrance_functions_init');
	wp_localize_script( 'fragrance_functions_init', 'controlPanelSettings', array(
		'clearpath' => plugins_url( 'fragrance_options/images/empty.png' ),
		'c_p_saving_message' => esc_html__( 'Saving...', 'frgn-extension' ),
		'c_p_options_saved_message' => esc_html__( 'Options Saved.', 'frgn-extension' ),
		'c_p_nonce' => wp_create_nonce('c_p_nonce')
	));
	wp_register_script( 'fragrance_colorpicker', plugins_url( 'fragrance_options/js/colorpicker.js', __FILE__ ), array(), '201005', 'all' );
	wp_enqueue_script('fragrance_colorpicker');
	wp_register_script( 'fragrance_eye', plugins_url( 'fragrance_options/js/eye.js', __FILE__ ), array(), '201006', 'all' );
	wp_enqueue_script('fragrance_eye');	
	wp_register_script( 'fragrance_image_uploader', plugins_url( 'fragrance_options/js/image_uploader.js', __FILE__ ), array(), '201007', 'all' );
	wp_enqueue_script('fragrance_image_uploader');	
}
	
add_action( 'admin_enqueue_scripts', 'fragrance_admin_script' );

function fragrance_admin_style() {
	wp_register_style( 'fragrance_wp_admin_css', plugins_url( 'fragrance_options/css/fragrance_options.css', __FILE__ ), array(), '20131003', 'all' ); 
	wp_enqueue_style( 'fragrance_wp_admin_css' );
}
add_action( 'admin_enqueue_scripts', 'fragrance_admin_style' );

function media_upload()  {
	wp_enqueue_script('image_upload', plugins_url( 'fragrance_options/js/image_uploader.js', __FILE__ ), array('jquery','media-upload','thickbox'));
}
add_action( 'admin_enqueue_scripts', 'media_upload' );

function media_upload_styles() {
	wp_enqueue_style('thickbox');
}
add_action( 'admin_enqueue_scripts', 'media_upload_styles' );	

/*** Bg functions ***/
add_action( 'wp_head', 'monni_set_sections_bg' );
function monni_set_sections_bg(){
	
	$frgn_header_bg_url = '';
	$frgn_HEADER_BG_COLOR = '';
	if ( get_option('monni_HEADER_BG_IMAGE') !== '' ) { $frgn_header_bg_url = get_option('monni_HEADER_BG_IMAGE'); }
	if ( get_option('monni_HEADER_BG_COLOR') !== '' ) { $frgn_HEADER_BG_COLOR = get_option('monni_HEADER_BG_COLOR'); }
	
	$frgn_classic_menu_color = '';
	if ( get_option('FRGN_CLASSIC_MENU_BG_COLOR') !== '' ) { $frgn_classic_menu_color = get_option('FRGN_CLASSIC_MENU_BG_COLOR'); }
	$frgn_classic_menu_color_link = '';
	if ( get_option('FRGN_CLASSIC_MENU_COLOR_LINKS') !== '' ) { $frgn_classic_menu_color_link = get_option('FRGN_CLASSIC_MENU_COLOR_LINKS'); }
	
	$frgn_menu_bg_url = '';
	if ( get_option('FRGN_MENU_BG_IMAGE') !== '' ) { $frgn_menu_bg_url = get_option('FRGN_MENU_BG_IMAGE'); }
	$frgn_left_menu_color = '';
	if ( get_option('FRGN_LEFT_MENU_COLOR') !== '' ) { $frgn_left_menu_color = get_option('FRGN_LEFT_MENU_COLOR'); }
	$frgn_left_menu_color_link = '';
	if ( get_option('FRGN_LEFT_MENU_COLOR_LINKS') !== '' ) { $frgn_left_menu_color_link = get_option('FRGN_LEFT_MENU_COLOR_LINKS'); }
	
	$frgn_color_scheme = '';
	if ( get_option('FRGN_COLOR_SCHEME') !== '' ) { $frgn_color_scheme = get_option('FRGN_COLOR_SCHEME'); }
		
	$style = '';
	$style .= '<style type="text/css">';
	if ( $frgn_header_bg_url <> '' ) $style .= '#main_header { background-image: url(' . esc_attr($frgn_header_bg_url) . ') !important; }';
	if ( $frgn_HEADER_BG_COLOR <> '' ) $style .= '#main_header { background-color: #' . esc_attr($frgn_HEADER_BG_COLOR) . ' !important; }';
	
	if ( $frgn_classic_menu_color <> '' ) $style .= '.menu_wrap, #menu ul.nav ul { background-color: #' . esc_attr($frgn_classic_menu_color) . ' !important; }';
	if ( $frgn_classic_menu_color_link <> '' ) $style .= '#menu .nav a, #menu .menu a, .menu .nav a{ color: #' . esc_attr($frgn_classic_menu_color_link) . ' !important; }';
	
	if ( $frgn_menu_bg_url <> '' ) $style .= '#menu.fr_left_menu { background-image: url(' . esc_attr($frgn_menu_bg_url) . ') !important; }';
	if ( $frgn_left_menu_color <> '' ) $style .= '#menu.fr_left_menu { background-color: #' . esc_attr($frgn_left_menu_color) . ' !important; }';
	if ( $frgn_left_menu_color_link <> '' ) $style .= '#menu.fr_left_menu .nav a{ color: #' . esc_attr($frgn_left_menu_color_link) . ' !important; }';

	
	if ( $frgn_color_scheme <> '' ) $style .= '.fr_testi_info span,
.fucts_counter span,
.meta a,
.team_post,
.da-thumbs li a div span.meta,
.frgn_service_2 h4,
.frgn_service i,
.frgn_arrow i,
.form__label,
.text-404,
.page-numbers.current,
.page-numbers a:hover,
.woocommerce .amount,
.woocommerce-info,
h2 a:hover, .meta_cat a:hover { color: ' . esc_attr($frgn_color_scheme) . '!important; } 

.woocommerce button.button,
.woocommerce-info{ border-color: ' . esc_attr($frgn_color_scheme) . '!important; }

.woocommerce button.button,
.woocommerce a.button.add_to_cart_button,
.woocommerce .widget_price_filter .ui-slider .ui-slider-range,
.woocommerce .widget_price_filter .ui-slider .ui-slider-handle,
.fr_video_popup_btn,
.frgn_video_popup_btn_bg,
.frgn_service i:after,
.frgn_arrow i:after,
.fr_post_sticky,
.portfolio_metro_btn:before,
.portfolio_metro_btn:after{ background-color: ' . esc_attr($frgn_color_scheme) . '; } ';
	$style .= '</style>';
	
	if ($frgn_header_bg_url <> '' || $frgn_menu_bg_url <> '' || $frgn_classic_menu_color <> '' || $frgn_color_scheme <> '' || $frgn_left_menu_color <> '' || $frgn_left_menu_color_link <> '') echo $style;
}

?>
