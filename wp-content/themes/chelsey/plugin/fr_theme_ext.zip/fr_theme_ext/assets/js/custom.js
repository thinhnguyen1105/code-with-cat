(function($){

	"use strict";

	if( $('.fr_video_popup_btn').length > 0){
		$('.fr_video_popup_btn').magnificPopup({
		  type: $(this).attr('data')
			// other options
		});
	}	
	
	var FRGN = FRGN || {};
	var isMobile = {
		Android: function() {
			return navigator.userAgent.match(/Android/i);
		},
		BlackBerry: function() {
			return navigator.userAgent.match(/BlackBerry/i);
		},
		iOS: function() {
			return navigator.userAgent.match(/iPhone|iPad|iPod/i);
		},
		Opera: function() {
			return navigator.userAgent.match(/Opera Mini/i);
		},
		Windows: function() {
			return navigator.userAgent.match(/IEMobile/i);
		},
		any: function() {
			return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
		}
	};
	var bodyLoader = false;
	var deviceAnimAppear =  false
	
	FRGN.documentReady = {
		init: function(){
			FRGN.pageSettings.init();
			FRGN.basicElements.init();
		}
	};
	FRGN.basicElements = {
		init: function(){
			this.animAppear();
		},
		animAppear: function(){
			if( bodyLoader || $('body').hasClass('page-template-template-full-page') ){
				return;
			}
			if( isMobile.any() && !deviceAnimAppear ) {
				$('.frgn-animated-item').css('opacity',1);
			} else {
				$('.frgn-animated-item').each(function() {
					var $that = $(this),
						timeDelay = $that.attr('data-delay');

					if( $that.parents('.frgn-clipping-animation').length ) return;

					$that.appear(function() {
						setTimeout(function () {
							$that.addClass('frgn-animated');
						}, timeDelay);
					},{accX: 0, accY: -150});
				});
			}
		},
	}
	FRGN.pageSettings = {
		init: function(){
			this.setClippingWrappers();
			this.setAppearWrappers();
			this.clippingAppear();
			//this.clippingAnimated();
		},
		setClippingWrappers: function(){
			var $element = $('.frgn-clipping-animation'),
				wrapper = '<div class="frgn-clipping-wrapper"><div class="frgn-clipping-content"></div></div>';
			if( isMobile.any() && !deviceAnimAppear ) {
				$element.removeClass('frgn-clipping-animation');
			} else {
				$element.wrapInner( wrapper );
				$element.each(function(){
					var $that = $(this),
						$wrapper = $that.find('.frgn-clipping-wrapper');
					if( $that.hasClass('frgn-colored-clipping') ) {
						var color = $that.data('clipping-color'),
							overlay = '<div class="frgn-clipping-overlay frgn-bg-' + color + '"></div>';
						$(overlay).appendTo( $wrapper );
					}
				});
				this.clippingAppear();
			}
		},
		setAppearWrappers: function(){
			var $element = $('.frgn-appear-animation'),
				wrapper = '<div class="frgn-appear-wrapper frgn-animation-wrapper"><div class="frgn-appear-content"></div></div>';
			if( isMobile.any() && !deviceAnimAppear ) {
				$element.removeClass('frgn-appear-animation');
			} else {
				$element.wrapInner( wrapper );
				this.animAppear();
			}
		},
		animAppear: function(){
			var $animationItem = $('.frgn-appear-animation');

			if( bodyLoader || $('body').hasClass('page-template-template-full-page') || $('body').hasClass('page-template-template-pilling-page') ){
				return;
			}
			if( isMobile.any() && !deviceAnimAppear ) {
				$animationItem.removeClass('frgn-appear-animation');
			} else {
				$animationItem.each(function() {
					var $that = $(this),
						timeDelay = $that.attr('data-delay');

					$that.appear(function() {
						setTimeout(function () {
							$that.addClass('frgn-appear-animated');
						}, timeDelay);
					},{accX: 0, accY: -150});
				});
			}
		},		
		clippingAppear: function(){
			var $clippingEl = $('.frgn-clipping-animation');
			if( bodyLoader || $('body').hasClass('page-template-template-full-page') || $('body').hasClass('page-template-template-pilling-page') ){
				return;
			}
			if( isMobile.any() && !deviceAnimAppear ) {
				$clippingEl.removeClass('frgn-clipping-animation');
			} else {
				$clippingEl.each(function() {
					var $that = $(this),
						timeDelay = $that.attr('data-delay');

					$that.appear(function() {
						setTimeout(function () {
							FRGN.pageSettings.clippingAnimated( $that );
						}, timeDelay);
					},{accX: 0, accY: -150});
				});
			}
		},
		clippingAnimated: function( $element ){
			var delay = 700,
				$overlay = $element.find( '.frgn-clipping-overlay' );

			$element.addClass('frgn-clipping-animated');

			if ( $element.hasClass('frgn-colored-clipping') ) {
				setTimeout(function(){
					$element.addClass('frgn-clipping-show-content');
				},delay);

				delay = 1400;
			}
			setTimeout(function(){
				$overlay.remove();
				$element.removeClass('frgn-clipping-animation frgn-clipping-animated frgn-colored-clipping frgn-clipping-show-content');
				FRGN.basicElements.animAppear();
			},delay);
		},
		
	}
	FRGN.scrollingPageAnimations = {
		addAnim: function( section, index ){
			var $section = $(section[index-1]),
				$element = $section.find('.frgn-animated-item'),
				$column = $section.find('.frgn-clipping-animation');

			$element.each(function(){
				var $that = $(this),
					delay = $that.data('delay');
				if( $that.parents('.frgn-clipping-animation').length ) return;
				setTimeout(function(){
					$that.addClass('frgn-animated');
				},delay);
			});

			$column.each(function(){
				var $that = $(this),
					$element = $that.find('.frgn-animated-item'),
					delay = $that.data('delay');
				setTimeout(function(){
					FRGN.pageSettings.clippingAnimated( $that );
					setTimeout(function(){
						$element.addClass('frgn-animated');
					},700);
				},delay);
			});
		},


		removeAnim: function(section, index, speed){
			var $section = $(section[index-1]),
				$element = $section.find('.frgn-animated-item');
			setTimeout(function(){
				$element.removeClass('frgn-animated');
			},speed);
		}
	};
	$(window).load(function(){ 
		setTimeout(function() {
		  $('.loader').fadeOut('slow', function() {});
		}, 400);
		FRGN.documentReady.init();
	});

	
	
})(jQuery);