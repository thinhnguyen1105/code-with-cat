<?php

add_action('header_top','fragrance_control_panel');
function fragrance_control_panel(){
	
	$admin_access = apply_filters( 'showcontrol_panel', current_user_can('switch_themes') );
	if ( !$admin_access ) return;
	if ( get_option('SHOW_CONTROL_PANEL') <> 'on' ) return;
	global $fr_add_google_fonts; ?>
	<div id="control_panel_wrap">
		<div id="control_panel_main">
			<a id="control_panel_close" href="#"></a>
			<div id="control_panel_inner" class="clearfix">				
				
				<?php 
					$google_fonts = $fr_add_google_fonts;
					$font_setting = 'Arvo';
					$body_font_setting = 'Open Sans';
					$decorative_font_setting = 'Montserrat';
					if ( isset( $_COOKIE['FRGN_HEADER_FONT'] ) ) $font_setting = $_COOKIE['FRGN_HEADER_FONT'];
					if ( isset( $_COOKIE['FRGN_BODY_FONT'] ) ) $body_font_setting = $_COOKIE['FRGN_BODY_FONT'];
					if ( isset( $_COOKIE['FRGN_DECORATIVE_FONT'] ) ) $body_font_setting = $_COOKIE['FRGN_DECORATIVE_FONT'];
				?>
				
			</div> <!-- end #control_panel_inner -->
		</div> <!-- end #control_panel_main -->
	</div> <!-- end #control_panel_wrap -->
<?php
}

add_action( 'wp_head', 'set_font_properties' );
function set_font_properties(){
	$font_style = '';
	$font_family = '';
	
	$header_font = get_option('FRGN_HEADER_FONT');
	//$font_style .= '<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Tangerine">';
	
	//if ( $header_font == 'Open Sans' || $header_font == 'Open Sans' ) $header_font = '';
	if ( $header_font <> '' ) {
		$header_font_id = strtolower( str_replace( '+', '_', $header_font ) );
		$header_font_id = str_replace( ' ', '_', $header_font_id );
		
		if ( $header_font <> '' ) { 
			$font_style .= "<link id='" . esc_attr($header_font_id) . "' href='" . esc_url( "http://fonts.googleapis.com/css?family=" . $header_font ) . "' rel='stylesheet' type='text/css' />";
			$font_family = "font-family: '" . esc_html(str_replace( '+', ' ', $header_font )) . "', Arial, sans-serif; ";
			$font_style .= '<link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700,700i" rel="stylesheet">';
		}
		
		$font_style .= "<style type='text/css'>h1,
h2,
h3,
h4,
h5,
h6,
h1 a,
h2 a,
h3 a,
h4 a,
h5 a,
h6 a,
#quote,
.fr_post_sticky,
span.fn,
q,
#menu a,
ul#mobile_menu a,
[type=submit],
.format-link p a,
.single .entry-title,
.comment-reply-title,
.page-numbers a,
.page-numbers span,
.page-links span,
.fr_testimonials_text_holder p,
.single blockquote:before,
.single blockquote p,
.format-quote blockquote p,
.format-quote blockquote:before,
.format-link p a,
.masonry_layout .format-quote blockquote,
.masonry_layout .format-link a,
.frgn_service_2 .frgn_service_number_2,
.frgn_service .frgn_service_number,
.fucts_counter span,
.vc_pie_chart .vc_pie_chart_value,
.fr-process-bg-text,
.frgn-interactive-links .meta a,
.intro-title,
.frgn_btn_holder a,
.frgn-portfolio-carousel .frgn_read_more,
.frgn_text_stroke, .frgn_text_stroke h2,
.loadmore, .frgn_more, button.ubtn, a.ultb3-btn,
.woocommerce ul.products li.product .button,
.woocommerce div.product .woocommerce-tabs ul.tabs li a,
.woocommerce a.button,
.woocommerce table.shop_table th,
.woocommerce div.product p.price,
.text-404,
.vc_label,
.frgn_single_portfolio .navigation a { ". $font_family .  " }</style>";
		
		echo $font_style;
	}
	
	$font_style = '';
	$font_family = '';
	
	$body_font = get_option('FRGN_BODY_FONT');
	if ( $body_font == 'PT Serif' ) $body_font = '';
	
	if ( $body_font <> '' ) {
		$body_font_id = strtolower( str_replace( '+', '_', $body_font ) );
		$body_font_id = str_replace( ' ', '_', $body_font_id );
		
		if ( $body_font <> '' ) { 
			$font_style .= "<link id='" . esc_attr($body_font_id) . "' href='" . esc_url( "http://fonts.googleapis.com/css?family=" . $body_font ) . "' rel='stylesheet' type='text/css' />";
			$font_family = "font-family: '" . esc_html(str_replace( '+', ' ', $body_font )) . "', Arial, sans-serif; ";
		}
		
		$font_style .= "<style type='text/css'>body,
p,
#contact p input,
#contact p textarea,
input,
textarea,
.fucts_name,
#fr_to_top span,
.wpb_pie_chart_heading,
.fr-process-inner h5,
.woocommerce ul.products li.product .price,
.meta,
.fr_category a,
cite,
.readmore,
.more-link,
.social-icons a,
.meta_line span,
.frgn_service_2 h4{ ". $font_family .  " }</style>";
		
		echo $font_style;
	}
	
	/*$font_style = '';
	$font_family = '';
	$decorative_font = get_option('FRGN_DECORATIVE_FONT');
	if ( $decorative_font == 'PT Serif' ) $decorative_font = '';
	
	if ( $decorative_font <> '' ) {
		$decorative_font_id = strtolower( str_replace( '+', '_', $decorative_font ) );
		$decorative_font_id = str_replace( ' ', '_', $decorative_font_id );
		
		if ( $decorative_font <> '' ) { 
			$font_style .= "<link id='" . esc_attr($decorative_font_id) . "' href='" . esc_url( "http://fonts.googleapis.com/css?family=" . $decorative_font ) . "' rel='stylesheet' type='text/css' />";
			$font_family = "font-family: '" . esc_html(str_replace( '+', ' ', $decorative_font )) . "', Arial, sans-serif !important;";
		}
		
		$font_style .= "<style type='text/css'>.frgn-portfolio-carousel-title-holder .meta a{ ". $font_family .  " }</style>";
		
		echo $font_style;
	}*/
	
	// FONT SIZE & LINE HEIGHT
	$frgn_font_size = '';
	$frgn_font_size_h = '';
	$frgn_font_size_h1 = get_option('FRGN_H1_FONT_SIZE');
	$frgn_h1_line_height = get_option('FRGN_H1_LINE_HEIGHT');
	$frgn_font_size_h2 = get_option('FRGN_H2_FONT_SIZE');
	$frgn_line_height_h2 = get_option('FRGN_H2_LINE_HEIGHT');
	$frgn_font_size_h3 = get_option('FRGN_H3_FONT_SIZE');
	$frgn_line_height_h3 = get_option('FRGN_H3_LINE_HEIGHT');
	$frgn_font_size_h4 = get_option('FRGN_H4_FONT_SIZE');
	$frgn_line_height_h4 = get_option('FRGN_H4_LINE_HEIGHT');
	$frgn_font_size_h5 = get_option('FRGN_H5_FONT_SIZE');
	$frgn_line_height_h5 = get_option('FRGN_H5_LINE_HEIGHT');
	$frgn_font_size_h6 = get_option('FRGN_H6_FONT_SIZE');
	$frgn_line_height_h6 = get_option('FRGN_H6_LINE_HEIGHT');
		
	$frgn_font_settings = array($frgn_font_size, $frgn_font_size_h1, $frgn_font_size_h2, $frgn_font_size_h3, $frgn_font_size_h4, $frgn_font_size_h5, $frgn_font_size_h6);	
	foreach ( $frgn_font_settings as $key => $frgn_opt ){		
		if ( $frgn_font_size_h.$key <> ''  ) {
			$font_style = "<style type='text/css' rel='headings'>h".$key.", h".$key." a{ font-size: ". get_option('FRGN_H'.$key.'_FONT_SIZE') .  "px !important; line-height: ". get_option('FRGN_H'.$key.'_LINE_HEIGHT') .  "px !important; }</style>";
		}
		if ($key > 0){
			echo $font_style;
		}
	}
	
	// TEXT TRANSFORM
	for($i=1; $i < 6; $i++) {
		if( get_option('FRGN_H'.$i.'_TEXT_TRANSFORM') <> ''){
			$font_transform = "<style type='text/css' rel='headings'>h".$i.", h".$i." a{ text-transform: ". strtolower(get_option('FRGN_H'.$i.'_TEXT_TRANSFORM')) .  " !important; }</style>";
			if ($i > 0){
				echo $font_transform;
			}
		}
		
	}
}
?>