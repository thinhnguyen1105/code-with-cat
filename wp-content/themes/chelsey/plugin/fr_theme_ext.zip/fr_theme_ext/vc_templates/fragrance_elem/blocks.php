<?php
	
//Process Services Block
/*function fr_service( $atts, $content = null ) {
   extract( shortcode_atts( array(
	  'sub_title' => '',
	  'sub_title_number' => '',
	  'title' => '',
	  'btn_color' => '',
	  //'btn_shadow_color' => '',
   ), $atts ) );
	
	$img_id = preg_replace( '/[^\d]/', '', $img );
	$img_url = wp_get_attachment_image_src( $img_id, 'full' );
	
	$output = "<div class='fr_service {$align}'>";
	$output .= "<span class='fr_service_number'><span class='fr_service_number_holder'>{$sub_title_number}</span></span>";
	$output .= "<div class='fr_service_title_holder'><h3 class='fr_service_title'>{$title}</h3></div>";
	$output .= "<span class='fr_service_sub_title_holder'>".wpb_js_remove_wpautop($content, true)."</span>";
	$output .= "<a href='#' class='fr_service_btn' style='background-color:{$btn_color};'><span class='frgn_icon_holder'><i class='pe-7s-angle-right'></i></span></a>";
	$output .= "</div>";
	
   return $output;
}
add_shortcode( 'add_fr_service', 'fr_service' );

add_action( 'init', 'fr_service1' );
function fr_service1() {
   vc_map( array(
	"name" => __("Process Services Block", "chelsey"),
	"description" => "Process Services Block",
	"base" => "add_fr_service",
	"icon" => 'chelsey-element-icon dashicons dashicons-image-filter',
	"class" => "",
	"category" => __('Chelsey Elements', 'frgn-extension'),
	'admin_enqueue_js' => '',
	'admin_enqueue_css' => '',
	"params" => array(	
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Sub Title Number of Process", "chelsey"),
			"param_name" => "sub_title_number",
			"value" => '',
			"description" => __("Sub Title Number of Process", "chelsey")
		),
		array(
			"type" => "textfield",
			"holder" => "h4",
			"class" => "",
			"heading" => __("Title", "chelsey"),
			"param_name" => "title",
			"value" => '',
			"description" => __("Title for service block", "chelsey")
		),
		array(
			"type" => "textarea_html",
			"holder" => "em",
			"class" => "",
			"heading" => __("Content", "chelsey"),
			"param_name" => "content",
			"value" => '',
			"description" => __("Sub Title for service block", "chelsey")
		),	
		array(
			"type" => "colorpicker",
			"holder" => "div",
			"class" => "",
			"heading" => __("Button color", "chelsey"),
			"param_name" => "btn_color",
			"value" => '',
			"description" => __("Choose color", "chelsey")
		),	
      )
   ) );
}
*/
//Process Services Block

//Process Services Block 2
function fr_service_2( $atts, $content = null ) {
   extract( shortcode_atts( array(
	  'sub_title' => '',
	  'sub_title_number' => '',
	  'title' => '',
	  'link_url' => '',
	  'link_text' => 'More Inforamtion',
   ), $atts ) );
	
	$output = "<div class='frgn_service_2 {$align}'>";
	$output .= "<div class='frgn_hover_block_overlap'></div>";
	$output .= "<div class='frgn_service_inner'><span class='frgn_service_number_2'><span class='fr_service_number_holder'>{$sub_title_number}</span></span>";
	$output .= "<div class='frgn_service_sub_title_holder'><h4 class='frgn_service_sub_title'>{$sub_title}</h4></div>";
	$output .= "<div class='frgn_service_title_holder'><h3 class='fr_service_title'>{$title}</h3></div>";
	$output .= "<span class='frgn_service_sub_title_holder'>".wpb_js_remove_wpautop($content, true)."</span>";
	$output .= "<div class='frgn_btn_holder {$align}'><a href='{$link_url}'><span>{$link_text}</span></a></div>";
	$output .= "</div></div>";
	
   return $output;
}
add_shortcode( 'add_fr_service_2', 'fr_service_2' );

add_action( 'init', 'fr_service_2_vc' );
function fr_service_2_vc() {
   vc_map( array(
	"name" => __("Services Block", "chelsey"),
	"description" => "Services Block",
	"base" => "add_fr_service_2",
	"icon" => 'chelsey-element-icon dashicons dashicons-image-filter',
	"class" => "",
	"category" => __('Chelsey Elements', 'frgn-extension'),
	'admin_enqueue_js' => '',
	'admin_enqueue_css' => '',
	"params" => array(	
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Number of Services", "chelsey"),
			"param_name" => "sub_title_number",
			"value" => '',
			"description" => __("Number of Services", "chelsey")
		),
		array(
			"type" => "textfield",
			"holder" => "em",
			"class" => "",
			"heading" => __("Sub Title", "chelsey"),
			"param_name" => "sub_title",
			"value" => '',
			"description" => __("Sub Title for service block", "chelsey")
		),
		array(
			"type" => "textfield",
			"holder" => "h4",
			"class" => "",
			"heading" => __("Title", "chelsey"),
			"param_name" => "title",
			"value" => '',
			"description" => __("Title for service block", "chelsey")
		),
		array(
			"type" => "textarea_html",
			"holder" => "em",
			"class" => "",
			"heading" => __("Content", "chelsey"),
			"param_name" => "content",
			"value" => '',
			"description" => __("Sub Title for service block", "chelsey")
		),	
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Link Text", "chelsey"),
			"param_name" => "link_text",
			"value" => '',
			"description" => __("Enter link text", "chelsey")
		),	
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Link URL", "chelsey"),
			"param_name" => "link_url",
			"value" => '',
			"description" => __("", "chelsey")
		),	
      )
   ) );
}
//Process Services Block

//Process Services Block
/*function frgn_service( $atts, $content = null ) {
   extract( shortcode_atts( array(
	  'sub_title' => '',
	  'sub_title_number' => '',
	  'title' => '',
	  'btn_color' => '',
	  'link_url' => '#',
	  'link_text' => 'See More',
	  'parallax' => 'transform:translateY(10%)',
   ), $atts ) );
	
	$img_id = preg_replace( '/[^\d]/', '', $img );
	$img_url = wp_get_attachment_image_src( $img_id, 'full' );
	
	$output = "<div class='frgn_service frgn_parallax {$align}' data-bottom='{$parallax}' data-center-bottom='transform:translateY(0%)'>";
	$output .= "<span class='frgn_service_number'><span class='frgn_service_number_holder'>{$sub_title_number}</span></span>";
	$output .= "<div class='frgn_service_title_holder'><h3 class='frgn_service_title'>{$title}</h3></div>";	
	$output .= "<span class='frgn_service_sub_title_holder'>".wpb_js_remove_wpautop($content, true)."</span>";
	$output .= "<div class='frgn_btn_holder {$align}'><a href='{$link_url}' class='frgn_arrow'><span>{$link_text}</span><i class='pe-7s-angle-right'></i></a></div>";
	$output .= "</div>";
	
   return $output;
}
add_shortcode( 'add_frgn_service', 'frgn_service' );

add_action( 'init', 'frgn_service1' );
function frgn_service1() {
   vc_map( array(
	"name" => __("Services Block", "chelsey"),
	"description" => "Services Block",
	"base" => "add_frgn_service",
	"icon" => 'chelsey-element-icon dashicons dashicons-image-filter',
	"class" => "",
	"category" => __('Chelsey Elements', 'frgn-extension'),
	'admin_enqueue_js' => '',
	'admin_enqueue_css' => '',
	"params" => array(	
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Sub Title Number of Process", "chelsey"),
			"param_name" => "sub_title_number",
			"value" => '',
			"description" => __("Sub Title Number of Process", "chelsey")
		),
		array(
			"type" => "textfield",
			"holder" => "h4",
			"class" => "",
			"heading" => __("Title", "chelsey"),
			"param_name" => "title",
			"value" => '',
			"description" => __("Title for service block", "chelsey")
		),
		array(
			"type" => "textarea_html",
			"holder" => "em",
			"class" => "",
			"heading" => __("Content", "chelsey"),
			"param_name" => "content",
			"value" => '',
			"description" => __("Sub Title for service block", "chelsey")
		),	
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Link URL", "chelsey"),
			"param_name" => "link_url",
			"value" => '',
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Link Text", "chelsey"),
			"param_name" => "link_text",
			"value" => '',
			"description" => __("", "chelsey")
		),
		array(
			"type" => "colorpicker",
			"holder" => "div",
			"class" => "",
			"heading" => __("Button color", "chelsey"),
			"param_name" => "btn_color",
			"value" => '',
			"description" => __("Choose color", "chelsey")
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => __("Parallax", "chelsey"),
			"param_name" => "parallax",
			"value" => array(
				esc_html__("Move to Top", "chelsey") => 'transform:translateY(10%)',
				esc_html__("Move to Bottom", "chelsey") => 'transform:translateY(-10%)',
			),
			"description" => __("", "chelsey")
		),
      )
   ) );
}*/
//Process Services Block

?>