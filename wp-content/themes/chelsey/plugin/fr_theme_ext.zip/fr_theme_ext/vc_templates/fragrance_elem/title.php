<?php
/**
 * Title Shortcode
 */

if( !function_exists( 'frgn_ext_vce_title_shortcode' ) ) {

	function frgn_ext_vce_title_shortcode( $atts, $content ) {

		$output = $data = $el_class = '';

		extract(
			shortcode_atts(
				array(
					'title' => '',
					'heading_tag' => 'h3',
					'heading' => 'h3',
					'custom_font_family' => '',
					'gradient_color' => '',
					'gradient_color_1' => 'primary-1',
					'gradient_color_2' => 'primary-2',
					'increase_heading' => '100',
					'increase_heading_reset' => '',
					'line_type' => '',
					'line_width' => '50',
					'line_height' => '1',
					'line_color' => 'primary-1',
					'inherit_align' => 'inherit',
					'animation' => '',
					'clipping_animation' => 'frgn-clipping-up',
					'clipping_animation_colors' => 'dark',
					'appear_animation' => 'frgn-appear-up',
					'animation_delay' => '200',
					'animation_duration' => 'normal',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$atts
			)
		);

		$style = frgn_ext_vce_build_margin_bottom_style( $margin_bottom );

		$title_classes = array( 'frgn-element', 'frgn-title' );

		array_push( $title_classes, 'frgn-align-' . $inherit_align );

		if ( !empty( $animation ) ) {
			if( 'frgn-clipping-animation' == $animation ) {
				array_push( $title_classes, $clipping_animation);
				if( 'frgn-colored-clipping-up' == $clipping_animation || 'frgn-colored-clipping-down' == $clipping_animation || 'frgn-colored-clipping-left' == $clipping_animation || 'frgn-colored-clipping-right' == $clipping_animation ) {
					array_push( $title_classes, 'frgn-colored-clipping');
					$data .= ' data-clipping-color="' . esc_attr( $clipping_animation_colors ) . '"';
				}
			} else if( 'frgn-appear-animation' == $animation ) {
				array_push( $title_classes, $appear_animation);
				array_push( $title_classes, 'frgn-duration-' . $animation_duration );
			} else {
				array_push( $title_classes, 'frgn-animated-item' );
				array_push( $title_classes, 'frgn-duration-' . $animation_duration );
			}
			array_push( $title_classes, $animation);
			$data .= ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}

		if ( !empty( $heading ) ) {
			array_push( $title_classes, 'frgn-' . $heading );
		}

		if ( !empty( $custom_font_family ) ) {
			array_push( $title_classes, 'frgn-' . $custom_font_family );
		}

		if ( !empty( $el_class ) ) {
			array_push( $title_classes, $el_class );
		}

		if( '100' != $increase_heading ){
			if( !empty( $increase_heading_reset ) ) {
				$title_classes = frgn_ext_vce_increase_heading_reset( $increase_heading_reset, $title_classes );
			}
			array_push( $title_classes, 'frgn-increase-heading' );
			array_push( $title_classes, 'frgn-heading-' . $increase_heading );
		}

		if ( !empty( $gradient_color ) ) {
			array_push( $title_classes, 'frgn-title-gradient' );
			array_push( $title_classes, 'frgn-gradient-1-' . $gradient_color_1 );
			array_push( $title_classes, 'frgn-gradient-2-' . $gradient_color_2 );
		}

		$title_class_string = implode( ' ', $title_classes );

		$output .= '<' . tag_escape( $heading_tag ) . ' class="' . esc_attr( $title_class_string ) . '" style="' . $style . '"' . $data . '>';
		$output .= '<span>';
		$output .= frgn_ext_vce_auto_br( $content );

		if ( !empty( $line_type ) ) {
			$line_style = '';
			$line_style .= 'width: '.(preg_match('/(px|em|\%|pt|cm)$/', $line_width) ? $line_width : $line_width.'px').';';
			$line_style .= 'height: '. $line_height. 'px;';
			$output .= '<span class="frgn-title-line frgn-title-' . esc_attr( $line_type ) . ' frgn-bg-' . esc_attr( $line_color ) . '" style="' . esc_attr( $line_style ) . '"></span>';
		}
		$output .= '</span>';
		$output .= '</' . tag_escape( $heading_tag ) . '>';

		return $output;
	}
	add_shortcode( 'frgn_title', 'frgn_ext_vce_title_shortcode' );

}

/**
 * Add shortcode to Page Builder
 */

if( !function_exists( 'frgn_ext_vce_title_shortcode_params' ) ) {
	function frgn_ext_vce_title_shortcode_params( $tag ) {
		return array(
			"name" => esc_html__( "Title", "frgn-extension" ),
			"description" => esc_html__( "Add a title in many and diverse ways", "frgn-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "chelsey-element-icon dashicons dashicons-editor-alignleft",
			"category" => esc_html__("Chelsey Elements", 'frgn-extension'),
			"params" => array(
				array(
					"type" => "textarea_html",
					"heading" => esc_html__( "Title Content", "frgn-extension" ),
					"param_name" => "content",
					"value" => "Sample Title",
					"description" => esc_html__( "Enter your title here.", "frgn-extension" ),
					"save_always" => true,
					"admin_label" => true,
				),
				frgn_ext_vce_get_heading_tag( "h3" ),
				//frgn_ext_vce_get_heading( "h3" ),
				//frgn_ext_vce_get_heading_increase(),
				//frgn_ext_vce_get_heading_increase_reset(),
				//frgn_ext_vce_get_custom_font_family(),
				//frgn_ext_vce_get_gradient_color(),
				//frgn_ext_vce_get_gradient_color_1(),
				//frgn_ext_vce_get_gradient_color_2(),
				/*array(
					"type" => "dropdown",
					"heading" => esc_html__( "Line type", "frgn-extension" ),
					"param_name" => "line_type",
					"value" => array(
						esc_html__( "No Line", "frgn-extension" ) => '',
						esc_html__( "Bottom Line", "frgn-extension" ) => 'bottom-line',
						esc_html__( "Left Line", "frgn-extension" ) => 'left-line',
						esc_html__( "Right Line", "frgn-extension" ) => 'right-line',
					),
					"description" => '',
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( "Line Width", "frgn-extension" ),
					"param_name" => "line_width",
					"value" => "50",
					"description" => esc_html__( "Enter the width for your line (Note: CSS measurement units allowed).", "frgn-extension" ),
					"dependency" => array( 'element' => "line_type", 'value_not_equal_to' => array( '' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Line Height", "frgn-extension" ),
					"param_name" => "line_height",
					"value" => array( '1', '2', '3', '4' , '5', '6', '7', '8', '9' , '10' ),
					"std" => '1',
					"description" => esc_html__( "Enter the hight for your line in px.", "frgn-extension" ),
					"dependency" => array( 'element' => "line_type", 'value_not_equal_to' => array( '' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Line Color", "frgn-extension" ),
					"param_name" => "line_color",
					"param_holder_class" => "frgn-colored-dropdown",
					"value" => array(
						esc_html__( "Primary 1", "frgn-extension" ) => 'primary-1',
						esc_html__( "Primary 2", "frgn-extension" ) => 'primary-2',
						esc_html__( "Primary 3", "frgn-extension" ) => 'primary-3',
						esc_html__( "Primary 4", "frgn-extension" ) => 'primary-4',
						esc_html__( "Primary 5", "frgn-extension" ) => 'primary-5',
						esc_html__( "Primary 6", "frgn-extension" ) => 'primary-6',
						esc_html__( "Green", "frgn-extension" ) => 'green',
						esc_html__( "Orange", "frgn-extension" ) => 'orange',
						esc_html__( "Red", "frgn-extension" ) => 'red',
						esc_html__( "Blue", "frgn-extension" ) => 'blue',
						esc_html__( "Aqua", "frgn-extension" ) => 'aqua',
						esc_html__( "Purple", "frgn-extension" ) => 'purple',
						esc_html__( "Black", "frgn-extension" ) => 'black',
						esc_html__( "Grey", "frgn-extension" ) => 'grey',
						esc_html__( "White", "frgn-extension" ) => 'white',
					),
					"description" => esc_html__( "Color for the line.", "frgn-extension" ),
					"dependency" => array( 'element' => "line_type", 'value_not_equal_to' => array( '' ) ),
				),*/
				frgn_ext_vce_add_inherit_align(),
				//frgn_ext_vce_add_margin_bottom(),
				frgn_ext_vce_add_el_class(),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "CSS Animation", "frgn-extension"),
					"param_name" => "animation",
					"value" => array(
						esc_html__( "No", "frgn-extension" ) => '',
						esc_html__( "Fade In", "frgn-extension" ) => "frgn-fade-in",
						esc_html__( "Fade In Up", "frgn-extension" ) => "frgn-fade-in-up",
						esc_html__( "Fade In Up Big", "frgn-extension" ) => "frgn-fade-in-up-big",
						esc_html__( "Fade In Down", "frgn-extension" ) => "frgn-fade-in-down",
						esc_html__( "Fade In Down Big", "frgn-extension" ) => "frgn-fade-in-down-big",
						esc_html__( "Fade In Left", "frgn-extension" ) => "frgn-fade-in-left",
						esc_html__( "Fade In Left Big", "frgn-extension" ) => "frgn-fade-in-left-big",
						esc_html__( "Fade In Right", "frgn-extension" ) => "frgn-fade-in-right",
						esc_html__( "Fade In Right Big", "frgn-extension" ) => "frgn-fade-in-right-big",
						esc_html__( "Zoom In", "frgn-extension" ) => "frgn-zoom-in",
						esc_html__( "Clipping Animation", "frgn-extension" ) => "frgn-clipping-animation",
						esc_html__( "Appear Animation", "frgn-extension" ) => "frgn-appear-animation",
					),
					"group" => esc_html__( "Animation", 'frgn-extension' ),
					"description" => esc_html__("Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", "frgn-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "CSS Animation", "frgn-extension"),
					"param_name" => "clipping_animation",
					"value" => array(
						esc_html__( "Clipping Up", "frgn-extension" ) => "frgn-clipping-up",
						esc_html__( "Clipping Down", "frgn-extension" ) => "frgn-clipping-down",
						esc_html__( "Clipping Left", "frgn-extension" ) => "frgn-clipping-left",
						esc_html__( "Clipping Right", "frgn-extension" ) => "frgn-clipping-right",
						esc_html__( "Colored Clipping Up", "frgn-extension" ) => "frgn-colored-clipping-up",
						esc_html__( "Colored Clipping Down", "frgn-extension" ) => "frgn-colored-clipping-down",
						esc_html__( "Colored Clipping Left", "frgn-extension" ) => "frgn-colored-clipping-left",
						esc_html__( "Colored Clipping Right", "frgn-extension" ) => "frgn-colored-clipping-right",
					),
					"group" => esc_html__( "Animation", 'frgn-extension' ),
					"dependency" => array( 'element' => "animation", 'value' => array( 'frgn-clipping-animation' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Clipping Color", "frgn-extension" ),
					"param_name" => "clipping_animation_colors",
					"param_holder_class" => "frgn-colored-dropdown",
					"value" => array(
						esc_html__( "Dark", "frgn-extension" ) => 'dark',
						esc_html__( "Light", "frgn-extension" ) => 'light',
						esc_html__( "Green", "frgn-extension" ) => 'green',
						esc_html__( "Orange", "frgn-extension" ) => 'orange',
						esc_html__( "Red", "frgn-extension" ) => 'red',
						esc_html__( "Blue", "frgn-extension" ) => 'blue',
						esc_html__( "Aqua", "frgn-extension" ) => 'aqua',
						esc_html__( "Purple", "frgn-extension" ) => 'purple',
						esc_html__( "Grey", "frgn-extension" ) => 'grey',
					),
					"description" => esc_html__( "Select clipping color", "frgn-extension" ),
					"group" => esc_html__( "Animation", 'frgn-extension' ),
					"dependency" => array( 'element' => "clipping_animation", 'value' => array( 'frgn-colored-clipping-up', 'frgn-colored-clipping-down', 'frgn-colored-clipping-left', 'frgn-colored-clipping-right' ) ),
				),

				array(
					"type" => "dropdown",
					"heading" => esc_html__("CSS Appear Animation", 'frgn-extension' ),
					"param_name" => "appear_animation",
					"admin_label" => true,
					"value" => array(
						esc_html__( "Appear Up", 'frgn-extension' ) => "frgn-appear-up",
						esc_html__( "Appear Down", 'frgn-extension' ) => "frgn-appear-down",
						esc_html__( "Appear Left", 'frgn-extension' ) => "frgn-appear-left",
						esc_html__( "Appear Right", 'frgn-extension' ) => "frgn-appear-right",
					),
					'dependency' => array(
						'element' => 'animation',
						'value' => 'frgn-appear-animation',
					),
					"description" => esc_html__("Select type of animation if you want this column to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", 'frgn-extension' ),
					"group" => esc_html__( "Animation", 'frgn-extension' ),
				),

				array(
					"type" => "textfield",
					'edit_field_class' => 'vc_col-sm-6',
					"heading" => esc_html__('Css Animation Delay', 'frgn-extension'),
					"param_name" => "animation_delay",
					"value" => '200',
					"description" => esc_html__( "Add delay in milliseconds.", "frgn-extension" ),
					"group" => esc_html__( "Animation", 'frgn-extension' ),
					"dependency" => array( 'element' => "animation", 'value_not_equal_to' => array( '' ) ),
				),
				array(
					"type" => "dropdown",
					'edit_field_class' => 'vc_col-sm-6',
					"heading" => esc_html__( "CSS Animation Duration", "frgn-extension"),
					"param_name" => "animation_duration",
					"value" => array(
						esc_html__( "Very Fast", "frgn-extension" ) => "very-fast",
						esc_html__( "Fast", "frgn-extension" ) => "fast",
						esc_html__( "Normal", "frgn-extension" ) => "normal",
						esc_html__( "Slow", "frgn-extension" ) => "slow",
						esc_html__( "Very Slow", "frgn-extension" ) => "very-slow",
					),
					"std" => 'normal',
					"description" => esc_html__("Select the duration for your animated element.", 'frgn-extension' ),
					"group" => esc_html__( "Animation", 'frgn-extension' ),
					"dependency" => array( 'element' => "animation", 'value_not_equal_to' => array( 'frgn-clipping-animation', '' ) ),
				),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'frgn_title', 'frgn_ext_vce_title_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = frgn_ext_vce_title_shortcode_params( 'frgn_title' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
