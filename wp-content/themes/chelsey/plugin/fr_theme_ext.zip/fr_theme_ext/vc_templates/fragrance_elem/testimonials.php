<?php
// Fragrance Testimonials Container
function testimonials_container( $atts, $content = null ) {
    extract( shortcode_atts( array(
		'img' => '',
		'testimonial' => '',
		'author_name' => '',
		'color_scheme' => '',
    ), $atts ) );
	
	$img_id = preg_replace( '/[^\d]/', '', $img );
	$img_url = wp_get_attachment_image_src( $img_id, 'thumbnail' );
	
	$output = "<div class='frgn-testimonials-carousel owl-carousel {$color_scheme}'>". do_shortcode($content);
	$output .="</div><div class='slider-counter'></div>";
	
    return $output;
}
add_shortcode( 'fr_testimonials_container_vc', 'testimonials_container' );

add_action( 'init', 'frgn_testimonials_container' );
function frgn_testimonials_container() {
   vc_map( array(
    "name" => __("Testimonials Container", "chelsey"),
    "base" => "fr_testimonials_container_vc",
	"icon" => 'chelsey-element-icon dashicons dashicons-admin-comments',
    "class" => "fr_testimonials",
	
	"show_settings_on_create" => false,
	"is_container" => true,
	"content_element" => true,
	"as_parent" => array('only' => 'fr_testimonials'),
	
    "category" => __('Chelsey Elements', 'frgn-extension'),
    'admin_enqueue_js' => '',
    'admin_enqueue_css' => '',
	"params" => array(
		array(
			"type" => "dropdown",
			"holder" => "div",
			"class" => "",
			"heading" => __("Color Scheme", "chelsey"),
			"param_name" => "color_scheme",
			"value" => array(
				esc_html__("Black", "chelsey") => 'black',
				esc_html__("White", "chelsey") => 'white',
			),
			"description" => __("", "chelsey")
		),
	)
    /*"params" => array(
		array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Position", "chelsey"),
            "param_name" => "position",
            "value" => '',
            "description" => __("", "chelsey")
        ),
      )*/
   ) );
}

// Fragrance Testimonials Container


// Fragrance Testimonials 1
function testimonials( $atts, $content = null ) {
    extract( shortcode_atts( array(
		'img' => '',
		'testimonial' => '',
		'author_name' => '',
		'position' => '',
    ), $atts ) );
	
	/*$img_id = preg_replace( '/[^\d]/', '', $img );
	$img_url = wp_get_attachment_image_src( $img_id, 'thumbnail' );*/
	
	$output = "<div class='fr_testimonials'>";
	//$output .= "<img src='{$img_url[0]}' alt='img' />";
	$output .= "<div class='fr_testimonials_text_holder'>".wpb_js_remove_wpautop($content, true)."</div>";
	$output .= "<div class='fr_testi_info clearfix'>";
	$output .="<p class='meta clearfix'><h4>{$author_name}</h4><span> - {$position}</span></p></div></div>";
	
    return $output;
}
add_shortcode( 'fr_testimonials', 'testimonials' );

add_action( 'init', 'fr_testimonials_block' );
function fr_testimonials_block() {
   vc_map( array(
    "name" => __("Testimonials", "chelsey"),
    "base" => "fr_testimonials",
	"icon" => 'chelsey-element-icon dashicons dashicons-admin-comments',
    "class" => "fr_testimonials",
    "category" => __('Chelsey Elements', 'frgn-extension'),
    'admin_enqueue_js' => '',
    'admin_enqueue_css' => '',
    "params" => array(
		/* array(
			"type" => "attach_image",
			"holder" => "div",
			"class" => "",
			"heading" => __("Testimonial Person Photo", "chelsey"),
			"param_name" => "img",
			"value" => '',
			"description" => __("", "chelsey")
		),*/
		array(
            "type" => "textarea_html",
            "holder" => "div",
            "class" => "",
            "heading" => __("Testimonial", "chelsey"),
            "param_name" => "content",
            "value" => '',
            "description" => __("", "chelsey")
        ),
		array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Testimonial Person Name", "chelsey"),
            "param_name" => "author_name",
            "value" => '',
            "description" => __("", "chelsey")
        ),
		array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Position", "chelsey"),
            "param_name" => "position",
            "value" => '',
            "description" => __("", "chelsey")
        ),
      )
   ) );
}
// Fragrance Testimonials 1


// Fragrance Testimonials 2
function testimonials2( $atts, $content = null ) {
    extract( shortcode_atts( array(
		'img' => '',
		'testimonial' => '',
		'author_name' => '',
		'position' => '',
		'style' => '',
		'bg_color' => '#e9f0f2 ',
		
    ), $atts ) );
	
	$img_id = preg_replace( '/[^\d]/', '', $img );
	$img_url = wp_get_attachment_image_src( $img_id, 'thumbnail' );
	
	$output = "<div class='fr_testimonials2 {$style}'>";
	$output .= "<div style='background-color:{$bg_color};'>".wpb_js_remove_wpautop($content, true)."<span class='bottom-arrow' style='background-color:{$bg_color};'></span></div>";
	$output .= "<div class='fr_testi_info'><img src='{$img_url[0]}' alt='img' />";
	$output .="<div class='meta'><h4>{$author_name}</h4><span>{$position}</span></div></div></div>";
	
    return $output;
}
add_shortcode( 'fr_testimonials2', 'testimonials2' );

add_action( 'init', 'fr_testimonials_block2' );
function fr_testimonials_block2() {
   vc_map( array(
    "name" => __("Testimonials 2", "chelsey"),
    "base" => "fr_testimonials2",
	"icon" => 'chelsey-element-icon dashicons dashicons-format-chat',
    "class" => "fr_testimonials2",
    "category" => __('Chelsey Elements', 'frgn-extension'),
    'admin_enqueue_js' => '',
    'admin_enqueue_css' => '',
    "params" => array(
		array(
			"type" => "dropdown",
			"holder" => "div",
			"class" => "",
			"heading" => __("Style", "chelsey"),
			"param_name" => "style",
			"value" => array("colored", "transparent"),
			"description" => __("", "chelsey")
		),
		array(
			"type" => "colorpicker",
			"holder" => "div",
			"class" => "",
			"heading" => __("Background color", "chelsey"),
			"param_name" => "bg_color",
			"value" => "#8f75be",
			"description" => __("Choose background color for colored style", "chelsey")
		),
        array(
			"type" => "attach_image",
			"holder" => "div",
			"class" => "",
			"heading" => __("Testimonial Person Photo", "chelsey"),
			"param_name" => "img",
			"value" => '',
			"description" => __("", "chelsey")
		),
		array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Image Size", "chelsey"),
            "param_name" => "img_size",
            "value" => '',
            "description" => __("", "chelsey")
        ),
		array(
            "type" => "textarea_html",
            "holder" => "div",
            "class" => "",
            "heading" => __("Testimonial", "chelsey"),
            "param_name" => "content",
            "value" => '',
            "description" => __("", "chelsey")
        ),
		array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Testimonial's Font Size", "chelsey"),
            "param_name" => "font_size",
            "value" => '',
            "description" => __("", "chelsey")
        ),
		array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Testimonial Person Name", "chelsey"),
            "param_name" => "author_name",
            "value" => '',
            "description" => __("", "chelsey")
        ),
		array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Position", "chelsey"),
            "param_name" => "position",
            "value" => '',
            "description" => __("", "chelsey")
        ),
      )
   ) );
}
// Fragrance Testimonials 2

// A must for container functionality, replace Wbc_Item with your base name from mapping for parent container
if(class_exists('WPBakeryShortCodesContainer')){
    class WPBakeryShortCode_fr_testimonials_container_vc extends WPBakeryShortCodesContainer {

    }
}

// Replace Wbc_Inner_Item with your base name from mapping for nested element
if(class_exists('WPBakeryShortCode')){
    class WPBakeryShortCode_fr_testimonials extends WPBakeryShortCode {

    }
}