<?php

//Fragrance Process
function process( $atts, $content = null ) {
	extract( shortcode_atts( array(
	  'img' => '',
	  'sub_head' => '',
	  'title' => '',
	  'bg_text' => '',
	  'align' => '',
	), $atts ) );
	
	$img_id = preg_replace( '/[^\d]/', '', $img );
	$img_url = wp_get_attachment_image_src( $img_id, 'full' );
	
	$output = "";
	$output .= "<div class='fr-process {$align}'>";
	$output .= "<div class='fr-process-bg'  style='background-image:url({$img_url[0]});'></div>";
	$output .= "<div class='fr-process-content'><div class='fr-process-inner'><h5>".$sub_head."</h5><h3>".$title."</h3><p>".wpb_js_remove_wpautop($content, true)."</p></div><div class='fr-process-bg-text' data-bottom='transform:translateY(10%)' data-center-bottom='transform:translateY(0%)'>".$bg_text."</div></div>";
	$output .= "</div>";

   return $output;
}
add_shortcode( 'process_elem', 'process' );

add_action( 'init', 'process_map' );
function process_map() {
   vc_map( array(
	"name" => __("Process", 'frgn-extension'),
	"base" => "process_elem",
	"icon" => 'chelsey-element-icon dashicons dashicons-editor-spellcheck',
	"class" => "",
	"category" => __('Chelsey Elements', 'frgn-extension'),
	'admin_enqueue_js' => '',
	'admin_enqueue_css' => '',
	"params" => array(
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Sub heading", 'frgn-extension'),
			"param_name" => "sub_head",
			"value" => '',
			"description" => __("Enter sub heading", 'frgn-extension')
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Title", 'frgn-extension'),
			"param_name" => "title",
			"value" => '',
			"description" => __("Enter your title", 'frgn-extension')
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Background text", 'frgn-extension'),
			"param_name" => "bg_text",
			"value" => '',
			"description" => __("Enter number or text for display on background", 'frgn-extension')
		),
		 array(
			"type" => "textarea_html",
			"holder" => "div",
			"class" => "",
			"heading" => __("Description", 'frgn-extension'),
			"param_name" => "content",
			"value" => '',
			"description" => __("Enter description", 'frgn-extension')
		),
		array(
			"type" => "attach_image",
			"holder" => "div",
			"class" => "",
			"heading" => __("Choose image", 'frgn-extension'),
			"param_name" => "img",
			"value" => '',
			"description" => __("Choose image to illustrate the process", 'frgn-extension')
		),
		array(
			"type" => "dropdown",
			"holder" => "div",
			"class" => "",
			"heading" => __("Align Image", 'frgn-extension'),
			"param_name" => "align",
			"value" => array("left", "right"),
			"description" => __("", 'frgn-extension')
		),
      )
   ) );
}
//Fragrance Process
?>