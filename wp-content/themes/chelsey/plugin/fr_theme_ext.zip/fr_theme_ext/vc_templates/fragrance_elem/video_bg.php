<?php

//Video Pop-up
function video_pop_up( $atts, $content = null ) {
	wp_enqueue_script( 'fr_magnific_popup' );
	extract( shortcode_atts( array(
		'video_url' => '',
		'bg_img' => '',
		'btn_color' => '#cca870',
		'width' => '100%',
		'height' => '',
		'text_right' => '',
		'text_left' => '',
	), $atts ) );
   
	$img_id = preg_replace( '/[^\d]/', '', $bg_img );
	$img_url = wp_get_attachment_image_src( $img_id, 'full' );
	
	$output = "<div class='fr_video_popup_holder'>";
	$output .= "<div class='frgn_intro-title-left'><span class='intro-title'>{$text_left}</span></div>";
	$output .= "<div class='frgn_intro_title_right'><span class='intro-title'>{$text_right}</span></div>";
	$output .= "<div class='fr_video_popup frgn_video_popup_bg' style='background-image:url({$img_url[0]}); width:{$width}; height:{$height};'>";	
	$output .= "<div class='fr_video_pop_up_inner'><a class='frgn_video_popup_btn_bg mfp-iframe' href='{$video_url}' style='background-color:{$btn_color};'>" .esc_html__('Play','frgn') ."</a>";
	$output .= wpb_js_remove_wpautop($content, true);
	$output .= "</div></div></div>";
	
   return $output;
}
add_shortcode( 'video_pop_up_elem', 'video_pop_up' );

add_action( 'init', 'fr_video_pop_up' );
function fr_video_pop_up() {
   vc_map( array(
	"name" => __("Video Pop-Up", "frgn-extension"),
	"description" => "Video from youtube or vimeo in pop-up window",
	"base" => "video_pop_up_elem",
	"icon" => 'chelsey-element-icon dashicons dashicons-video-alt2',
	"class" => "",
	"category" => __('Chelsey Elements', "frgn-extension"),
	"params" => array(
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Video URL", "frgn-extension"),
			"param_name" => "video_url",
			"value" => '', 
			"description" => __("Enter video URL", "frgn-extension")
		),
		array(
			"type" => "textarea_html",
			"holder" => "div",
			"class" => "",
			"heading" => __("Text", "frgn-extension"),
			"param_name" => "content",
			"value" => 'Pressing the play button will open a pop-up a video player', 
			"description" => __("Enter your text", "frgn-extension")
		),
		array(
			"type" => "colorpicker",
			"holder" => "div",
			"class" => "",
			"heading" => __("Button Color", "frgn-extension"),
			"param_name" => "btn_color",
			"value" => '#cca870',
			"description" => __("Choose color for button", "frgn-extension")
		),
		array(
			"type" => "attach_image",
			"holder" => "img",
			"class" => "",
			"heading" => __("Background Image", "frgn-extension"),
			"param_name" => "bg_img",
			"value" => 'none',
			"description" => __("Choose image for background", "frgn-extension")
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Width", "frgn-extension"),
			"param_name" => "width",
			"value" => '100%', 
			"description" => __("By default width 100%. You can set width in % and px", "frgn-extension")
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Height", "frgn-extension"),
			"param_name" => "height",
			"value" => '', 
			"description" => __("You can set height in px", "frgn-extension")
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Text Left", "frgn-extension"),
			"param_name" => "text_left",
			"value" => '', 
			"description" => __("Enter the text to be displayed on the left.", "frgn-extension")
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Text Right", "frgn-extension"),
			"param_name" => "text_right",
			"value" => '', 
			"description" => __("Enter the text to be displayed on the right.", "frgn-extension")
		),
      )
   ) );
}
//Video Pop-up

//Pop-Up Video Block
/*function frgn_video_block( $atts, $content = null ) {
   extract( shortcode_atts( array(
	  'align_btn' => '',
	  'video_url' => '',
	  'bg_img' => '',
	  'height' => '350px',
   ), $atts ) );
	
	$img_id = preg_replace( '/[^\d]/', '', $bg_img );
	$img_url = wp_get_attachment_image_src( $img_id, 'full' );
	
	$output = "<div class='frgn_video_block fr_video_popup' style='background-image:url({$img_url[0]}); height:{$height};'>";
	$output .= "<div class='fr_video_pop_up_inner'><a class='fr_video_popup_btn mfp-iframe' href='{$video_url}' style='background-color:{$btn_color}; box-shadow: 0 0 0 {$btn_color};'><i class='pe-7s-play' ></i></a>";
	$output .= "</div></div>";
	
   return $output;
}
add_shortcode( 'add_frgn_video_block', 'frgn_video_block' );

add_action( 'init', 'frgn_video_block_vc' );
function frgn_video_block_vc() {
   vc_map( array(
	"name" => __("Pop-Up Video Block", "frgn-extension"),
	"description" => "Video popup with side button",
	"base" => "add_frgn_video_block",
	"icon" => 'chelsey-element-icon dashicons dashicons-media-video',
	"class" => "",
	"category" => __('Chelsey Elements', "frgn-extension"),
	'admin_enqueue_js' => '',
	'admin_enqueue_css' => '',
	"params" => array(	
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Video URL", "frgn-extension"),
			"param_name" => "video_url",
			"value" => '', 
			"description" => __("Enter video URL", "frgn-extension")
		),
		array(
			"type" => "attach_image",
			"holder" => "img",
			"class" => "",
			"heading" => __("Background Image", "frgn-extension"),
			"param_name" => "bg_img",
			"value" => 'none',
			"description" => __("Choose image for background", "frgn-extension")
		),	
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => __("Parallax", "frgn-extension"),
			"param_name" => "parallax",
			"value" => array(
				esc_html__("Left", "frgn-extension") => 'transform:translateY(10%)',
				esc_html__("Right", "frgn-extension") => 'transform:translateY(-10%)',
			),
			"description" => __("", "frgn-extension")
		),
      )
   ) );
}*/
//Pop-Up Video Block
?>