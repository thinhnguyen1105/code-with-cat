<?php
/**
* Single Image Shortcode
*/

if( !function_exists( 'frgn_ext_vce_single_image_shortcode' ) ) {

	function frgn_ext_vce_single_image_shortcode( $attr, $content ) {

		$output = $data = $retina_data = $el_class = $image_srcset = '' ;

		extract(
			shortcode_atts(
				array(
					'image' => '',
					'image_mode' => '',
					'retina_image' => '',
					'image_type' => 'image',
					'ids' => '',
					'image_popup_size' => 'extra-extra-large',
					'image_popup_title_caption' => 'none',
					'image_column_space' => 'auto',
					'inherit_align' => 'center',
					'title_heading_tag' => 'h3',
					'title_heading' => 'h3',
					'title_custom_font_family' => '',
					'custom_title' => '',
					'custom_caption' => '',
					'image_hover_style' => 'hover-style-1',
					'image_shape' => 'square',
					'shadow' => '',
					'zoom_effect' => 'in',
					'content_bg_color' => 'white',
					'overlay_color' => 'dark',
					'overlay_opacity' => '60',
					'link' => '',
					'link_class' => '',
					'video_link' => '',
					'video_icon_color' => 'primary-1',
					'animation' => '',
					'clipping_animation' => 'frgn-clipping-up',
					'clipping_animation_colors' => 'dark',
					'animation_delay' => '200',
					'animation_duration' => 'normal',
					'margin_bottom' => '',
					'el_class' => '',
				),
				$attr
			)
		);

		$has_link = frgn_ext_vce_has_link( $link );
		$link_attributes = frgn_ext_vce_get_link_attributes( $link, $link_class );

		$single_image_classes = array( 'frgn-element', 'frgn-image' );

		if ( !empty( $animation ) ) {
			if( 'frgn-clipping-animation' == $animation ) {
				array_push( $single_image_classes, $clipping_animation);
				array_push( $single_image_classes, 'frgn-advanced-animation');

				if( 'frgn-colored-clipping-up' == $clipping_animation || 'frgn-colored-clipping-down' == $clipping_animation || 'frgn-colored-clipping-left' == $clipping_animation || 'frgn-colored-clipping-right' == $clipping_animation ) {
					array_push( $single_image_classes, 'frgn-colored-clipping');
					$data .= ' data-clipping-color="' . esc_attr( $clipping_animation_colors ) . '"';
				}
			} else {
				array_push( $single_image_classes, 'frgn-animated-item' );
				array_push( $single_image_classes, 'frgn-duration-' . $animation_duration );
			}
			array_push( $single_image_classes, $animation);
			$data .= ' data-delay="' . esc_attr( $animation_delay ) . '"';
		}
		if( 'none' != $grayscale_effect ){
			array_push( $single_image_classes, 'frgn-' . $grayscale_effect);
		}
		if ( !empty( $el_class ) ) {
			array_push( $single_image_classes, $el_class);
		}

		array_push( $single_image_classes, 'frgn-align-' . $inherit_align );
		if( 'image-caption' == $image_type || 'image-popup-caption' == $image_type  ) {
			array_push( $single_image_classes, 'frgn-hover-item' );
			array_push( $single_image_classes, 'frgn-' . $image_hover_style );
		}

		if ( 'auto' != $image_column_space ) {
			array_push( $single_image_classes, 'frgn-image-space-' . $image_column_space );
			array_push( $single_image_classes, 'frgn-image-expand-width' );
		}

		if ( 'gallery-popup' == $image_type ) {
			array_push( $single_image_classes, 'frgn-gallery-popup' );
		}

		if ( 'image-popup' == $image_type || 'image-video-popup' == $image_type || 'gallery-popup' == $image_type || 'image-popup-caption' == $image_type ) {
			array_push( $single_image_classes, 'frgn-light-gallery' );
		}

		$single_image_classes_string = implode( ' ', $single_image_classes );

		$image_classes = array();

		$image_mode_size =  $image_mode ;
		$image_classes[] = 'attachment-' . $image_mode_size;
		$image_classes[] = 'size-' . $image_mode_size;

		$image_class_string = implode( ' ', $image_classes );

		if( 'image-caption' == $image_type || 'image-popup-caption' == $image_type  ) {
			$image_class_string = '';
		}

		$style = frgn_ext_vce_build_margin_bottom_style( $margin_bottom );


		//Image Title & Caption Color
		$text_color = 'white';
		$title_color = 'white';
		if( 'hover-style-1' == $image_hover_style ){
			$text_color = 'inherit';
			$title_color = 'inherit';
		} elseif( 'hover-style-2' == $image_hover_style || 'hover-style-3' == $image_hover_style ){
			if( 'light' == $overlay_color ) {
				$text_color = 'content';
				$title_color = 'black';
			}
		}
		if( 'hover-style-4' == $image_hover_style || 'hover-style-5' == $image_hover_style || 'hover-style-7' == $image_hover_style ){
			$text_color = 'inherit';
			if( 'white' == $content_bg_color ){
				$title_color = 'black';
			} else {
				$title_color = 'white';
			}
		}

		$image_content_classes = array( 'frgn-content' );
		if ( !empty( $custom_title ) || !empty( $custom_caption ) ) {
			if( 'hover-style-7' == $image_hover_style ){
				array_push( $image_content_classes, 'frgn-align-left');
			} else {
				array_push( $image_content_classes, 'frgn-align-center');
			}
			if( 'hover-style-4' == $image_hover_style || 'hover-style-5' == $image_hover_style || 'hover-style-7' == $image_hover_style ){
				array_push( $image_content_classes, 'frgn-box-item frgn-bg-' . $content_bg_color );
			}
		}
		$image_content_class_string = implode( ' ', $image_content_classes );

		// Image Wrapper Classes
		$image_wrapper_classes = array( 'frgn-image-wrapper', 'frgn-popup-item' );

		if ( 'square' != $image_shape ) {
			$image_wrapper_classes[] = 'frgn-' . $image_shape;
		}

		if ( !empty( $shadow ) ) {
			$image_wrapper_classes[] = 'frgn-' . $shadow;
			$image_wrapper_classes[] = 'frgn-with-shadow';
		}

		$image_wrapper_class_string = implode( ' ', $image_wrapper_classes );


		$image_popup_size_mode = frgn_ext_vce_get_image_size( $image_popup_size );

		$img_width = '100%';

		if ( !empty( $image ) ) {
			$id = preg_replace('/[^\d]/', '', $image);
			$thumb_src = wp_get_attachment_image_src( $id, $image_mode_size );
			$thumb_url = $thumb_src[0];
			$image_srcset = '';
			$img_width = $thumb_src[1];
			$full_src = wp_get_attachment_image_src( $id, $image_popup_size_mode );
			$full_url = $full_src[0];

			if ( !empty( $retina_image ) && empty( $image_mode ) ) {
				$img_retina_id = preg_replace('/[^\d]/', '', $retina_image);
				$img_retina_src = wp_get_attachment_image_src( $img_retina_id, 'full' );
				$retina_url = $img_retina_src[0];
				$image_srcset = $thumb_url . ' 1x,' . $retina_url . ' 2x';
				$image_html = frgn_ext_vce_get_attachment_image( $id, $image_mode_size , "", array( 'class' => $image_class_string, 'srcset'=> $image_srcset, 'data-column-space' => $image_column_space ) );
			} else {
				$image_html = frgn_ext_vce_get_attachment_image( $id, $image_mode_size , "", array( 'class' => $image_class_string, 'data-column-space' => $image_column_space ) );
			}

		} else {
			$full_url = frgn_ext_vce_get_fallback_image( $image_popup_size_mode, 'url' );
			$image_html = frgn_ext_vce_get_fallback_image( $image_mode_size, "", array( 'class' => $image_class_string ) );
		}

		$output .= '<div class="' . esc_attr( $single_image_classes_string ) . '" style="' . $style . '"' . $data . '>';
		if ( 'auto' != $image_column_space ){
			$output .= '<div class="' . esc_attr( $image_wrapper_class_string ) . '">';
		} else {
			$output .= '<div class="' . esc_attr( $image_wrapper_class_string ) . '" style="max-width:' . esc_attr( $img_width ) . 'px;">';
		}

		if ( 'image-popup' == $image_type ) {

			$image_title = $image_caption = "";
			if ( !empty( $image ) ) {
				$image_title = get_post_field( 'post_title', $id );
				$image_caption = get_post_field( 'post_excerpt', $id );
			}
			$data = "";
			$data_html = '';
			if ( !empty( $image_title ) && 'none' != $image_popup_title_caption && 'caption-only' != $image_popup_title_caption ) {
				$data_html .= '<span class="frgn-title">' . $image_title . '</span>';
			}
			if ( !empty( $image_caption ) && 'none' != $image_popup_title_caption && 'title-only' != $image_popup_title_caption ) {
				$data_html .= '<span class="frgn-caption">' . $image_caption . '</span>';
			}
			if ( !empty( $data_html ) ) {
				$data .= ' data-sub-html="' . esc_attr( $data_html ) . '"';
			}

			$data .= ' data-size="' . esc_attr( $full_src[1] ) . 'x' . esc_attr( $full_src[2] ) . '"';

			$output .= '<a class="frgn-item-url" href="' . esc_url( $full_url ) . '"' . $data . '></a>';
			$output .= $image_html;
		} else if ( 'gallery-popup' == $image_type ) {

			$attachments = explode( ",", $ids );
			if ( !empty( $ids ) && !empty( $attachments ) ) {
				$first_image_data = "";
				$first_image_url = "#";
				$index = 0;

				$gallery_links = "";
				$gallery_links .= '<div class="frgn-hidden">';
				foreach ( $attachments as $id ) {
					$full_src = wp_get_attachment_image_src( $id, $image_popup_size_mode );
					$full_url = $full_src[0];
					$image_title = get_post_field( 'post_title', $id );
					$image_caption = get_post_field( 'post_excerpt', $id );
					$data = "";
					$data_html = '';
					if ( !empty( $image_title ) && 'none' != $image_popup_title_caption && 'caption-only' != $image_popup_title_caption ) {
						$data_html .= '<span class="frgn-title">' . $image_title . '</span>';
					}
					if ( !empty( $image_caption ) && 'none' != $image_popup_title_caption && 'title-only' != $image_popup_title_caption ) {
						$data_html .= '<span class="frgn-caption">' . $image_caption . '</span>';
					}
					if ( !empty( $data_html ) ) {
						$data .= ' data-sub-html="' . esc_attr( $data_html ) . '"';
					}
					$data .= ' data-size="' . esc_attr( $full_src[1] ) . 'x' . esc_attr( $full_src[2] ) . '"';
					if ( 0 == $index ) {
						$first_image_data = $data;
						$first_image_url= $full_url;
					} else {
						$gallery_links .= '<a class="frgn-item-url" href="' . esc_url( $full_url ) . '"' . $data . '></a>';
					}
					$index ++;
				}
				$gallery_links .= '</div>';

				$output .= '<a class="frgn-item-url" href="' . esc_url( $first_image_url ) . '"' . $first_image_data . '></a>';
				$output .= $image_html;
				$output .= $gallery_links;
			} else {
				$output .= $image_html;
			}

		} else if ( 'image-link' == $image_type ) {
			$output .= '<a ' . implode( ' ', $link_attributes ) . '>';
			$output .= $image_html;
			$output .= '</a>';
		} else if ( 'image-video-popup' == $image_type ) {
			if ( !empty( $video_link ) ) {
				$output .= '<div class="frgn-media frgn-paraller-wrapper">';
				$output .= '	<a class="frgn-item-url frgn-video-popup" href="' . esc_url( $video_link ) . '">';
				$output .= frgn_ext_vce_get_video_icon( $video_icon_color );
				$output .= '	</a>';
				$output .= $image_html;
				$output .= '</div>';
			} else {
				$output .= '<div class="frgn-media">';
				$output .= $image_html;
				$output .= '</div>';
			}
		} else if ( 'image-caption' == $image_type || 'image-popup-caption' == $image_type ) {

			$title_classes = array( 'frgn-title' );
			$title_classes[]  = 'frgn-' . $title_heading;
			$title_classes[]  = 'frgn-text-' . $title_color;
			if ( !empty( $title_custom_font_family ) ) {
				$title_classes[]  = 'frgn-' . $title_custom_font_family;
			}
			$title_class_string = implode( ' ', $title_classes );

			if ( 'hover-style-1' == $image_hover_style ) {
				$output .= '<figure class="frgn-image-hover frgn-media frgn-zoom-' . esc_attr( $zoom_effect ) . '">';
				if ( 'image-caption' == $image_type && $has_link ) {
					$output .= '<a class="frgn-item-url" ' . implode( ' ', $link_attributes ) . '></a>';
				} elseif ( 'image-popup-caption' == $image_type ) {
					$data = "";
					$data_html = '';
					if ( !empty( $custom_title ) && 'none' != $image_popup_title_caption && 'caption-only' != $image_popup_title_caption ) {
						$data_html .= '<span class="frgn-title">' . $custom_title . '</span>';
					}
					if ( !empty( $custom_caption ) && 'none' != $image_popup_title_caption && 'title-only' != $image_popup_title_caption ) {
						$data_html .= '<span class="frgn-caption">' . $custom_caption . '</span>';
					}
					if ( !empty( $data_html ) ) {
						$data .= ' data-sub-html="' . esc_attr( $data_html ) . '"';
					}
					$data .= ' data-size="' . esc_attr( $full_src[1] ) . 'x' . esc_attr( $full_src[2] ) . '"';
					$output .= '<a class="frgn-item-url" href="' . esc_url( $full_url ) . '"' . $data . '></a>';
				}
				$output .= '<div class="frgn-bg-' . esc_attr( $overlay_color ) . ' frgn-hover-overlay  frgn-opacity-' . esc_attr( $overlay_opacity )  . '"></div>';
				$output .= $image_html;
				$output .= '<figcaption></figcaption>';
				$output .= '</figure>';
				if ( !empty( $custom_title ) || !empty( $custom_caption ) ) {
					$output .= '<div class="' . esc_attr( $image_content_class_string ) . '">';
					if ( !empty( $custom_title ) ) {
						$output .= '<' . tag_escape( $title_heading_tag ) . ' class="' . esc_attr( $title_class_string ) . '">' . esc_html( $custom_title ) . '</' . tag_escape( $title_heading_tag ) . '>';
					}
					if ( !empty( $custom_caption ) ) {
						$output .= '<span class="frgn-description frgn-link-text frgn-text-content">' . wp_kses_post( $custom_caption ) . '</span>';
					}
					$output .= '</div>';
				}
			} else {
				$output .= '<figure class="frgn-image-hover frgn-media frgn-zoom-' . esc_attr( $zoom_effect ) . '">';
				if ( 'image-caption' == $image_type && $has_link ) {
					$output .= '<a class="frgn-item-url" ' . implode( ' ', $link_attributes ) . '></a>';
				} elseif ( 'image-popup-caption' == $image_type ) {
					$output .= '<a class="frgn-item-url" href="' . esc_url( $full_url ) . '"></a>';
				}
				if( 'hover-style-6' != $image_hover_style ){
					$output .= '<div class="frgn-bg-' . esc_attr( $overlay_color ) . ' frgn-hover-overlay  frgn-opacity-' . esc_attr( $overlay_opacity )  . '"></div>';
				} else {
					$output .= '<div class="frgn-gradient-overlay frgn-gradient-' . esc_attr( $overlay_color ) . ' frgn-gradient-opacity-' . esc_attr( $overlay_opacity ) .'"></div>';				
				}
				$output .= $image_html;
				if ( !empty( $custom_title ) || !empty( $custom_caption ) ) {
					$output .= '<figcaption class="' . esc_attr( $image_content_class_string ) . '">';
					if ( !empty( $custom_title ) ) {
						$output .= '<' . tag_escape( $title_heading_tag ) . ' class="' . esc_attr( $title_class_string ) . '">' . esc_html( $custom_title ) . '</' . tag_escape( $title_heading_tag ) . '>';
					}
					if ( !empty( $custom_caption ) ) {
						$output .= '<span class="frgn-description frgn-small-text frgn-text-' . esc_attr( $text_color ) . '">' . wp_kses_post( $custom_caption ) . '</span>';
					}
					$output .= '</figcaption>';
				} else {
					$output .= '<figcaption></figcaption>';
				}
				$output .= '</figure>';
			}

		} else {
			$output .= $image_html;
		}

		$output .= '  </div>';
		$output .= '</div>';

		return $output;

	}
	add_shortcode( 'frgn_single_image', 'frgn_ext_vce_single_image_shortcode' );

}

/**
* Add shortcode to Page Builder
*/

if( !function_exists( 'frgn_ext_vce_single_image_shortcode_params' ) ) {
	function frgn_ext_vce_single_image_shortcode_params( $tag ) {
		return array(
			"name" => esc_html__( "Single Image", "frgn-extension" ),
			"description" => esc_html__( "Image or Video popup in various uses", "frgn-extension" ),
			"base" => $tag,
			"class" => "",
			"icon"      => "chelsey-element-icon dashicons dashicons-format-image",
			"category" => esc_html__( "Chelsey Elements", "js_composer" ),
			"params" => array(
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Type", "frgn-extension" ),
					"param_name" => "image_type",
					"value" => array(
						esc_html__( "Image", "frgn-extension" ) => 'image',
						esc_html__( "Image Link", "frgn-extension" ) => 'image-link',
						esc_html__( "Image Popup", "frgn-extension" ) => 'image-popup',
						esc_html__( "Image Video Popup", "frgn-extension" ) => 'image-video-popup',
						esc_html__( "Image With Caption", "frgn-extension" ) => 'image-caption',
						esc_html__( "Image Popup With Caption", "frgn-extension" ) => 'image-popup-caption',
						esc_html__( "Gallery Popup", "frgn-extension" ) => 'gallery-popup',
					),
					"description" => esc_html__( "Select your image type.", "frgn-extension" ),
					"admin_label" => true,
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Image Size", "frgn-extension" ),
					"param_name" => "image_mode",
					'value' => array(
						esc_html__( 'Full', 'frgn-extension' ) => '',
						esc_html__( 'Square', 'frgn-extension' ) => 'chelsey-square-thumb',
						esc_html__( 'Landscape Small Crop', 'frgn-extension' ) => 'landscape',
						esc_html__( 'Portrait', 'frgn-extension' ) => 'chelsey-portrait-thumb',
						esc_html__( 'Resize ( Extra Extra Large )', 'frgn-extension' ) => 'extra-extra-large',
						esc_html__( 'Resize ( Large )', 'frgn-extension' ) => 'large',
						esc_html__( 'Resize ( Medium Large )', 'frgn-extension' ) => 'medium_large',
						esc_html__( 'Resize ( Medium )', 'frgn-extension' ) => 'medium',
						//esc_html__( 'Thumbnail', 'frgn-extension' ) => 'thumbnail',
					),
					'std' => '',
					"description" => esc_html__( "Select your Image Size.", "frgn-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Image Popup Size", "frgn-extension" ),
					"param_name" => "image_popup_size",
					'value' => apply_filters( 'frgn_ext_image_options', array(
						esc_html__( 'Large' , 'frgn-extension' ) => 'large',
						esc_html__( 'Extra Extra Large' , 'frgn-extension' ) => 'extra-extra-large',
						esc_html__( 'Full' , 'frgn-extension' ) => 'full',
					) ),
					"std" => 'extra-extra-large',
					"dependency" => array( 'element' => "image_type", 'value' => array( 'image-popup', 'image-popup-caption', 'gallery-popup' ) ),
					"description" => esc_html__( "Select size for your popup image.", "frgn-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Image Popup Title & Caption Visibility", "frgn-extension" ),
					"param_name" => "image_popup_title_caption",
					'value' => array(
						esc_html__( 'None' , 'frgn-extension' ) => 'none',
						esc_html__( 'Title and Caption' , 'frgn-extension' ) => 'title-caption',
						esc_html__( 'Title Only' , 'frgn-extension' ) => 'title-only',
						esc_html__( 'Caption Only' , 'frgn-extension' ) => 'caption-only',
					),
					"dependency" => array( 'element' => "image_type", 'value' => array( 'image-popup', 'image-popup-caption', 'gallery-popup' ) ),
					"description" => esc_html__( "Define the visibility for your popup image title - caption.", "frgn-extension" ),
				),
				array(
					"type" => "attach_image",
					"heading" => esc_html__( "Image", "frgn-extension" ),
					"param_name" => "image",
					"value" => '',
					"description" => esc_html__( "Select an image.", "frgn-extension" ),
				),
				array(
					"type" => "attach_image",
					"heading" => esc_html__( "Retina Image", "frgn-extension" ),
					"param_name" => "retina_image",
					"value" => '',
					"description" => esc_html__( "Select a 2x image.", "frgn-extension" ),
					"dependency" => array( 'element' => "image_mode", 'value' => array( '' ) ),
				),
				array(
					"type"			=> "attach_images",
					"class"			=> "",
					"heading"		=> esc_html__( "Attach Images", "frgn-extension" ),
					"param_name"	=> "ids",
					"value" => '',
					"description"	=> esc_html__( "Select your gallery images.", "frgn-extension" ),
					"dependency" => array( 'element' => "image_type", 'value' => array( 'gallery-popup' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Image Column Space", "frgn-extension" ),
					"param_name" => "image_column_space",
					"value" => array(
						esc_html__( "Auto", "frgn-extension" ) => 'auto',
						esc_html__( "100%", "frgn-extension" ) => '100',
						esc_html__( "125%", "frgn-extension" ) => '125',
						esc_html__( "150%", "frgn-extension" ) => '150',
						esc_html__( "175%", "frgn-extension" ) => '175',
						esc_html__( "200%", "frgn-extension" ) => '200',
						esc_html__( "225%", "frgn-extension" ) => '225',
						esc_html__( "250%", "frgn-extension" ) => '250',
					),
					"description" => esc_html__( "Define the max width of the image on this column. Setting percentage larger than 100% the image overflows out of the column. Default is the image resolution.", "frgn-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Alignment", "frgn-extension" ),
					"param_name" => "inherit_align",
					"value" => array(
						esc_html__( "Inherit", "frgn-extension" ) => 'inherit',
						esc_html__( "Left", "frgn-extension" ) => 'left',
						esc_html__( "Right", "frgn-extension" ) => 'right',
						esc_html__( "Center", "frgn-extension" ) => 'center',
					),
					"description" => 'Inherits its value from its column text align definition.',
					"std" => 'center',
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Image shape", "frgn-extension" ),
					"param_name" => "image_shape",
					"value" => array(
						esc_html__( "Square", "frgn-extension" ) => 'square',
						esc_html__( "Radius 3px", "frgn-extension" ) => 'radius-3',
						esc_html__( "Radius 5px", "frgn-extension" ) => 'radius-5',
						esc_html__( "Radius 10px", "frgn-extension" ) => 'radius-10',
						esc_html__( "Radius 15px", "frgn-extension" ) => 'radius-15',
						esc_html__( "Radius 20px", "frgn-extension" ) => 'radius-20',
						esc_html__( "Radius 25px", "frgn-extension" ) => 'radius-25',
						esc_html__( "Radius 30px", "frgn-extension" ) => 'radius-30',
						esc_html__( "Radius 35px", "frgn-extension" ) => 'radius-35',
						esc_html__( "Circle", "frgn-extension" ) => 'circle',
					),
					"description" => '',
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Add Shadow", "frgn-extension" ),
					"param_name" => "shadow",
					"value" => array(
						esc_html__( "No", "frgn-extension" ) => '',
						esc_html__( "Small", "frgn-extension" ) => 'small-shadow',
						esc_html__( "Medium", "frgn-extension" ) => 'medium-shadow',
						esc_html__( "Large", "frgn-extension" ) => 'large-shadow',
					),
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( "Video Link", "frgn-extension" ),
					"param_name" => "video_link",
					"value" => "",
					"description" => esc_html__( "Type video URL e.g Vimeo/YouTube.", "frgn-extension" ),
					"dependency" => array( 'element' => "image_type", 'value' => array( 'image-video-popup') ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Video Icon Color", "frgn-extension" ),
					"param_name" => "video_icon_color",
					"param_holder_class" => "frgn-colored-dropdown",
					"value" => array(
						esc_html__( "Primary 1", "frgn-extension" ) => 'primary-1',
						esc_html__( "Primary 2", "frgn-extension" ) => 'primary-2',
						esc_html__( "Primary 3", "frgn-extension" ) => 'primary-3',
						esc_html__( "Primary 4", "frgn-extension" ) => 'primary-4',
						esc_html__( "Primary 5", "frgn-extension" ) => 'primary-5',
						esc_html__( "Primary 6", "frgn-extension" ) => 'primary-6',
						esc_html__( "Green", "frgn-extension" ) => 'green',
						esc_html__( "Orange", "frgn-extension" ) => 'orange',
						esc_html__( "Red", "frgn-extension" ) => 'red',
						esc_html__( "Blue", "frgn-extension" ) => 'blue',
						esc_html__( "Aqua", "frgn-extension" ) => 'aqua',
						esc_html__( "Purple", "frgn-extension" ) => 'purple',
						esc_html__( "Black", "frgn-extension" ) => 'black',
						esc_html__( "Grey", "frgn-extension" ) => 'grey',
						esc_html__( "White", "frgn-extension" ) => 'white',
					),
					"dependency" => array( 'element' => "image_type", 'value' => array( 'image-video-popup') ),
				),
				array(
					"type" => "vc_link",
					"heading" => esc_html__( "Link", "frgn-extension" ),
					"param_name" => "link",
					"value" => "",
					"description" => esc_html__( "Enter link.", "frgn-extension" ),
					"dependency" => array( 'element' => "image_type", 'value' => array( 'image-link', 'image-caption' ) ),
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( "Link Class", "frgn-extension" ),
					"param_name" => "link_class",
					"value" => "",
					"description" => esc_html__( "Enter extra class name for your link.", "frgn-extension" ),
					"dependency" => array( 'element' => "image_type", 'value' => array( 'image-link', 'image-caption' ) ),
				),
				//frgn_ext_vce_add_margin_bottom(),
				frgn_ext_vce_add_el_class(),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "CSS Animation", "frgn-extension"),
					"param_name" => "animation",
					"value" => array(
						esc_html__( "No", "frgn-extension" ) => '',
						esc_html__( "Fade In", "frgn-extension" ) => "frgn-fade-in",
						esc_html__( "Fade In Up", "frgn-extension" ) => "frgn-fade-in-up",
						esc_html__( "Fade In Up Big", "frgn-extension" ) => "frgn-fade-in-up-big",
						esc_html__( "Fade In Down", "frgn-extension" ) => "frgn-fade-in-down",
						esc_html__( "Fade In Down Big", "frgn-extension" ) => "frgn-fade-in-down-big",
						esc_html__( "Fade In Left", "frgn-extension" ) => "frgn-fade-in-left",
						esc_html__( "Fade In Left Big", "frgn-extension" ) => "frgn-fade-in-left-big",
						esc_html__( "Fade In Right", "frgn-extension" ) => "frgn-fade-in-right",
						esc_html__( "Fade In Right Big", "frgn-extension" ) => "frgn-fade-in-right-big",
						esc_html__( "Zoom In", "frgn-extension" ) => "frgn-zoom-in",
						esc_html__( "Clipping Animation", "frgn-extension" ) => "frgn-clipping-animation",
					),
					"group" => esc_html__( "Animation", 'frgn-extension' ),
					"description" => esc_html__("Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", "frgn-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "CSS Animation", "frgn-extension"),
					"param_name" => "clipping_animation",
					"value" => array(
						esc_html__( "Clipping Up", "frgn-extension" ) => "frgn-clipping-up",
						esc_html__( "Clipping Down", "frgn-extension" ) => "frgn-clipping-down",
						esc_html__( "Clipping Left", "frgn-extension" ) => "frgn-clipping-left",
						esc_html__( "Clipping Right", "frgn-extension" ) => "frgn-clipping-right",
						esc_html__( "Colored Clipping Up", "frgn-extension" ) => "frgn-colored-clipping-up",
						esc_html__( "Colored Clipping Down", "frgn-extension" ) => "frgn-colored-clipping-down",
						esc_html__( "Colored Clipping Left", "frgn-extension" ) => "frgn-colored-clipping-left",
						esc_html__( "Colored Clipping Right", "frgn-extension" ) => "frgn-colored-clipping-right",
					),
					"group" => esc_html__( "Animation", 'frgn-extension' ),
					"dependency" => array( 'element' => "animation", 'value' => array( 'frgn-clipping-animation' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Clipping Color", "frgn-extension" ),
					"param_name" => "clipping_animation_colors",
					"param_holder_class" => "frgn-colored-dropdown",
					"value" => array(
						esc_html__( "Dark", "frgn-extension" ) => 'dark',
						esc_html__( "Light", "frgn-extension" ) => 'light',
						esc_html__( "Green", "frgn-extension" ) => 'green',
						esc_html__( "Orange", "frgn-extension" ) => 'orange',
						esc_html__( "Red", "frgn-extension" ) => 'red',
						esc_html__( "Blue", "frgn-extension" ) => 'blue',
						esc_html__( "Aqua", "frgn-extension" ) => 'aqua',
						esc_html__( "Purple", "frgn-extension" ) => 'purple',
						esc_html__( "Grey", "frgn-extension" ) => 'grey',
					),
					"description" => esc_html__( "Select clipping color", "frgn-extension" ),
					"group" => esc_html__( "Animation", 'frgn-extension' ),
					"dependency" => array( 'element' => "clipping_animation", 'value' => array( 'frgn-colored-clipping-up', 'frgn-colored-clipping-down', 'frgn-colored-clipping-left', 'frgn-colored-clipping-right' ) ),
				),
				array(
					"type" => "textfield",
					'edit_field_class' => 'vc_col-sm-6',
					"heading" => esc_html__('Css Animation Delay', 'frgn-extension'),
					"param_name" => "animation_delay",
					"value" => '200',
					"description" => esc_html__( "Add delay in milliseconds.", "frgn-extension" ),
					"group" => esc_html__( "Animation", 'frgn-extension' ),
					"dependency" => array( 'element' => "animation", 'value_not_equal_to' => array( '' ) ),
				),
				array(
					"type" => "dropdown",
					'edit_field_class' => 'vc_col-sm-6',
					"heading" => esc_html__( "CSS Animation Duration", "frgn-extension"),
					"param_name" => "animation_duration",
					"value" => array(
						esc_html__( "Very Fast", "frgn-extension" ) => "very-fast",
						esc_html__( "Fast", "frgn-extension" ) => "fast",
						esc_html__( "Normal", "frgn-extension" ) => "normal",
						esc_html__( "Slow", "frgn-extension" ) => "slow",
						esc_html__( "Very Slow", "frgn-extension" ) => "very-slow",
					),
					"std" => 'normal',
					"description" => esc_html__("Select the duration for your animated element.", 'frgn-extension' ),
					"group" => esc_html__( "Animation", 'frgn-extension' ),
					"dependency" => array( 'element' => "animation", 'value_not_equal_to' => array( 'frgn-clipping-animation', '' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Title Tag", "frgn-extension" ),
					"param_name" => "title_heading_tag",
					"value" => array(
						esc_html__( "h1", "frgn-extension" ) => 'h1',
						esc_html__( "h2", "frgn-extension" ) => 'h2',
						esc_html__( "h3", "frgn-extension" ) => 'h3',
						esc_html__( "h4", "frgn-extension" ) => 'h4',
						esc_html__( "h5", "frgn-extension" ) => 'h5',
						esc_html__( "h6", "frgn-extension" ) => 'h6',
						esc_html__( "div", "frgn-extension" ) => 'div',
					),
					"description" => esc_html__( "Title Tag for SEO", "frgn-extension" ),
					"std" => 'h3',
					"dependency" => array( 'element' => "image_type", 'value' => array( 'image-caption', 'image-popup-caption' ) ),
					"group" => esc_html__( "Titles & Hovers", "frgn-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Title Size/Typography", "frgn-extension" ),
					"param_name" => "title_heading",
					"value" => array(
						esc_html__( "h1", "frgn-extension" ) => 'h1',
						esc_html__( "h2", "frgn-extension" ) => 'h2',
						esc_html__( "h3", "frgn-extension" ) => 'h3',
						esc_html__( "h4", "frgn-extension" ) => 'h4',
						esc_html__( "h5", "frgn-extension" ) => 'h5',
						esc_html__( "h6", "frgn-extension" ) => 'h6',
						esc_html__( "Leader Text", "frgn-extension" ) => 'leader-text',
						esc_html__( "Subtitle Text", "frgn-extension" ) => 'subtitle-text',
						esc_html__( "Small Text", "frgn-extension" ) => 'small-text',
						esc_html__( "Link Text", "frgn-extension" ) => 'link-text',
					),
					"description" => esc_html__( "Title size and typography, defined in Theme Options - Typography Options", "frgn-extension" ),
					"std" => 'h3',
					"dependency" => array( 'element' => "image_type", 'value' => array( 'image-caption', 'image-popup-caption' ) ),
					"group" => esc_html__( "Titles & Hovers", "frgn-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Custom Font Family", "frgn-extension" ),
					"param_name" => "title_custom_font_family",
					"value" => array(
						esc_html__( "Same as Typography", "frgn-extension" ) => '',
						esc_html__( "Custom Font Family 1", "frgn-extension" ) => 'custom-font-1',
						esc_html__( "Custom Font Family 2", "frgn-extension" ) => 'custom-font-2',
						esc_html__( "Custom Font Family 3", "frgn-extension" ) => 'custom-font-3',
						esc_html__( "Custom Font Family 4", "frgn-extension" ) => 'custom-font-4',

					),
					"description" => esc_html__( "Select a different font family, defined in Theme Options - Typography Options - Extras - Custom Font Family", "frgn-extension" ),
					"std" => '',
					"dependency" => array( 'element' => "image_type", 'value' => array( 'image-caption', 'image-popup-caption' ) ),
					"group" => esc_html__( "Titles & Hovers", "frgn-extension" ),
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( "Title", "frgn-extension" ),
					"param_name" => "custom_title",
					"value" => "",
					"description" => esc_html__( "Enter your title.", "frgn-extension" ),
					"admin_label" => true,
					"dependency" => array( 'element' => "image_type", 'value' => array( 'image-caption', 'image-popup-caption' ) ),
					"group" => esc_html__( "Titles & Hovers", "frgn-extension" ),
				),
				array(
					"type" => "textarea",
					"heading" => esc_html__( "Caption", "frgn-extension" ),
					"param_name" => "custom_caption",
					"value" => "",
					"description" => esc_html__( "Enter your caption.", "frgn-extension" ),
					"dependency" => array( 'element' => "image_type", 'value' => array( 'image-caption', 'image-popup-caption' ) ),
					"group" => esc_html__( "Titles & Hovers", "frgn-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Image Style - Hovers", "frgn-extension" ),
					"param_name" => "image_hover_style",
					'value' => array(
						esc_html__( 'Content Below Image' , 'frgn-extension' ) => 'hover-style-1',
						esc_html__( 'Top Down Animated Content' , 'frgn-extension' ) => 'hover-style-2',
						esc_html__( 'Left Right Animated Content' , 'frgn-extension' ) => 'hover-style-3',
						esc_html__( 'Static Box Content' , 'frgn-extension' ) => 'hover-style-4',
						esc_html__( 'Animated Box Content' , 'frgn-extension' ) => 'hover-style-5',
						esc_html__( 'Gradient Overlay' , 'frgn-extension' ) => 'hover-style-6',
						esc_html__( 'Animated Right Corner Box Content' , 'frgn-extension' ) => 'hover-style-7',
					),
					"description" => esc_html__( "Select the hover style for the image.", "frgn-extension" ),
					"dependency" => array( 'element' => "image_type", 'value' => array( 'image-caption', 'image-popup-caption' ) ),
					"group" => esc_html__( "Titles & Hovers", "frgn-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Content Background Color", "frgn-extension" ),
					"param_name" => "content_bg_color",
					'value' => array(
						esc_html__( 'White' , 'frgn-extension' ) => 'white',
						esc_html__( 'Black' , 'frgn-extension' ) => 'black',
					),
					"description" => esc_html__( "Select the background color for image item content.", "frgn-extension" ),
					"dependency" => array( 'element' => "image_hover_style", 'value' => array( 'hover-style-4', 'hover-style-5', 'hover-style-7' ) ),
					"group" => esc_html__( "Titles & Hovers", "frgn-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Image Zoom Effect", "frgn-extension" ),
					"param_name" => "zoom_effect",
					"value" => array(
						esc_html__( "Zoom In", "frgn-extension" ) => 'in',
						esc_html__( "Zoom Out", "frgn-extension" ) => 'out',
						esc_html__( "None", "frgn-extension" ) => 'none',
					),
					"description" => esc_html__( "Choose the image zoom effect.", "frgn-extension" ),
					"dependency" => array( 'element' => "image_type", 'value' => array( 'image-caption', 'image-popup-caption' ) ),
					"group" => esc_html__( "Titles & Hovers", "frgn-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Overlay Color", "frgn-extension" ),
					"param_name" => "overlay_color",
					"param_holder_class" => "frgn-colored-dropdown",
					"value" => array(
						esc_html__( "Dark", "frgn-extension" ) => 'dark',
						esc_html__( "Light", "frgn-extension" ) => 'light',
						esc_html__( "Primary 1", "frgn-extension" ) => 'primary-1',
						esc_html__( "Primary 2", "frgn-extension" ) => 'primary-2',
						esc_html__( "Primary 3", "frgn-extension" ) => 'primary-3',
						esc_html__( "Primary 4", "frgn-extension" ) => 'primary-4',
						esc_html__( "Primary 5", "frgn-extension" ) => 'primary-5',
						esc_html__( "Primary 6", "frgn-extension" ) => 'primary-6',
						esc_html__( "Green", "frgn-extension" ) => 'green',
						esc_html__( "Orange", "frgn-extension" ) => 'orange',
						esc_html__( "Red", "frgn-extension" ) => 'red',
						esc_html__( "Blue", "frgn-extension" ) => 'blue',
						esc_html__( "Aqua", "frgn-extension" ) => 'aqua',
						esc_html__( "Purple", "frgn-extension" ) => 'purple',
						esc_html__( "Grey", "frgn-extension" ) => 'grey',
						esc_html__( "Dark Grey", "frgn-extension" ) => 'dark-grey',
						esc_html__( "Light Grey", "frgn-extension" ) => 'light-grey',
					),
					"description" => esc_html__( "Choose the image color overlay.", "frgn-extension" ),
					"dependency" => array( 'element' => "image_type", 'value' => array( 'image-caption', 'image-popup-caption' ) ),
					"group" => esc_html__( "Titles & Hovers", "frgn-extension" ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Overlay Opacity", "frgn-extension" ),
					"param_name" => "overlay_opacity",
					"value" => array( '0', '10', '20', '30', '40', '50', '60', '70', '80', '90', '100' ),
					"std" => '60',
					"description" => esc_html__( "Choose the opacity for the overlay.", "frgn-extension" ),
					"dependency" => array( 'element' => "image_type", 'value' => array( 'image-caption', 'image-popup-caption' ) ),
					"group" => esc_html__( "Titles & Hovers", "frgn-extension" ),
				),
			),
		);
	}
}

if( function_exists( 'vc_lean_map' ) ) {
	vc_lean_map( 'frgn_single_image', 'frgn_ext_vce_single_image_shortcode_params' );
} else if( function_exists( 'vc_map' ) ) {
	$attributes = frgn_ext_vce_single_image_shortcode_params( 'frgn_single_image' );
	vc_map( $attributes );
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
