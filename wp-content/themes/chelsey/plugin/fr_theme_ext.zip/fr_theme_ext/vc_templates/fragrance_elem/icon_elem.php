<?php

//Fragrance Icon Block
function icon_block( $atts, $content = null ) {
	extract( shortcode_atts( array(
	  'icon' => 'fa-magic',
	  'block_bg' => '',
	  'bg_img' => '',
	  'font_color' => ''
	), $atts ) );
	
	$img_id = preg_replace( '/[^\d]/', '', $bg_img );
	$img_url = wp_get_attachment_image_src( $img_id, 'full' );
	
	$output = "<div class='icon_block cube flip-to-bottom'>";
	$output .= "<div class='icon_block_inner default-state' style='background-image:url({$img_url[0]}); background-color:{$block_bg}; color:{$font_color};'></div>";
	$output .= "<div class='icon_block_content active-state'>".wpb_js_remove_wpautop($content, true);
	$output .= "</div></div> <!-- end .icon_block -->";

   return $output;
}
add_shortcode( 'icon_block_elem', 'icon_block' );

add_action( 'init', 'fr_icon_block' );
function fr_icon_block() {
   vc_map( array(
	"name" => __("3D Flipping Box", "eye-q"),
	"description" => __("3D Flipping Box", "eye-q"),
	"base" => "icon_block_elem",
	"icon" => "icon_block_1",
	"class" => "separator  small",
	"category" => __('Fragrance Element', 'eye-q'),
	'admin_enqueue_js' => '',
	'admin_enqueue_css' => '',
	"params" => array(
		array(
			"type" => "textarea_html",
			"holder" => "div",
			"class" => "",
			"heading" => __("Content", "eye-q"),
			"param_name" => "content",
			"value" => '',
			"description" => __("", "eye-q")
		),
		array(
			"type" => "attach_image",
			"holder" => "div",
			"class" => "",
			"heading" => __("Background Image", "eye-q"),
			"param_name" => "bg_img",
			"value" => 'none',
			"description" => __("Choose image for background", "eye-q")
		),
		array(
			"type" => "colorpicker",
			"holder" => "div",
			"class" => "",
			"heading" => __("Block Background Color", "eye-q"),
			"param_name" => "block_bg",
			"value" => '',
			"description" => __("Choose background color", "eye-q")
		),
		array(
			"type" => "colorpicker",
			"holder" => "div",
			"class" => "",
			"heading" => __("Font Color", "eye-q"),
			"param_name" => "font_color",
			"value" => '',
			"description" => __("Choose font color", "eye-q")
		),
      )
   ) );
}
//Fragrance Icon Block

?>