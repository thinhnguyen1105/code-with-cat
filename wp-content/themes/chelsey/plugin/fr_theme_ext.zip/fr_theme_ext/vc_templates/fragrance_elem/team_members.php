<?php

//Team  Members
/*function team_members( $atts ) {
   extract( shortcode_atts( array(
      'img' => '',
	  'color' => '',
	  'name' => '',
	  'post' => '',
	  'info' => '',
	  'twitter_url' => '',
	  'facebook_url' => '',
	  'dribbble_url' => '',
	  'linkedin_url' => '',
	  'instagram_url' => '',
	  'skype_url' => '',
   ), $atts ) );
	
	$img_id = preg_replace( '/[^\d]/', '', $img );
	$img_url = wp_get_attachment_image_src( $img_id, 'full' );
	
	$output = "<div class='team_member' style='color:{$color}'>";
	$output .= "<img src='{$img_url[0]}' alt='img'/>";
	$output .= "<div class='team_info'><h4 style='color:{$color}'>{$name}</h4>";
	$output .= "<p class='team_post'>{$post}</p>";
	$output .= "<div class='team_inner'><p>{$info}</p>";
	$output .= "<a href='{$twitter_url}'><i class='fa fa-twitter'></i></a>";
	$output .= "<a href='{$facebook_url}'><i class='fa fa-facebook'></i></a>";
	$output .= "<a href='{$dribbble_url}'><i class='fa fa-dribbble'></i></a>";
	$output .= "<a href='{$linkedin_url}'><i class='fa fa-linkedin'></i></a>";
	$output .= "<a href='{$instagram_url}'><i class='fa fa-instagram'></i></a>";
	$output .= "<a href='{$skype_url}'><i class='fa fa-skype'></i></a>";
	$output .= "</div></div></div>";
	
   return $output;
}
add_shortcode( 'team_members_block', 'team_members' );

add_action( 'init', 'fr_team_members' );
function fr_team_members() {
   vc_map( array(
	"name" => __("Team", "chelsey"),
	"description" => "Team member block",
	"base" => "team_members_block",
	"icon" => "team",
	"class" => "",
	"category" => __('Chelsey Elements', 'frgn-extension'),
	'admin_enqueue_js' => '',
	'admin_enqueue_css' => '',
	"params" => array(
		 array(
			"type" => "attach_image",
			"holder" => "div",
			"class" => "",
			"heading" => __("Photo team member", "chelsey"),
			"param_name" => "img",
			"value" => '',
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Name team member", "chelsey"),
			"param_name" => "name",
			"value" => '', 
			"description" => __("", "chelsey")
		),
		array(
			"type" => "colorpicker",
			"holder" => "div",
			"class" => "",
			"heading" => __("Text color", "chelsey"),
			"param_name" => "color",
			"value" => '#fff', //Default color
			"description" => __("Choose  color", "chelsey")
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Post team member", "chelsey"),
			"param_name" => "post",
			"value" => '', 
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textarea",
			"holder" => "div",
			"class" => "",
			"heading" => __("Additional information", "chelsey"),
			"param_name" => "info",
			"value" => '', 
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Twitter URL", "chelsey"),
			"param_name" => "twitter_url",
			"value" => '', 
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Facebook URL", "chelsey"),
			"param_name" => "facebook_url",
			"value" => '', 
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Dribbble URL", "chelsey"),
			"param_name" => "dribbble_url",
			"value" => '', 
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Linkedin URL", "chelsey"),
			"param_name" => "linkedin_url",
			"value" => '', 
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Instagram URL", "chelsey"),
			"param_name" => "instagram_url",
			"value" => '', 
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Skype URL", "chelsey"),
			"param_name" => "skype_url",
			"value" => '', 
			"description" => __("", "chelsey")
		),
      )
   ) );
}*/
//Team  Members

//Team  Members Image
function team_members_img( $atts ) {
   extract( shortcode_atts( array(
      'img' => '',
	  'name' => '',
	  'post' => '',
	  'twitter_url' => '',
	  'facebook_url' => '',
	  'dribbble_url' => '',
	  'linkedin_url' => '',
	  'instagram_url' => '',
	  'skype_url' => '',
   ), $atts ) );
	
	$img_id = preg_replace( '/[^\d]/', '', $img );
	$img_url = wp_get_attachment_image_src( $img_id, 'full' );
	
	$output = "<div class='team_member_img'><div class='team_img' style='background-image: url({$img_url[0]});'></div> ";
	
	$output .= "<div class='team_inner'><p class='team_post'>{$post}</p><h4>{$name}</h4>";
	$output .= "<div class='team_info'>";
	$output .= "<a href='{$twitter_url}'>Tw</a>";
	$output .= "<a href='{$facebook_url}'>Fb</a>";
	$output .= "<a href='{$dribbble_url}'>Dr</a>";
	$output .= "<a href='{$linkedin_url}'>Lin</a>";
	$output .= "<a href='{$instagram_url}'>Ig</a>";
	$output .= "<a href='{$skype_url}'>Sk</a>";
	$output .= "</div>";
	$output .= "</div></div>";
	
   return $output;
}
add_shortcode( 'team_members_block_img', 'team_members_img' );

add_action( 'init', 'fr_team_members_img' );
function fr_team_members_img() {
   vc_map( array(
	"name" => __("Team", "chelsey"),
	"description" => "Team member block (Image)",
	"base" => "team_members_block_img",
	"icon" => 'chelsey-element-icon dashicons dashicons-businessman',
	"class" => "",
	"category" => __('Chelsey Elements', 'frgn-extension'),
	'admin_enqueue_js' => '',
	'admin_enqueue_css' => '',
	"params" => array(
		 array(
			"type" => "attach_image",
			"holder" => "img",
			"class" => "",
			"heading" => __("Photo team member", "chelsey"),
			"param_name" => "img",
			"value" => '',
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textfield",
			"holder" => "h4",
			"class" => "",
			"heading" => __("Name team member", "chelsey"),
			"param_name" => "name",
			"value" => '', 
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textfield",
			"holder" => "em",
			"class" => "",
			"heading" => __("Post team member", "chelsey"),
			"param_name" => "post",
			"value" => '', 
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Twitter URL", "chelsey"),
			"param_name" => "twitter_url",
			"value" => '', 
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Facebook URL", "chelsey"),
			"param_name" => "facebook_url",
			"value" => '', 
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Dribbble URL", "chelsey"),
			"param_name" => "dribbble_url",
			"value" => '', 
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Linkedin URL", "chelsey"),
			"param_name" => "linkedin_url",
			"value" => '', 
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Instagram URL", "chelsey"),
			"param_name" => "instagram_url",
			"value" => '', 
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Skype URL", "chelsey"),
			"param_name" => "skype_url",
			"value" => '', 
			"description" => __("", "chelsey")
		),
      )
   ) );
}
//Team  Members Image

//Team  Members 2
/*function team_members_t( $atts ) {
   extract( shortcode_atts( array(
      'img' => '',
	  'name' => '',
	  'post' => '',
	  'orientation' => '',
   ), $atts ) );
	
	$img_id = preg_replace( '/[^\d]/', '', $img );
	$img_url = wp_get_attachment_image_src( $img_id, 'full' );
	
	$output = "<div class='team_member_t clearfix {$orientation}'>";
	$output .= "<img src='{$img_url[0]}' alt='img'/>";
	$output .= "<h4>{$name}</h4>";
	$output .= "<p class='team_post'>{$post}</p>";
	$output .= "</div>";
	
   return $output;
}
add_shortcode( 'team_members_block_t', 'team_members_t' );

add_action( 'init', 'fr_team_members_t' );
function fr_team_members_t() {
   vc_map( array(
	"name" => __("Team (Third Variant)"),
	"description" => "Team member block (Third Variant, Round Avatar)",
	"base" => "team_members_block_t",
	"icon" => "team_image",
	"class" => "",
	"category" => __('Chelsey Elements', 'frgn-extension'),
	'admin_enqueue_js' => '',
	'admin_enqueue_css' => '',
	"params" => array(
		 array(
			"type" => "attach_image",
			"holder" => "div",
			"class" => "",
			"heading" => __("Photo team member", "chelsey"),
			"param_name" => "img",
			"value" => '',
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Name team member", "chelsey"),
			"param_name" => "name",
			"value" => '', 
			"description" => __("", "chelsey")
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Post team member", "chelsey"),
			"param_name" => "post",
			"value" => '', 
			"description" => __("", "chelsey")
		),
		array(
			"type" => "dropdown",
			"holder" => "div",
			"class" => "",
			"heading" => __("Orientation", "chelsey"),
			"param_name" => "orientation",
			"value" => array("vertical","horizontal"), 
			"description" => __("", "chelsey")
		),
      )
   ) );
}*/
//Team  Members 2

?>