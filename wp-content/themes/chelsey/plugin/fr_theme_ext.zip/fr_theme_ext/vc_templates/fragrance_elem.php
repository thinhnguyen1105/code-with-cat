<?php

require_once('fragrance_elem/title.php');
require_once('fragrance_elem/team_members.php');
require_once('fragrance_elem/video_bg.php');
require_once('fragrance_elem/single_image.php');
require_once('fragrance_elem/blocks.php');
require_once('fragrance_elem/testimonials.php');
//require_once('fragrance_elem/process.php');


//Fragrance Bg Text
function bg_text( $atts ) {
	extract( shortcode_atts( array(
		'text' => '',
		'stroke_color' => '#000',
		'font_size' => '200',
		'position_top' => '0',
		'position_left' => '60%',
		'position' => '999',
		'responsive_tablet' => '',
		'responsive_tablet_portrait' => '',
		'responsive_mobile_landscape' => '',
		'responsive_mobile' => '',
		'responsive_top_tablet' => '',
		'responsive_top_tablet_portrait' => '',
		'responsive_top_mobile_landscape' => '',
		'responsive_top_mobile' => '',
		'responsive_left_tablet' => '',
		'responsive_left_tablet_portrait' => '',
		'responsive_left_mobile_landscape' => '',
		'responsive_left_mobile' => '',
		'animation' => '',
		'clipping_animation' => 'frgn-clipping-up',
		'clipping_animation_colors' => 'dark',
		'animation_delay' => '200',
		'animation_duration' => 'normal',
		'el_class' => '',
	), $atts ) );
	
	$single_image_classes = array( 'frgn-element' );
	
	if ( !empty( $animation ) ) {
		if( 'frgn-clipping-animation' == $animation ) {
			array_push( $single_image_classes, $clipping_animation);
			array_push( $single_image_classes, 'frgn-advanced-animation');

			if( 'frgn-colored-clipping-up' == $clipping_animation || 'frgn-colored-clipping-down' == $clipping_animation || 'frgn-colored-clipping-left' == $clipping_animation || 'frgn-colored-clipping-right' == $clipping_animation ) {
				array_push( $single_image_classes, 'frgn-colored-clipping');
				$data .= ' data-clipping-color="' . esc_attr( $clipping_animation_colors ) . '"';
			}
		} else {
			array_push( $single_image_classes, 'frgn-animated-item' );
			array_push( $single_image_classes, 'frgn-duration-' . $animation_duration );
		}
		array_push( $single_image_classes, $animation);
		$data .= ' data-delay="' . esc_attr( $animation_delay ) . '"';
	}
	
	$single_image_classes_string = implode( ' ', $single_image_classes );
	
	// Image Wrapper Classes
		$image_wrapper_classes = array( 'frgn-image-wrapper', 'frgn-popup-item' );

		$image_wrapper_class_string = implode( ' ', $image_wrapper_classes );
	
	$output = "<div class='frgn_bg_text_holder frgn_text_stroke {$single_image_classes_string}' style='top:{$position_top}; text-stroke-color:{$stroke_color}; -webkit-text-stroke-color:{$stroke_color}; left:{$position_left}; font-size:{$font_size}px; z-index:{$position};' data-tablet='{$responsive_tablet}' data-tablet-portrait='{$responsive_tablet_portrait}' data-mobile-landscape='{$responsive_mobile_landscape}' data-mobile='{$responsive_mobile}' data-top-tablet='{$responsive_top_tablet} data-top-portrait='{$responsive_top_tablet_portrait}' data-top-mobile-landscape='{$responsive_top_mobile_landscape}' data-top-mobile='{$responsive_top_mobile}' data-left-tablet='{$responsive_left_tablet}' data-left-portrait='{$responsive_left_tablet_portrait}' data-left-mobile-landscape='{$responsive_left_mobile_landscape}' data-left-mobile='{$responsive_left_mobile}' {$data} >";
	$output .= "<div class='" . esc_attr( $image_wrapper_class_string ) . "'>";
	$output .= "<div class='frgn_bg_text_inner'>{$text}</div></div></div>";
	//$output .= $frgn_custom_css;

   return $output;
}
add_shortcode( 'bg_text_elem', 'bg_text' );

add_action( 'init', 'frgn_bg_text' );
function frgn_bg_text() {
   vc_map( array(
	"name" => __("Background Text", "frgn-extension"),
	"base" => "bg_text_elem",
	"icon" => 'chelsey-element-icon dashicons dashicons-editor-bold',
	"class" => "bg_text",
	"category" => __('Chelsey Elements', 'frgn-extension'),
	'admin_enqueue_js' => '',
	'admin_enqueue_css' => '',
	"params" => array(
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Text", "frgn-extension"),
			"param_name" => "text",
			"value" => '',
			"description" => __("", "frgn-extension")
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Font Size", "frgn-extension"),
			"param_name" => "font_size",
			"value" => '',
			"description" => __("", "frgn-extension")
		),
		array(
			"type" => "colorpicker",
			"class" => "",
			"heading" => __("Stroke Color", "frgn-extension"),
			"param_name" => "stroke_color",
			"value" => '',
			"description" => __("Choose stroke color", "frgn-extension")
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Position Top", "frgn-extension"),
			"param_name" => "position_top",
			"value" => '',
			"description" => __("You can use any number with px, em, %, etc.", "frgn-extension")
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Position Left", "frgn-extension"),
			"param_name" => "position_left",
			"value" => '',
			"description" => __("You can use any number with px, em, %, etc.", "frgn-extension")
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => __("Position", "frgn-extension"),
			"param_name" => "position",
			"value" => array(
				esc_html__("Above Content", "frgn-extension") => '999',
				esc_html__("Under Content", "frgn-extension") => '-1',
			),
			"description" => __("Select position relative to content", "frgn-extension")
		),
		frgn_ext_vce_add_el_class(),
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "CSS Animation", "frgn-extension"),
			"param_name" => "animation",
			"value" => array(
				esc_html__( "No", "frgn-extension" ) => '',
				esc_html__( "Fade In", "frgn-extension" ) => "frgn-fade-in",
				esc_html__( "Fade In Up", "frgn-extension" ) => "frgn-fade-in-up",
				esc_html__( "Fade In Up Big", "frgn-extension" ) => "frgn-fade-in-up-big",
				esc_html__( "Fade In Down", "frgn-extension" ) => "frgn-fade-in-down",
				esc_html__( "Fade In Down Big", "frgn-extension" ) => "frgn-fade-in-down-big",
				esc_html__( "Fade In Left", "frgn-extension" ) => "frgn-fade-in-left",
				esc_html__( "Fade In Left Big", "frgn-extension" ) => "frgn-fade-in-left-big",
				esc_html__( "Fade In Right", "frgn-extension" ) => "frgn-fade-in-right",
				esc_html__( "Fade In Right Big", "frgn-extension" ) => "frgn-fade-in-right-big",
				esc_html__( "Zoom In", "frgn-extension" ) => "frgn-zoom-in",
				esc_html__( "Clipping Animation", "frgn-extension" ) => "frgn-clipping-animation",
				esc_html__( "Appear Animation", "frgn-extension" ) => "frgn-appear-animation",
			),
			"group" => esc_html__( "Animation", 'frgn-extension' ),
			"description" => esc_html__("Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", "frgn-extension" ),
		),
		array(
					"type" => "dropdown",
					"heading" => esc_html__( "CSS Animation", "frgn-extension"),
					"param_name" => "clipping_animation",
					"value" => array(
						esc_html__( "Clipping Up", "frgn-extension" ) => "frgn-clipping-up",
						esc_html__( "Clipping Down", "frgn-extension" ) => "frgn-clipping-down",
						esc_html__( "Clipping Left", "frgn-extension" ) => "frgn-clipping-left",
						esc_html__( "Clipping Right", "frgn-extension" ) => "frgn-clipping-right",
						esc_html__( "Colored Clipping Up", "frgn-extension" ) => "frgn-colored-clipping-up",
						esc_html__( "Colored Clipping Down", "frgn-extension" ) => "frgn-colored-clipping-down",
						esc_html__( "Colored Clipping Left", "frgn-extension" ) => "frgn-colored-clipping-left",
						esc_html__( "Colored Clipping Right", "frgn-extension" ) => "frgn-colored-clipping-right",
					),
					"group" => esc_html__( "Animation", 'frgn-extension' ),
					"dependency" => array( 'element' => "animation", 'value' => array( 'frgn-clipping-animation' ) ),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( "Clipping Color", "frgn-extension" ),
					"param_name" => "clipping_animation_colors",
					"param_holder_class" => "frgn-colored-dropdown",
					"value" => array(
						esc_html__( "Dark", "frgn-extension" ) => 'dark',
						esc_html__( "Light", "frgn-extension" ) => 'light',
						esc_html__( "Primary 1", "frgn-extension" ) => 'primary-1',
						esc_html__( "Primary 2", "frgn-extension" ) => 'primary-2',
						esc_html__( "Primary 3", "frgn-extension" ) => 'primary-3',
						esc_html__( "Primary 4", "frgn-extension" ) => 'primary-4',
						esc_html__( "Primary 5", "frgn-extension" ) => 'primary-5',
						esc_html__( "Primary 6", "frgn-extension" ) => 'primary-6',
						esc_html__( "Green", "frgn-extension" ) => 'green',
						esc_html__( "Orange", "frgn-extension" ) => 'orange',
						esc_html__( "Red", "frgn-extension" ) => 'red',
						esc_html__( "Blue", "frgn-extension" ) => 'blue',
						esc_html__( "Aqua", "frgn-extension" ) => 'aqua',
						esc_html__( "Purple", "frgn-extension" ) => 'purple',
						esc_html__( "Grey", "frgn-extension" ) => 'grey',
					),
					"description" => esc_html__( "Select clipping color", "frgn-extension" ),
					"group" => esc_html__( "Animation", 'frgn-extension' ),
					"dependency" => array( 'element' => "clipping_animation", 'value' => array( 'frgn-colored-clipping-up', 'frgn-colored-clipping-down', 'frgn-colored-clipping-left', 'frgn-colored-clipping-right' ) ),
				),
				array(
					"type" => "textfield",
					'edit_field_class' => 'vc_col-sm-6',
					"heading" => esc_html__('Css Animation Delay', 'frgn-extension'),
					"param_name" => "animation_delay",
					"value" => '200',
					"description" => esc_html__( "Add delay in milliseconds.", "frgn-extension" ),
					"group" => esc_html__( "Animation", 'frgn-extension' ),
					"dependency" => array( 'element' => "animation", 'value_not_equal_to' => array( '' ) ),
				),
				array(
					"type" => "dropdown",
					'edit_field_class' => 'vc_col-sm-6',
					"heading" => esc_html__( "CSS Animation Duration", "frgn-extension"),
					"param_name" => "animation_duration",
					"value" => array(
						esc_html__( "Very Fast", "frgn-extension" ) => "very-fast",
						esc_html__( "Fast", "frgn-extension" ) => "fast",
						esc_html__( "Normal", "frgn-extension" ) => "normal",
						esc_html__( "Slow", "frgn-extension" ) => "slow",
						esc_html__( "Very Slow", "frgn-extension" ) => "very-slow",
					),
					"std" => 'normal',
					"description" => esc_html__("Select the duration for your animated element.", 'frgn-extension' ),
					"group" => esc_html__( "Animation", 'frgn-extension' ),
					"dependency" => array( 'element' => "animation", 'value_not_equal_to' => array( 'frgn-clipping-animation', '' ) ),
				),
		frgn_ext_vce_add_el_class(),
		array(
			"type" => "text",
			"heading" => "<h4>".__("Enter values with respective unites. Example - 10px, 10em, 10%, etc.","frgn-extension")."</h4>",
			"param_name" => "margin_design_tab_text",
			"group" => "Responsive Options",
		),
		array(
			"type" => "ult_param_heading",
			"text" => __("Font Size Responsive Settings","frgn-extension"),
			"param_name" => "main_heading_typograpy",
			"group" => "Responsive Options",
			"class" => "ult-param-heading",
			'edit_field_class' => 'ult-param-heading-wrapper no-top-margin vc_column vc_col-sm-12',
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__( "Tablet", "frgn-extension"),
			"param_name" => "responsive_tablet",
			"value" => '',
			"group" => esc_html__( "Responsive Options", 'frgn-extension' ),
			"edit_field_class" => "vc_col-sm-3",
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__( "Tablet Portrait", "frgn-extension"),
			"param_name" => "responsive_tablet_portrait",
			"value" => '',
			"group" => esc_html__( "Responsive Options", 'frgn-extension' ),
			"edit_field_class" => "vc_col-sm-3",
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__( "Mobile Landscape", "frgn-extension"),
			"param_name" => "responsive_mobile_landscape",
			"value" => '',
			"group" => esc_html__( "Responsive Options", 'frgn-extension' ),
			"edit_field_class" => "vc_col-sm-3",
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__( "Mobile", "frgn-extension"),
			"param_name" => "responsive_mobile",
			"value" => '',
			"group" => esc_html__( "Responsive Options", 'frgn-extension' ),
			"edit_field_class" => "vc_col-sm-3",
		),
		array(
			"type" => "ult_param_heading",
			"text" => __("Top Position Responsive Settings","frgn-extension"),
			"param_name" => "main_heading_typograpy",
			"group" => "Responsive Options",
			"class" => "ult-param-heading",
			'edit_field_class' => 'ult-param-heading-wrapper no-top-margin vc_column vc_col-sm-12',
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__( "Tablet", "frgn-extension"),
			"param_name" => "responsive_top_tablet",
			"value" => '',
			"group" => esc_html__( "Responsive Options", 'frgn-extension' ),
			"edit_field_class" => "vc_col-sm-3",
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__( "Tablet Portrait", "frgn-extension"),
			"param_name" => "responsive_top_tablet_portrait",
			"value" => '',
			"group" => esc_html__( "Responsive Options", 'frgn-extension' ),
			"edit_field_class" => "vc_col-sm-3",
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__( "Mobile Landscape", "frgn-extension"),
			"param_name" => "responsive_top_mobile_landscape",
			"value" => '',
			"group" => esc_html__( "Responsive Options", 'frgn-extension' ),
			"edit_field_class" => "vc_col-sm-3",
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__( "Mobile", "frgn-extension"),
			"param_name" => "responsive_top_mobile",
			"value" => '',
			"group" => esc_html__( "Responsive Options", 'frgn-extension' ),
			"edit_field_class" => "vc_col-sm-3",
		),
		array(
			"type" => "ult_param_heading",
			"text" => __("Left Position Responsive Settings","frgn-extension"),
			"param_name" => "main_heading_typograpy",
			"group" => "Responsive Options",
			"class" => "ult-param-heading",
			'edit_field_class' => 'ult-param-heading-wrapper vc_column vc_col-sm-12',
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__( "Tablet", "frgn-extension"),
			"param_name" => "responsive_left_tablet",
			"value" => '',
			"group" => esc_html__( "Responsive Options", 'frgn-extension' ),
			"edit_field_class" => "vc_col-sm-3",
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__( "Tablet Portrait", "frgn-extension"),
			"param_name" => "responsive_left_tablet_portrait",
			"value" => '',
			"group" => esc_html__( "Responsive Options", 'frgn-extension' ),
			"edit_field_class" => "vc_col-sm-3",
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__( "Mobile Landscape", "frgn-extension"),
			"param_name" => "responsive_left_mobile_landscape",
			"value" => '',
			"group" => esc_html__( "Responsive Options", 'frgn-extension' ),
			"edit_field_class" => "vc_col-sm-3",
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__( "Mobile", "frgn-extension"),
			"param_name" => "responsive_left_mobile",
			"value" => '',
			"group" => esc_html__( "Responsive Options", 'frgn-extension' ),
			"edit_field_class" => "vc_col-sm-3",
		),
      )
   ) );
}
//Fragrance Bg Text

//Fragrance Stroke Text
function stroke_text( $atts ) {
	extract( shortcode_atts( array(
	  'text' => '',
	  'font_size' => '120',
	  'align' => 'left',
	), $atts ) );
	
	$output = "<div class='frgn_stroke_text_holder frgn_text_stroke {$align}' style='font-size:{$font_size}px;'><div class='frgn_stroke_text_inner'>{$text}</div></div>";

   return $output;
}
add_shortcode( 'stroke_text_elem', 'stroke_text' );

add_action( 'init', 'frgn_stroke_text' );
function frgn_stroke_text() {
   vc_map( array(
	"name" => __("Stroke Text", "frgn-extension"),
	"base" => "stroke_text_elem",
	"icon" => 'chelsey-element-icon dashicons dashicons-star-empty',
	"class" => "stroke_text",
	"category" => __('Chelsey Elements', 'frgn-extension'),
	'admin_enqueue_js' => '',
	'admin_enqueue_css' => '',
	"params" => array(
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Text", "frgn-extension"),
			"param_name" => "text",
			"value" => '',
			"description" => __("", "frgn-extension")
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Font Size", "frgn-extension"),
			"param_name" => "font_size",
			"value" => '',
			"description" => __("", "frgn-extension")
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => __("Align", "frgn-extension"),
			"param_name" => "align",
			"value" => array(
				esc_html__("Left", "frgn-extension") => 'text-left',
				esc_html__("Right", "frgn-extension") => 'text-right',
				esc_html__("Center", "frgn-extension") => 'text-center',
			),
			"description" => __("", "frgn-extension")
		),
      )
   ) );
}
//Fragrance Stroke Text

//Fragrance Btn
function arrow_btn( $atts ) {
	extract( shortcode_atts( array(
	  'link_url' => '#',
	  'link_text' => 'See More',
	  'font_color' => '',
	  'align' => 'text-left',
	), $atts ) );
	
	$output = "<div class='frgn_btn_holder {$align}'><a href='{$link_url}''><span>{$link_text}</span></a></div>";

   return $output;
}
add_shortcode( 'arrow_btn_elem', 'arrow_btn' );

add_action( 'init', 'frgn_arrow_btn' );
function frgn_arrow_btn() {
   vc_map( array(
	"name" => __("Chelsey Button", "frgn-extension"),
	"base" => "arrow_btn_elem",
	"icon" => 'chelsey-element-icon dashicons dashicons-editor-removeformatting',
	"class" => "arrow_btn",
	"category" => __('Chelsey Elements', 'frgn-extension'),
	'admin_enqueue_js' => '',
	'admin_enqueue_css' => '',
	"params" => array(
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Link URL", "frgn-extension"),
			"param_name" => "link_url",
			"value" => '',
			"description" => __("", "frgn-extension")
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Link Text", "frgn-extension"),
			"param_name" => "link_text",
			"value" => '',
			"description" => __("", "frgn-extension")
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => __("Align Button", "frgn-extension"),
			"param_name" => "align",
			"value" => array(
				esc_html__("Left", "frgn-extension") => 'text-left',
				esc_html__("Right", "frgn-extension") => 'text-right',
				esc_html__("Center", "frgn-extension") => 'text-center',
			),
			"description" => __("", "frgn-extension")
		),
      )
   ) );
}
//Fragrance Btn


//Fragrance Fun Fucts
function fun_fucts( $atts ) {
	extract( shortcode_atts( array(
	  'count' => 'Enter number of fact',
	  'fucts_name' => '',
	  'font_color' => '',
	  'symbol' => '',
	  'align' => '',
	), $atts ) );
	
	$output = '';
	$output .= "<div class='fucts_counter {$align}' data-perc={$count}>";
	$output .= "<span class='fucts_count highlight' style='color:{$font_color}'>{$count}</span><span class='fucts_symbol' style='color:{$font_color}'>{$symbol}</span>";
	$output .= "<h5 class='fucts_name' style='color:{$font_color}'>{$fucts_name}</h5>";
	$output .= '</div>';

   return $output;
}
add_shortcode( 'fun_fucts_elem', 'fun_fucts' );

add_action( 'init', 'funfucts' );
function funfucts() {
   vc_map( array(
	"name" => __("Fun fucts", "frgn-extension"),
	"base" => "fun_fucts_elem",
	"icon" => 'chelsey-element-icon dashicons dashicons-smiley',
	"class" => "fun_fucts",
	"category" => __('Chelsey Elements', 'frgn-extension'),
	'admin_enqueue_js' => '',
	'admin_enqueue_css' => '',
	"params" => array(
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Fucts icon", "frgn-extension"),
			"param_name" => "icon",
			"value" => '',
			"description" => __("Paste class of fontasome icon", "frgn-extension")
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Fucts name", "frgn-extension"),
			"param_name" => "fucts_name",
			"value" => '',
			"description" => __("Enter your fuct name", "frgn-extension")
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Number of fact", "frgn-extension"),
			"param_name" => "count",
			"value" => '',
			"description" => __("Enter number of fact", "frgn-extension")
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Symbol of fact", "frgn-extension"),
			"param_name" => "symbol",
			"value" => '',
			"description" => __("Enter symbol of fact. You can use %, &copy; , &deg; etc", "frgn-extension")
		),
		array(
			"type" => "colorpicker",
			"holder" => "div",
			"class" => "",
			"heading" => __("Font color", "frgn-extension"),
			"param_name" => "font_color",
			"value" => '',
			"description" => __("Choose font color", "frgn-extension")
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => __("Align", "frgn-extension"),
			"param_name" => "align",
			"value" => array(
				esc_html__("Left", "frgn-extension") => 'text-left',
				esc_html__("Right", "frgn-extension") => 'text-right',
				esc_html__("Center", "frgn-extension") => 'text-center',
			),
			"description" => __("", "frgn-extension")
		),
      )
   ) );
}
//Fragrance Fun Fucts

//Clients
function client( $atts ) {
	extract( shortcode_atts( array(
	  'link_url' => 'Enter Link URL',
	  'img' => '',
	), $atts ) );
	
	$img_id = preg_replace( '/[^\d]/', '', $img );
	$img_url = wp_get_attachment_image_src( $img_id, 'full' );
	
	$img_hover_id = preg_replace( '/[^\d]/', '', $hover_img );
	
	$output = "<div class='frgn_client_holder {$align}'><a href='{$link_url}'><span><img src='{$img_url[0]}' alt='img' /></span></a></div>";

   return $output;
}
add_shortcode( 'client_elem', 'client' );

add_action( 'init', 'frgn_client' );
function frgn_client() {
   vc_map( array(
	"name" => __("Chelsey Client", "frgn-extension"),
	"base" => "client_elem",
	"icon" => 'chelsey-element-icon dashicons dashicons-smiley',
	"class" => "client",
	"category" => __('Chelsey Elements', 'frgn-extension'),
	'admin_enqueue_js' => '',
	'admin_enqueue_css' => '',
	"params" => array(
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => __("Link URL", "frgn-extension"),
			"param_name" => "link_url",
			"value" => '',
			"description" => __("", "frgn-extension")
		),
		array(
			"type" => "attach_image",
			"class" => "",
			"heading" => __("Image", "frgn-extension"),
			"param_name" => "img",
			"value" => '',
			"description" => __("Attach client logo", "frgn-extension")
		),
      )
   ) );
}
//Clients

// Fragrance Parallax Block
/*function parallax_block( $atts, $content = null ) {
    extract( shortcode_atts( array(
		'img' => '',
		'title' => '',
		'button_text' => 'View Case',
		'button_link' => '#',
		
    ), $atts ) );
	
	$img_id = preg_replace( '/[^\d]/', '', $img );
	$img_url = wp_get_attachment_image_src( $img_id, 'full' );
	
	$output = "<div class='fr_frgn_parallax_block'>";
	$output .= "<div class='fr_frgn_parallax_image_holder'><img src='{$img_url[0]}' alt='img' /></div>";
	$output .= "<div class='fr_frgn_parallax_text_holder' data-bottom='transform:translateY(10%)' data-center-bottom='transform:translateY(0%)'><h2>{$title}</h2><div class='desc'>".wpb_js_remove_wpautop($content, true);
	$output .= "</div>";
	$output .= "<a href='{$button_link}' class='frgn_more'>{$button_text}</a>";
	$output .= "</div></div>";
	
    return $output;
}
add_shortcode( 'fr_frgn_parallax_block', 'parallax_block' );

add_action( 'init', 'frgn_parallax_block_func' );
function frgn_parallax_block_func() {
   vc_map( array(
    "name" => __("Parallax Block Image Left", "frgn-extension"),
    "base" => "fr_frgn_parallax_block",
	"icon" => 'chelsey-element-icon dashicons dashicons-image-rotate-right',
    "class" => "fr_frgn_parallax_block",
    "category" => __('Chelsey Elements', 'frgn-extension'),
    'admin_enqueue_js' => '',
    'admin_enqueue_css' => '',
    "params" => array(
		array(
			"type" => "attach_image",
			"holder" => "div",
			"class" => "",
			"heading" => __("Image", "frgn-extension"),
			"param_name" => "img",
			"value" => '',
			"description" => __("", "frgn-extension")
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Title", "frgn-extension"),
			"param_name" => "title",
			"value" => "",
			"description" => __("", "frgn-extension")
		),
		array(
            "type" => "textarea_html",
            "holder" => "div",
            "class" => "",
            "heading" => __("Description", "frgn-extension"),
            "param_name" => "content",
            "value" => '',
            "description" => __("", "frgn-extension")
        ),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Button link", "frgn-extension"),
			"param_name" => "button_link",
			"value" => "#",
			"description" => __("", "frgn-extension")
		),  
		array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Button text", "frgn-extension"),
            "param_name" => "button_text",
            "value" => 'View Case',
            "description" => __("", "frgn-extension")
        ),
      )
   ) );
}*/
// Fragrance Parallax Block

// Fragrance Parallax Block
/*function parallax_block_img_right( $atts, $content = null ) {
    extract( shortcode_atts( array(
		'img' => '',
		'title' => '',
		'button_text' => 'View Case',
		'button_link' => '#',
		
    ), $atts ) );
	
	$img_id = preg_replace( '/[^\d]/', '', $img );
	$img_url = wp_get_attachment_image_src( $img_id, 'full' );
	
	$output = "<div class='fr_frgn_parallax_block_img_right'>";
	$output .= "<div class='fr_frgn_parallax_text_holder' data-bottom='transform:translateY(10%)' data-center-bottom='transform:translateY(0%)'><h2>{$title}</h2><div class='desc'>".wpb_js_remove_wpautop($content, true);
	$output .= "</div>";
	$output .= "<a href='{$button_link}' class='frgn_more'>{$button_text}</a>";
	$output .= "</div>";
	$output .= "<div class='fr_frgn_parallax_image_holder'><img src='{$img_url[0]}' alt='img' /></div></div>";
	
    return $output;
}
add_shortcode( 'fr_frgn_parallax_block_img_right', 'parallax_block_img_right' );

add_action( 'init', 'frgn_parallax_block_func_img_right' );
function frgn_parallax_block_func_img_right() {
   vc_map( array(
    "name" => __("Parallax Block Image Right", "frgn-extension"),
    "base" => "fr_frgn_parallax_block_img_right",
	"icon" => 'chelsey-element-icon dashicons dashicons-image-rotate-left',
    "class" => "fr_frgn_parallax_block_img_right",
    "category" => __('Chelsey Elements', 'frgn-extension'),
    'admin_enqueue_js' => '',
    'admin_enqueue_css' => '',
    "params" => array(
		array(
			"type" => "attach_image",
			"holder" => "div",
			"class" => "",
			"heading" => __("Image", "frgn-extension"),
			"param_name" => "img",
			"value" => '',
			"description" => __("", "frgn-extension")
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Title", "frgn-extension"),
			"param_name" => "title",
			"value" => "",
			"description" => __("", "frgn-extension")
		),
		array(
            "type" => "textarea_html",
            "holder" => "div",
            "class" => "",
            "heading" => __("Description", "frgn-extension"),
            "param_name" => "content",
            "value" => '',
            "description" => __("", "frgn-extension")
        ),
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => __("Button link", "frgn-extension"),
			"param_name" => "button_link",
			"value" => "#",
			"description" => __("", "frgn-extension")
		),  
		array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __("Button text", "frgn-extension"),
            "param_name" => "button_text",
            "value" => 'View Case',
            "description" => __("", "frgn-extension")
        ),
      )
   ) );
}*/
// Fragrance Parallax Block
