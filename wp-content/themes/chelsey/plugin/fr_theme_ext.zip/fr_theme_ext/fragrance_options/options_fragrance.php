<?php
global $chelsey_mainTabs, $chelsey_themename, $chelsey_shortname, $chelsey_options, $chelsey_add_google_fonts, $chelsey_menus_style;

$chelsey_mainTabs = array('general', 'head', 'typography', 'contact', 'social-network', 'footer');

$chelsey_add_google_fonts = apply_filters( 'chelsey_add_google_fonts', array('Colaborate Thin', 'Kreon','Droid Sans','Droid Serif','Lobster','Yanone Kaffeesatz','Nobile','Crimson Text','Arvo','Tangerine','Cuprum','Cantarell','Philosopher','Josefin Sans','Dancing Script','Raleway','Bentham','Goudy Bookletter 1911','Quattrocento','Ubuntu','PT Sans','Arimo','Bevan','Bigshot One','Yeseva One' ,'Abel', 'Open Sans', 'Dosis', 'Dorsa', 'Bree Serif', 'Pacifico', 'PT Sans Narrow','Lato' ,'Molengo', 'Trocchi', 'Lusitana', 'Brawler', 'Patua One' ,'Alegreya SC' ,'Alike', 'Gentium Basic','Rokkitt' ,'Ovo', 'Georgia', 'Museo Slab', 'Brandon', 'Muli', 'Sintony', 'Roboto', 'Montserrat', 'Palatino Linotype', 'Crete Round', 'Lora', 'Playfair Display', 'Source Sans Pro', 'PT Serif', 'Rubik', 'Nunito', 'Oswald', 'Kaushan Script') );
sort($chelsey_add_google_fonts);

$chelsey_menus_style = array(esc_html__('Classic Top Menu',"chelsey"), esc_html__('Side Menu',"chelsey"), esc_html__('Vertical Menu',"chelsey"));

$chelsey_text_transform = array(esc_html__('None',"chelsey"), esc_html__('Capitalize',"chelsey"), esc_html__('Uppercase',"chelsey"), esc_html__('Lowercase',"chelsey"), esc_html__('Initial',"chelsey"), esc_html__('Inherit',"chelsey"));

$chelsey_options = array (

	array( "name" => "wrap-general",
		   "type" => "contenttab-wrapstart",),

		array( "type" => "subnavtab-start",),

			array( "name" => "general-1", "type" => "subnav-tab", "desc" => esc_html__("General Options","chelsey")),

		array( "type" => "subnavtab-end",),

		array( "name" => "general-1",
			   "type" => "subcontent-start",),
			   			
			array( "name" => esc_html__("Logo","chelsey"),
				   "id" => "FRGN_SITE_LOGO_SMALL",
				   "type" => "upload",
				   "std" => "",
				   "desc" => esc_html__("Upload here your logo image. Size is not more 70x27","chelsey")
			),
			
			array( "name" => esc_html__("Mobile Logo","chelsey"),
				   "id" => "FRGN_SITE_LOGO_MOBILE",
				   "type" => "upload",
				   "std" => "",
				   "desc" => esc_html__("Upload here your logo image, which will be displayed on mobile devices.","chelsey")
			),
			
			array( "name" => esc_html__("Color Scheme","chelsey"),
				   "id" =>"FRGN_COLOR_SCHEME",
				   "type" => "textcolorpopup",
				   "std" => "#000",
				   "desc" => esc_html__("Here you can set the main color of your website using the palette","chelsey")
			 ),
			 
			 array( "type" => "hint",
				"desc" => esc_html__("Enable or Disable Theme Loader, Theme Loader Spinner","chelsey")
			),
			 
			 array( "name" => esc_html__("Enable Spinner","chelsey"),
			   "id" => "FRGN_ENABLE_SPINNER",
			   "type" => "checkbox",
			   "std" => "off",
			   "desc" => esc_html__("Enable or Disable Theme Loader Spinner","chelsey")
			),
										   

			array( "type" => "clearfix",),

		array( "name" => "general-1",
			   "type" => "subcontent-end",),


	array(  "name" => "wrap-general",
			"type" => "contenttab-wrapend",),

//-------------------------------------------------------------------------------------//

array( "name" => "wrap-head",
		   "type" => "contenttab-wrapstart",),
		   
	array( "type" => "subnavtab-start",),

			array( "name" => "head",
				   "type" => "subnav-tab",
				   "desc" => esc_html__("Header","chelsey")
			),
			
		array( "name" => esc_html__("Choose menus style","chelsey"),
		   "id" => "chelsey_menus_style",
		    "std" => "Classic Top Menu",
		   "type" => "select",
		   "options" => $chelsey_menus_style,
			"desc" => esc_html__("The default style is the 'Classic Top Menu' setting for it below","chelsey")
		),
		
		array( "name" => esc_html__("Enable One Page Menu","chelsey"),
		   "id" => "FRGN_ENABLE_ONE_PAGE_MENU",
		   "type" => "checkbox",
		   "std" => "off",
		   "desc" => esc_html__("One Page Menu available only for Classic menu style","chelsey")
		),
		
		array( "name" => esc_html__("Choose Classic Menu Background Color","chelsey"),
		   "id" => "FRGN_CLASSIC_MENU_BG_COLOR",
		   "std" => "",
		   "type" => "textcolorpopup",
			"desc" => esc_html__("Color Scheme for Side Menu","chelsey")
		),
		
		array( "name" => esc_html__("Choose Classic Menu Links Color","chelsey"),
		   "id" => "FRGN_CLASSIC_MENU_COLOR_LINKS",
		   "std" => "",
			"type" => "textcolorpopup",
			"desc" => esc_html__("Font Color for Side Menu","chelsey")
		),
		
		array( "name" => esc_html__("Side Menu Background Image","chelsey"),
			   "id" => "FRGN_MENU_BG_IMAGE",
			   "type" => "upload",
			   "std" => "",
			   "desc" => esc_html__("If you choose Left Menu, you can set the background image","chelsey")
		),
		
		array( "name" => esc_html__("Choose Side Menu Background Color","chelsey"),
		   "id" => "FRGN_LEFT_MENU_COLOR",
		   "std" => "",
		   "type" => "textcolorpopup",
			"desc" => esc_html__("Color Scheme for Side Menu","chelsey")
		),
		
		array( "name" => esc_html__("Choose Side Menu Links Color","chelsey"),
		   "id" => "FRGN_LEFT_MENU_COLOR_LINKS",
		   "std" => "",
			"type" => "textcolorpopup",
			"desc" => esc_html__("Font Color for Side Menu","chelsey")
		),
		

		array( "type" => "subnavtab-end",),
		
		array( "name" => "head",
			   "type" => "subcontent-start",),
			   
		array( "name" => "head",
			   "type" => "subcontent-end",),
	
	array( "name" => "wrap-head",
		   "type" => "contenttab-wrapend",),
		   
//-------------------------------------------------------------------------------------//

	array( "name" => "wrap-typography",
			   "type" => "contenttab-wrapstart",),
			   
		array( "type" => "subnavtab-start",),
			
			array( "name" => esc_html__("Header Font","chelsey"),
				   "id" => "FRGN_HEADER_FONT",
				   "type" => "select",
				   "std" => "Oswald",
				   "options" => $chelsey_add_google_fonts,
				   "desc" => "Set the font family for headers"
			),
				   
			array( "name" => esc_html__("Body Font","chelsey"),
				   "id" => "FRGN_BODY_FONT",
				   "type" => "select",
				   "std" => "Open Sans",
				   "options" => $chelsey_add_google_fonts,
				   "desc" => "Set the font family for body"
			),
			
			array( "type" => "hint",
				"desc" => esc_html__("Specify the H1 font.","chelsey")
			),			
			array( "name" => esc_html__("H1 Font Size","chelsey"),
                   "id" => "FRGN_H1_FONT_SIZE",
                   "std" => "",
                   "type" => "text",
				   "desc" => "Set the font size in pixels."
			),
			array( "name" => esc_html__("H1 Line Height","chelsey"),
                   "id" => "FRGN_H1_LINE_HEIGHT",
                   "std" => "",
                   "type" => "text",
				   "desc" => "Set the line height in pixels."
			),			
			array( "name" => esc_html__("H1 Text Transform","chelsey"),
				   "id" => "FRGN_H1_TEXT_TRANSFORM",
				   "type" => "select",
				   "std" => "none",
				   "options" => $chelsey_text_transform,
				   "desc" => ""
			),
			
			array( "type" => "hint",
				"desc" => esc_html__("Specify the H2 font.","chelsey")
			),			
			array( "name" => esc_html__("H2 Font Size","chelsey"),
                   "id" => "FRGN_H2_FONT_SIZE",
                   "std" => "",
                   "type" => "text",
				   "desc" => "Set the font size in pixels."
			),
			array( "name" => esc_html__("H2 Line Height","chelsey"),
                   "id" => "FRGN_H2_LINE_HEIGHT",
                   "std" => "",
                   "type" => "text",
				   "desc" => "Set the line height in pixels."
			),			
			array( "name" => esc_html__("H2 Text Transform","chelsey"),
				   "id" => "FRGN_H2_TEXT_TRANSFORM",
				   "type" => "select",
				   "std" => "none",
				   "options" => $chelsey_text_transform,
				   "desc" => ""
			),
			
			array( "type" => "hint",
				"desc" => esc_html__("Specify the H3 font.","chelsey")
			),			
			array( "name" => esc_html__("H3 Font Size","chelsey"),
                   "id" => "FRGN_H3_FONT_SIZE",
                   "std" => "",
                   "type" => "text",
				   "desc" => "Set the font size in pixels."
			),
			array( "name" => esc_html__("H3 Line Height","chelsey"),
                   "id" => "FRGN_H3_LINE_HEIGHT",
                   "std" => "",
                   "type" => "text",
				   "desc" => "Set the line height in pixels."
			),			
			array( "name" => esc_html__("H3 Text Transform","chelsey"),
				   "id" => "FRGN_H3_TEXT_TRANSFORM",
				   "type" => "select",
				   "std" => "none",
				   "options" => $chelsey_text_transform,
				   "desc" => ""
			),
			
			array( "type" => "hint",
				"desc" => esc_html__("Specify the H4 font.","chelsey")
			),			
			array( "name" => esc_html__("H4 Font Size","chelsey"),
                   "id" => "FRGN_H4_FONT_SIZE",
                   "std" => "",
                   "type" => "text",
				   "desc" => "Set the font size in pixels."
			),
			array( "name" => esc_html__("H4 Line Height","chelsey"),
                   "id" => "FRGN_H4_LINE_HEIGHT",
                   "std" => "",
                   "type" => "text",
				   "desc" => "Set the line height in pixels."
			),			
			array( "name" => esc_html__("H4 Text Transform","chelsey"),
				   "id" => "FRGN_H4_TEXT_TRANSFORM",
				   "type" => "select",
				   "std" => "none",
				   "options" => $chelsey_text_transform,
				   "desc" => ""
			),
			
			array( "type" => "hint",
				"desc" => esc_html__("Specify the H5 font.","chelsey")
			),			
			array( "name" => esc_html__("H5 Font Size","chelsey"),
                   "id" => "FRGN_H5_FONT_SIZE",
                   "std" => "",
                   "type" => "text",
				   "desc" => "Set the font size in pixels."
			),
			array( "name" => esc_html__("H5 Line Height","chelsey"),
                   "id" => "FRGN_H5_LINE_HEIGHT",
                   "std" => "",
                   "type" => "text",
				   "desc" => "Set the line height in pixels."
			),			
			array( "name" => esc_html__("H5 Text Transform","chelsey"),
				   "id" => "FRGN_H5_TEXT_TRANSFORM",
				   "type" => "select",
				   "std" => "none",
				   "options" => $chelsey_text_transform,
				   "desc" => ""
			),
			
			array( "type" => "hint",
				"desc" => esc_html__("Specify the H6 font.","chelsey")
			),			
			array( "name" => esc_html__("H6 Font Size","chelsey"),
                   "id" => "FRGN_H6_FONT_SIZE",
                   "std" => "",
                   "type" => "text",
				   "desc" => "Set the font size in pixels."
			),
			array( "name" => esc_html__("H6 Line Height","chelsey"),
                   "id" => "FRGN_H6_LINE_HEIGHT",
                   "std" => "",
                   "type" => "text",
				   "desc" => "Set the line height in pixels."
			),			
			array( "name" => esc_html__("H6 Text Transform","chelsey"),
				   "id" => "FRGN_H6_TEXT_TRANSFORM",
				   "type" => "select",
				   "std" => "none",
				   "options" => $chelsey_text_transform,
				   "desc" => ""
			),

			array( "type" => "subnavtab-end",),
			
			array( "name" => "typography",
				   "type" => "subcontent-start",),
				   
			array( "name" => "typography",
				   "type" => "subcontent-end",),
		
		array( "name" => "wrap-typography",
			   "type" => "contenttab-wrapend",),

//-------------------------------------------------------------------------------------//
		   
//-------------------------------------------------------------------------------------//

array( "name" => "wrap-social-network",
		   "type" => "contenttab-wrapstart",),
		   
	array( "type" => "subnavtab-start",),

			array( "name" => "social-network",
				   "type" => "subnav-tab",
				   "desc" => esc_html__("Social Network","chelsey")
			),

		array( "type" => "subnavtab-end",),
		
		array( "name" => "social-network",
			   "type" => "subcontent-start",),
			   
			   array( "type" => "hint",
					"desc" => esc_html__("In these settings, you can turn on and off display of icons of social networks","chelsey")
				),
			   
			   array( "name" => esc_html__("Twitter Icon","chelsey"),
                   "id" => "FRGN_SHOW_TWITTER_ICON",
                   "type" => "checkbox",
                   "std" => "on",
				   "desc" => ""
				),
			
			array( "name" => esc_html__("Facebook Icon","chelsey"),
                   "id" => "FRGN_SHOW_FACEBOOK_ICON",
                   "type" => "checkbox",
                   "std" => "on",
				   "desc" => ""
			),
						
			array( "name" => esc_html__("Google Icon","chelsey"),
                   "id" => "FRGN_SHOW_GOOGLE_ICON",
                   "type" => "checkbox",
                   "std" => "on",
				   "desc" => ""
			),
			
			
			array( "name" => esc_html__("Pinterest Icon","chelsey"),
                   "id" => "FRGN_SHOW_PINTEREST_ICON",
                   "type" => "checkbox",
                   "std" => "on",
				   "desc" => ""
			),
			
			array( "name" => esc_html__("Dribble Icon","chelsey"),
                   "id" => "FRGN_SHOW_DRIBBLE_ICON",
                   "type" => "checkbox",
                   "std" => "on",
				   "desc" => ""
			),
			
			array( "name" => esc_html__("Instagram Icon","chelsey"),
                   "id" => "FRGN_SHOW_INSTAGRAM_ICON",
                   "type" => "checkbox",
                   "std" => "on",
				   "desc" => ""
			),
			
			array( "name" => esc_html__("Linkedin Icon","chelsey"),
                   "id" => "FRGN_SHOW_LINKEDIN_ICON",
                   "type" => "checkbox",
                   "std" => "on",
				   "desc" => ""
			),
			
			array( "name" => esc_html__("XING Icon","chelsey"),
                   "id" => "FRGN_SHOW_XING_ICON",
                   "type" => "checkbox",
                   "std" => "on",
				   "desc" => ""
			),
			
			array( "name" => esc_html__("Skype Icon","chelsey"),
                   "id" => "FRGN_SHOW_SKYPE_ICON",
                   "type" => "checkbox",
                   "std" => "on",
				   "desc" => ""
			),
			
			array( "type" => "clearfix",),
			
			 array( "type" => "hint",
				"desc" => esc_html__("Enter your address to your network profiles","chelsey")
			),
			
			array( "name" => esc_html__("Twitter Profile Url","chelsey"),
                   "id" => $chelsey_shortname."_twitter_url",
                   "std" => "#",
                   "type" => "text",
				   "desc" => ""
			),
				   
			array( "name" => esc_html__("Pinterest Profile Url","chelsey"),
                   "id" => $chelsey_shortname."_pinterest_url",
                   "std" => "#",
                   "type" => "text",
				   "desc" => ""
			),
			
			array( "name" => esc_html__("Facebook Profile Url","chelsey"),
                   "id" => $chelsey_shortname."_facebook_url",
                   "std" => "#",
                   "type" => "text",
				   "desc" => ""
			),
			
			array( "name" => esc_html__("Google Profile Url","chelsey"),
                   "id" => $chelsey_shortname."_google_url",
                   "std" => "#",
                   "type" => "text",
				   "desc" => ""
			),
			
			array( "name" => esc_html__("Dribble Profile Url","chelsey"),
                   "id" => $chelsey_shortname."_dribble_url",
                   "std" => "#",
                   "type" => "text",
				   "desc" => ""
			),
			
			array( "name" => esc_html__("Instagram Profile Url","chelsey"),
                   "id" => $chelsey_shortname."_instagram_url",
                   "std" => "#",
                   "type" => "text",
				   "desc" => ""
			),
			
			array( "name" => esc_html__("Linkedin Profile Url","chelsey"),
                   "id" => $chelsey_shortname."_linkedin_url",
                   "std" => "#",
                   "type" => "text",
				   "desc" => ""
			),
			
			array( "name" => esc_html__("XING Profile Url","chelsey"),
                   "id" => $chelsey_shortname."_xing_url",
                   "std" => "#",
                   "type" => "text",
				   "desc" => ""
			),
			
			array( "name" => esc_html__("Skype Profile Url","chelsey"),
                   "id" => $chelsey_shortname."_skype_url",
                   "std" => "#",
                   "type" => "text",
				   "desc" => ""
			),
			   
		array( "name" => "social-network",
			   "type" => "subcontent-end",),
			   
			   

	array( "name" => "wrap-social-network",
		   "type" => "contenttab-wrapend",),

//-------------------------------------------------------------------------------------//

array( "name" => "wrap-footer",
		   "type" => "contenttab-wrapstart",),
		   
	array( "type" => "subnavtab-start",),
		
		array( "type" => "hint",
			"desc" => esc_html__("Footer Settings","chelsey")
		),
		
		array( "name" => esc_html__("Background Color of Footer","chelsey"),
			   "id" => "FRGN_FOOTER_BG_COLOR",
			   "type" => "textcolorpopup",
			   "std" => "",
			   "desc" => esc_html__("Here you can set the background color using the palette","chelsey")
		 ),
		 
		 array( "name" => esc_html__("Footer Font Color","chelsey"),
			   "id" => "FRGN_FOOTER_FONT_COLOR",
			   "type" => "textcolorpopup",
			   "std" => "",
			   "desc" => esc_html__("Here you can set the font color using the palette","chelsey")
		 ),
		 
		 array( "name" => esc_html__("Text of Footer","chelsey"),
		   "id" => "FRGN_FOOTER_TEXT",
		   "std" => esc_html__("Designed by Fragrance Design � 2019","chelsey"),
		   "type" => "text",
		   "desc" => esc_html__("","chelsey")
		),

		array( "type" => "subnavtab-end",),
		
		array( "name" => "footer",
			   "type" => "subcontent-start",),
			   
		array( "name" => "footer",
			   "type" => "subcontent-end",),
	
	array( "name" => "wrap-footer",
		   "type" => "contenttab-wrapend",),

//-------------------------------------------------------------------------------------//

); 