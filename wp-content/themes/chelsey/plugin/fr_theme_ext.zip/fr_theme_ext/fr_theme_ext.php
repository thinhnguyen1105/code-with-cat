<?php
/*
Plugin Name: Fragrance Theme Extensions
Plugin URI: 
Description: Custom functions for Fragrance Themes. This plugin is required for use with Chelsey theme. It gathers all shortcodes and elements from Chelsey theme. It gives a possibility to keep this content data even if you switch the theme to another one. This is a part of new Envato requirements for WordPress theme developers.
Version: 1.0.0
Author: Fragrance
Author URI: fragrancetheme.com
*/

function frgn_register_script() {
	/* Video Pop-Up*/
	wp_register_style( 'fr_magnific_popup_css', plugins_url( 'assets/css/magnific-popup.css', __FILE__ ), array() );  	
	wp_register_script( 'fr_custom', plugins_url( 'assets/js/custom.js', __FILE__ ), array() );  
	
	wp_enqueue_style( 'font-awesome', plugins_url( 'assets/css/all.min.css', __FILE__ ), array() );  
	wp_enqueue_style( 'fr_magnific_popup_css' );	
	wp_enqueue_script( 'fr_custom' );
} 
add_action( 'wp_enqueue_scripts', 'frgn_register_script' );

require_once('fragrance_options.php');
require_once('layout.php');
require_once('fr_page_settings/add_page_settings.php');

//iclude widgets
include_once('chelsey-elements/inc/widgets/socials.php'); // add socials widget
include_once('chelsey-elements/inc/widgets/instagram.php'); // add instagram widget

/**
 * Force Visual Composer to initialize as "built into the theme". This will hide certain tabs under the Settings->Visual Composer page
 */
add_action( 'vc_before_init', 'fr_vcSetAsTheme' );
function fr_vcSetAsTheme() {
    vc_set_as_theme();
	require_once('vc_templates/fragrance_elem.php');
	require_once('chelsey-elements/chelsey-elements.php');
}
/*** Register Sidebars ***/
add_action( 'widgets_init', 'chelsey_widgets' );
if ( function_exists('register_sidebar') ) {
	function chelsey_widgets() {
		register_sidebar( array(
			'name' => esc_html__( 'Header Aside Area', 'chelsey' ),
			'id' => esc_html__('header-area', 'chelsey' ),
			'description'   => esc_html__( 'Opening widget area in aside header', 'chelsey' ),
			'before_widget' => wp_kses('<div id="%1$s" class="widget %2$s">',array('div' => array( 'id' => array(), 'class' => array(),),)),
			'after_widget' => wp_kses('</div> <!-- end .f_widget -->',array('div' => array(),)),
			'before_title' => wp_kses('<h4 class="widgettitle">',array('h4' => array(),)),
			'after_title' => wp_kses('</h4>',array('h4' => array(),)),
		) );
	}
}

function frgn_ext_vce_has_link( $link = '' ) {

	$has_link = false;

	if ( !empty( $link ) ){
		$link = vc_build_link( $link );
		if ( strlen( $link['url'] ) > 0 ) {
			$has_link = true;
		}
	}
	return $has_link;

}

function frgn_ext_vce_get_link_attributes( $link = '', $class = '', $style = ''  ) {
	$attributes = array();
	$a_href = $a_title = $a_target = $a_rel = '';
	$use_link = false;

	if ( !empty( $link ) ){
		$link = vc_build_link( $link );
		if ( strlen( $link['url'] ) > 0 ) {
			$use_link = true;
			$a_href = $link['url'];
			$a_title = $link['title'];
			$a_target = $link['target'];
			$a_rel = $link['rel'];
		}
	}

	if ( $use_link ) {
		$attributes[] = 'href="' . esc_url( $a_href ) . '"';
		if ( ! empty( $a_title ) ) {
			$attributes[] = 'title="' . esc_attr( trim( $a_title ) ) . '"';
		}
		if ( ! empty( $a_target ) ) {
			$attributes[] = 'target="' . esc_attr( trim( $a_target ) ) . '"';
		}
		if ( ! empty( $a_rel ) ) {
			$attributes[] = 'rel="' . esc_attr( trim( $a_rel ) ) . '"';
		}
	} else {
		$attributes[] = 'href="#"';
	}


	if ( ! empty( $class ) ) {
		$attributes[] = 'class="' . esc_attr( $class ) . '"';
	}
	if ( ! empty( $style ) ) {
		$attributes[] = 'style="' . esc_attr( $style ) . '"';
	}

	return $attributes;
}
function frgn_ext_vce_build_margin_bottom_style( $margin_bottom ) {
	$style = '';
	if( $margin_bottom != '' ) {
		$style .= 'margin-bottom: '.(preg_match('/(px|em|\%|pt|cm)$/', $margin_bottom) ? $margin_bottom : $margin_bottom .'px').';';
		$style = esc_attr( $style );
	}
	return $style;
}
function frgn_ext_vce_get_image_size( $image_mode = 'full', $index = 1 ) {

	switch( $image_mode ) {
		case 'thumbnail':
			$image_size = 'thumbnail';
		break;
		case 'medium':
			$image_size = 'medium';
		break;
		case 'medium_large':
			$image_size = 'medium_large';
		break;
		case 'large':
			$image_size = 'large';
		break;
		case 'square':
			$image_size = 'frgn-small-square';
		break;
		case 'landscape':
			$image_size = 'frgn-small-rect-horizontal';
		break;
		case 'landscape-medium':
			$image_size = 'frgn-medium-rect-horizontal';
		break;
		case 'portrait':
			$image_size = 'frgn-small-rect-vertical';
		break;
		case 'portrait-medium':
			$image_size = 'frgn-medium-rect-vertical';
		break;
		case 'landscape-large-wide':
			$image_size = 'frgn-large-rect-horizontal';
		break;
		case 'fullscreen':
		case 'extra-extra-large':
			$image_size = 'frgn-fullscreen';
		break;
		case 'loop':
			$image_size = "frgn-small-rect-vertical";
			if ( $index % 2  == 0 ) {
				$image_size = "frgn-medium-rect-horizontal";
			}
		break;
		default:
			$image_size = 'full';
		break;
	}

	return $image_size;

}
function frgn_ext_vce_get_attachment_image( $id, $size = 'thumbnail', $icon = false, $attr = '' ) {
	if ( function_exists( 'frgn_eutf_get_attachment_image' ) ) {
		return frgn_eutf_get_attachment_image( $id, $size , $icon, $attr );
	} else {
		return wp_get_attachment_image( $id, $size , $icon, $attr );
	}
}
function frgn_ext_vce_auto_br( $s ) {
    $s = str_replace("<p>", "", $s);
    $s = str_replace("</p>", "<br>", $s);
    return $s;
}

if( !function_exists( 'frgn_ext_vce_add_margin_bottom' ) ) {
	function frgn_ext_vce_add_margin_bottom() {
		return array(
			"type" => "textfield",
			"heading" => esc_html__('Bottom margin', 'frgn-extension'),
			"param_name" => "margin_bottom",
			"description" => esc_html__( "You can use px, em, %, etc. or enter just number and it will use pixels.", "frgn-extension" ),
		);
	}
}
if( !function_exists( 'frgn_ext_vce_add_el_class' ) ) {
	function frgn_ext_vce_add_el_class() {
		return array(
			"type" => "textfield",
			"heading" => esc_html__( "Extra class name", "frgn-extension" ),
			"param_name" => "el_class",
			"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "frgn-extension" ),
		);
	}
}

//Title Headings/Tags
if( !function_exists( 'frgn_ext_vce_get_heading_tag' ) ) {
	function frgn_ext_vce_get_heading_tag( $std = '' ) {
		return	array(
			"type" => "dropdown",
			"heading" => esc_html__( "Title Tag", "frgn-extension" ),
			"param_name" => "heading_tag",
			"value" => array(
				esc_html__( "h1", "frgn-extension" ) => 'h1',
				esc_html__( "h2", "frgn-extension" ) => 'h2',
				esc_html__( "h3", "frgn-extension" ) => 'h3',
				esc_html__( "h4", "frgn-extension" ) => 'h4',
				esc_html__( "h5", "frgn-extension" ) => 'h5',
				esc_html__( "h6", "frgn-extension" ) => 'h6',
				esc_html__( "div", "frgn-extension" ) => 'div',
			),
			"description" => esc_html__( "Title Tag for SEO", "frgn-extension" ),
			"std" => $std,
		);
	}
}

if( !function_exists( 'frgn_ext_vce_get_heading' ) ) {
	function frgn_ext_vce_get_heading( $std = '' ) {
		return	array(
			"type" => "dropdown",
			"heading" => esc_html__( "Title Size/Typography", "frgn-extension" ),
			"param_name" => "heading",
			"value" => array(
				esc_html__( "h1", "frgn-extension" ) => 'h1',
				esc_html__( "h2", "frgn-extension" ) => 'h2',
				esc_html__( "h3", "frgn-extension" ) => 'h3',
				esc_html__( "h4", "frgn-extension" ) => 'h4',
				esc_html__( "h5", "frgn-extension" ) => 'h5',
				esc_html__( "h6", "frgn-extension" ) => 'h6',
				esc_html__( "Leader Text", "frgn-extension" ) => 'leader-text',
				esc_html__( "Subtitle Text", "frgn-extension" ) => 'subtitle-text',
				esc_html__( "Small Text", "frgn-extension" ) => 'small-text',
				esc_html__( "Link Text", "frgn-extension" ) => 'link-text',
			),
			"description" => esc_html__( "Title size and typography, defined in Theme Options - Typography Options", "frgn-extension" ),
			"std" => $std,
		);
	}
}
// Heading Increase
if( !function_exists( 'frgn_ext_vce_get_heading_increase' ) ) {
	function frgn_ext_vce_get_heading_increase() {
		return	array(
			"type" => "dropdown",
			"heading" => esc_html__( "Increased Heading Size", "frgn-extension" ),
			"param_name" => "increase_heading",
			"value" => array(
				esc_html__( "100%", "frgn-extension" ) => '100',
				esc_html__( "120%", "frgn-extension" ) => '120',
				esc_html__( "140%", "frgn-extension" ) => '140',
				esc_html__( "160%", "frgn-extension" ) => '160',
				esc_html__( "180%", "frgn-extension" ) => '180',
				esc_html__( "200%", "frgn-extension" ) => '200',
				esc_html__( "250%", "frgn-extension" ) => '250',
				esc_html__( "300%", "frgn-extension" ) => '300',
			),
			"description" => esc_html__( "Set the percentage you want to increase your Headings size.", "frgn-extension" ),
		);
	}
}
if( !function_exists( 'frgn_ext_vce_get_heading_increase_reset' ) ) {
	function frgn_ext_vce_get_heading_increase_reset() {
		return	array(
			"type" => "dropdown",
			"heading" => esc_html__( "Reset Heading Size", "frgn-extension" ),
			"param_name" => "increase_heading_reset",
			"value" => array(
				esc_html__( "Never", "frgn-extension" ) => '',
				esc_html__( "on Small Desktop and below", "frgn-extension" ) => 'desktop-sm',
				esc_html__( "on Tablet Landscape and below", "frgn-extension" ) => 'tablet',
				esc_html__( "on Tablet Portrait and below", "frgn-extension" ) => 'tablet-sm',
				esc_html__( "on Mobile Ladscape ane below", "frgn-extension" ) => 'mobile',
			),
			"description" => esc_html__( "Select if you want to reset the header size in some devices in case size is too large.", "frgn-extension" ),
			"dependency" => array( 'element' => "increase_heading", 'value_not_equal_to' => array( '100' ) ),
		);
	}
}
if( !function_exists( 'frgn_ext_vce_get_custom_font_family' ) ) {
	function frgn_ext_vce_get_custom_font_family( $std = '' ) {
		return	array(
			"type" => "dropdown",
			"heading" => esc_html__( "Custom Font Family", "frgn-extension" ),
			"param_name" => "custom_font_family",
			"value" => array(
				esc_html__( "Same as Typography", "frgn-extension" ) => '',
				esc_html__( "Custom Font Family 1", "frgn-extension" ) => 'custom-font-1',
				esc_html__( "Custom Font Family 2", "frgn-extension" ) => 'custom-font-2',
				esc_html__( "Custom Font Family 3", "frgn-extension" ) => 'custom-font-3',
				esc_html__( "Custom Font Family 4", "frgn-extension" ) => 'custom-font-4',

			),
			"description" => esc_html__( "Select a different font family, defined in Theme Options - Typography Options - Extras - Custom Font Family", "frgn-extension" ),
			"std" => $std,
		);
	}
}

if( !function_exists( 'frgn_ext_vce_get_gradient_color' ) ) {
	function frgn_ext_vce_get_gradient_color( ) {
		return	array(
			"type" => "dropdown",
			"heading" => esc_html__( "Gradient Color", "frgn-extension" ),
			"param_name" => "gradient_color",
			"value" => array(
				esc_html__( "No", "frgn-extension" ) => '',
				esc_html__( "Yes", "frgn-extension" ) => 'yes',

			),
			"description" => esc_html__( "Select if you want gradient color", "frgn-extension" ),
		);
	}
}

if( !function_exists( 'frgn_ext_vce_get_gradient_color_1' ) ) {
	function frgn_ext_vce_get_gradient_color_1( ) {
		return	array(
				"type" => "dropdown",
				"heading" => esc_html__( "Gradient Color 1 ", "frgn-extension" ),
				"param_name" => "gradient_color_1",
				"param_holder_class" => "eut-colored-dropdown",
				'edit_field_class' => 'vc_col-sm-6',
				"value" => array(
					esc_html__( "Primary 1", "frgn-extension" ) => 'primary-1',
					esc_html__( "Primary 2", "frgn-extension" ) => 'primary-2',
					esc_html__( "Primary 3", "frgn-extension" ) => 'primary-3',
					esc_html__( "Primary 4", "frgn-extension" ) => 'primary-4',
					esc_html__( "Primary 5", "frgn-extension" ) => 'primary-5',
					esc_html__( "Primary 6", "frgn-extension" ) => 'primary-6',
					esc_html__( "Green", "frgn-extension" ) => 'green',
					esc_html__( "Orange", "frgn-extension" ) => 'orange',
					esc_html__( "Red", "frgn-extension" ) => 'red',
					esc_html__( "Blue", "frgn-extension" ) => 'blue',
					esc_html__( "Aqua", "frgn-extension" ) => 'aqua',
					esc_html__( "Purple", "frgn-extension" ) => 'purple',
					esc_html__( "Black", "frgn-extension" ) => 'black',
					esc_html__( "Grey", "frgn-extension" ) => 'grey',
					esc_html__( "White", "frgn-extension" ) => 'white',
				),
				"description" => esc_html__( "Select first color for gradient.", "frgn-extension" ),
				"dependency" => array( 'element' => "gradient_color", 'value' => array( 'yes' ) ),
				"std" => 'primary-1',
		);
	}
}

if( !function_exists( 'frgn_ext_vce_get_gradient_color_2' ) ) {
	function frgn_ext_vce_get_gradient_color_2( ) {
		return	array(
				"type" => "dropdown",
				"heading" => esc_html__( "Gradient Color 2 ", "frgn-extension" ),
				"param_name" => "gradient_color_2",
				"param_holder_class" => "eut-colored-dropdown",
				'edit_field_class' => 'vc_col-sm-6',
				"value" => array(
					esc_html__( "Primary 1", "frgn-extension" ) => 'primary-1',
					esc_html__( "Primary 2", "frgn-extension" ) => 'primary-2',
					esc_html__( "Primary 3", "frgn-extension" ) => 'primary-3',
					esc_html__( "Primary 4", "frgn-extension" ) => 'primary-4',
					esc_html__( "Primary 5", "frgn-extension" ) => 'primary-5',
					esc_html__( "Primary 6", "frgn-extension" ) => 'primary-6',
					esc_html__( "Green", "frgn-extension" ) => 'green',
					esc_html__( "Orange", "frgn-extension" ) => 'orange',
					esc_html__( "Red", "frgn-extension" ) => 'red',
					esc_html__( "Blue", "frgn-extension" ) => 'blue',
					esc_html__( "Aqua", "frgn-extension" ) => 'aqua',
					esc_html__( "Purple", "frgn-extension" ) => 'purple',
					esc_html__( "Black", "frgn-extension" ) => 'black',
					esc_html__( "Grey", "frgn-extension" ) => 'grey',
					esc_html__( "White", "frgn-extension" ) => 'white',
				),
				"description" => esc_html__( "Select second color for gradient.", "frgn-extension" ),
				"dependency" => array( 'element' => "gradient_color", 'value' => array( 'yes' ) ),
				"std" => 'primary-2',
		);
	}
}
if( !function_exists( 'frgn_ext_vce_add_inherit_align' ) ) {
	function frgn_ext_vce_add_inherit_align() {
		return array(
			"type" => "dropdown",
			"heading" => esc_html__( "Alignment", "frgn-extension" ),
			"param_name" => "inherit_align",
			"value" => array(
				esc_html__( "Inherit", "frgn-extension" ) => 'inherit',
				esc_html__( "Left", "frgn-extension" ) => 'left',
				esc_html__( "Right", "frgn-extension" ) => 'right',
				esc_html__( "Center", "frgn-extension" ) => 'center',
			),
			"description" => 'Inherits its value from its column text align definition.',
		);
	}
}
?>