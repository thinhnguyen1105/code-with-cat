<?php

/* ----------------------------------------------------- 
 * Post Slides Metabox
 * ----------------------------------------------------- */
add_filter( 'rwmb_meta_boxes', 'chelsey_register_meta_boxes' );
function chelsey_register_meta_boxes($meta_boxes) {
    $prefix = 'chelsey_';
	/* ----------------------------------------------------- */
	// Post Slides Metabox
	/* ----------------------------------------------------- */
	$meta_boxes[] = array(
		'id'		=> 'portfolio_layout',
		'title'		=> esc_html__('Portfolio Layout','chelsey-elements'),
		'pages'		=> array( 'post' ),
		'context' => 'normal',
		'fields'	=> array(
			array(
	    	   'name' => esc_html__('Select portfolio item width', 'chelsey-elements'),
	    	   'desc' => esc_html__('Select width for metro portfolio item', 'chelsey-elements'),
	    	   'id' => $prefix . 'portfolio_layout',
	    	   'type' => 'select',
	    	   'options'  => array(
	    	   		'col-lg-2 col-md-2 col-sm-6 col-xs-12' => esc_html__('Standart Width', 'chelsey-elements'),
	    	   		'col-lg-4 col-md-2 col-sm-6 col-xs-12' => esc_html__('Double Width', 'chelsey-elements'),
	    	   	),
			   'std' => array('col-md-4 col-sm-6 col-xs-12')
	    	), 
			array(
	    	   'name' => esc_html__('Select portfolio item height', 'chelsey-elements'),
	    	   'desc' => esc_html__('Select height for metro portfolio item', 'chelsey-elements'),
	    	   'id' => $prefix . 'portfolio_height',
	    	   'type' => 'select',
	    	   'options'  => array(
	    	   		'standart_height' => esc_html__('Standart Height', 'chelsey-elements'),
	    	   		'double_height' => esc_html__('Double Height', 'chelsey-elements'),
	    	   	),
			   'std' => array('standart_height')
	    	), 
		)
	);
	
	$meta_boxes[] = array(
		'id'		=> 'portfolio_project',
		'title'		=> esc_html__('Portfolio Project','chelsey-elements'),
		'pages'		=> array( 'post' ),
		'context' => 'normal',
		'fields'	=> array(
			array(
				'name'	=> esc_html__('Project Client','chelsey-elements'),
				'desc'	=> esc_html__('','chelsey-elements'),
				'id'	=> $prefix . 'project_client',
				'type'	=> 'text',
			),
			array(
				'name'	=> esc_html__('Project Skills','chelsey-elements'),
				'desc'	=> esc_html__('Input title for your external link.','chelsey-elements'),
				'id'	=> $prefix . 'project_skills',
				'type'	=> 'text',
			),

		)
	);
	$meta_boxes[] = array(
		'id'		=> 'post_layout',
		'title'		=> esc_html__('Post Layout','chelsey-elements'),
		'pages'		=> array( 'page' ),
		'context' => 'normal',
		'fields'	=> array(
			array(
			    'name' => esc_html__('Post sidebar', 'chelsey-elements'),
			    'desc' => esc_html__('Select sidebar position.', 'chelsey-elements'),
			    'id'   => $prefix . 'post_sidebar',
			    'type' => 'select',
			    'options' => array(
			    	'default' => esc_html__('Default', 'chelsey-elements'),
			    	'sidebar-right' => esc_html__('Sidebar right', 'chelsey-elements'),
			    	'sidebar-left' => esc_html__('Sidebar left', 'chelsey-elements'),
			    ),
			    'std'  => array('default'),
			),
			array(
	    	   'name' => esc_html__('Featured post', 'chelsey-elements'),
	    	   'desc' => esc_html__('Check this if you need to highlight post for posts list view.', 'chelsey-elements'),
	    	   'id' => $prefix . 'post_featured',
	    	   'type' => 'checkbox',
			   'std' => 0
	    	),

		)
	);
	$meta_boxes[] = array(
		'id'		=> 'post_slides',
		'title'		=> esc_html__('Post Gallery','chelsey-elements'),
		'pages'		=> array( 'post' ),
		'context' => 'normal',
		'fields'	=> array(
			array(
				'name'	=> esc_html__('Post Gallery Images','chelsey-elements'),
				'desc'	=> esc_html__('Upload up to 30 project images for a slideshow - or only one to display a single image.','chelsey-elements'),
				'id'	=> $prefix . 'gallery_images',
				'type'	=> 'image_advanced',
				'max_file_uploads' => 30
			),
		)
	);
	return $meta_boxes;
}
