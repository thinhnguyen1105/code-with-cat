<?php

add_action( 'init', 'chelsey_elements_vc_shortcodes' );
function chelsey_elements_vc_shortcodes() {
	$imageSizes = get_intermediate_image_sizes();
	$imageSizes[]= 'full';
	
	vc_map( 
		array(
			"name" => __("Chelsey Grid Posts", 'chelsey-elements'),
			"base" => "gridposts",
			"icon" => 'chelsey-element-icon dashicons dashicons-screenoptions',
			"category" => __('Chelsey Elements', 'chelsey-elements'),
			'description' => __('Show WP posts in grid.', 'chelsey-elements'),
			"params" => array(	
				array(
					"type" => "textfield",            
					"heading" => __("Post count", 'chelsey-elements'),
					"param_name" => "num",
					"value" => '3',
					'admin_label' => true,
					"description" => __("Enter number of posts to display (Note: Enter '-1' to display all posts).", 'chelsey-elements')            
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Posts per row", 'chelsey-elements'),
					"param_name" => "columns",
					"value" => array(
					   __('Two', 'chelsey-elements')=>'span6',
					   __('Three', 'chelsey-elements')=>'span4',
					   __('Four', 'chelsey-elements')=>'span3',
					   __('Five', 'chelsey-elements')=>'one_fifth',
					   __('Six', 'chelsey-elements')=>'span2',
					),
					"description" => __("Select posts count per row.", 'chelsey-elements'),
					"std" => array('span4')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Category slug", 'chelsey-elements'),
					"param_name" => "cat_slug",
					"value" => '',
					"description" => __("This help you to retrieve items from specific category. More than one separate by commas.", 'chelsey-elements')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Post IDs", 'chelsey-elements'),
					"param_name" => "post_ids",
					"value" => '',
					"description" => __("Enter posts IDs to display only those records (Note: separate values by commas (,)).", 'chelsey-elements')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Sort order", 'chelsey-elements'),
					"param_name" => "order",
					"value" => array(
					   __('Descending', 'chelsey-elements')=>'DESC', 
					   __('Ascending', 'chelsey-elements')=>'ASC'
					),
					"description" => __('Select ascending or descending order.', 'chelsey-elements'),
					"std" => array('DESC')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Post view style", 'chelsey-elements'),
					"param_name" => "post_style",
					"value" => array(
					   __('Simple', 'chelsey-elements')=>'style_1', 
					   __('Boxed', 'chelsey-elements')=>'style_2'
					),
					"description" => __('Select posts style on preview.', 'chelsey-elements'),
					"std" => array('style_1')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Thumbnail size", 'chelsey-elements'),
					"param_name" => "thumbsize",
					"value" => $imageSizes,
					"description" => __('Select your image size to use.', 'chelsey-elements'),
					"std" => array('medium')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Post excerpt count", 'chelsey-elements'),
					"param_name" => "excerpt_count",
					"value" => '32',
					"description" => __("Enter number of words in post excerpt. 0 to hide it.", 'chelsey-elements')            
				),
				array(
		            "type" => "dropdown",            
		            "heading" => __("Show share icons", 'chelsey-elements'),
		            "param_name" => "show_sharebox",
		            "value" => array(__('Yes','chelsey-elements')=>'true', __('No', 'chelsey-elements')=>'false'),
		            "description" => __('Show sticky posts?', 'chelsey-elements'),
		            "std" => array('true')
		        ),
				array(
		            "type" => "dropdown",            
		            "heading" => __("Pagination", 'chelsey-elements'),
		            "param_name" => "pagination",
		            "value" => array(__('Enable','chelsey-elements')=>'true', __('Disable', 'chelsey-elements')=>'false'),
		            "description" => __('Enable or Disable pagination for posts.', 'chelsey-elements'),
		            "std" => array('false')
		        ),
			)
		)
	);
	
	vc_map( 
		array(
			"name" => __("Chelsey Carousel Posts", 'chelsey-elements'),
			"base" => "carouselposts",
			"icon" => 'chelsey-element-icon dashicons dashicons-leftright',
			'front_enqueue_js' => array(CHELSEY_PLUGIN_URL.'js/owl-carousel.min.js'),
			"category" => __('Chelsey Elements', 'chelsey-elements'),
			'description' => __('Show WP posts in grid.', 'chelsey-elements'),
			"params" => array(
				array(
					"type" => "textfield",            
					"heading" => __("Posts block title", 'chelsey-elements'),
					"param_name" => "block_title",
					"value" => '',
					'admin_label' => true,
					"description" => __("Enter posts block title e.g. 'Latest posts'. Leave blank if you need not to display it.", 'chelsey-elements')            
				),		
				array(
					"type" => "textfield",            
					"heading" => __("Post count", 'chelsey-elements'),
					"param_name" => 'posts_count',
					"value" => '3',
					"description" => __("Enter number of posts to display (Note: Enter '-1' to display all posts).", 'chelsey-elements')            
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Posts per view", 'chelsey-elements'),
					"param_name" => "columns",
					"value" => array(
					   __('Two per view', 'chelsey-elements')=>'span6',
					   __('Three per view', 'chelsey-elements')=>'span4',
					   __('Four per view', 'chelsey-elements')=>'span3',
					   __('Five per view', 'chelsey-elements')=>'one_fifth',
					   __('Six per view', 'chelsey-elements')=>'span2',
					),
					"description" => __("Select posts count per view.", 'chelsey-elements'),
					"std" => array('one_fifth')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Category slug", 'chelsey-elements'),
					"param_name" => "cat_slug",
					"value" => '',
					"description" => __("This help you to retrieve items from specific category. More than one separate by commas.", 'chelsey-elements')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Post IDs", 'chelsey-elements'),
					"param_name" => "post_ids",
					"value" => '',
					"description" => __("Enter posts IDs to display only those records (Note: separate values by commas (,)).", 'chelsey-elements')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Order by", 'chelsey-elements'),
					"param_name" => "orderby",
					"value" => array(
					   __('Date', 'chelsey-elements')=>'date', 
					   __('Last modified date', 'chelsey-elements') => 'modified',
					   __('Popularity', 'chelsey-elements')=>'comment_count',
					   __('Title', 'chelsey-elements')=>'title',
					   __('Random', 'chelsey-elements')=>'rand',
					   __('Preserve post ID order', 'chelsey-elements') => 'post__in',
					),
					"description" => __('Select how to sort retrieved posts.', 'chelsey-elements'),
					"std" => array('date')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Sort order", 'chelsey-elements'),
					"param_name" => "order",
					"value" => array(
					   __('Descending', 'chelsey-elements')=>'DESC', 
					   __('Ascending', 'chelsey-elements')=>'ASC'
					),
					"description" => __('Select ascending or descending order.', 'chelsey-elements'),
					"std" => array('DESC')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Thumbnail size", 'chelsey-elements'),
					"param_name" => "thumbsize",
					"value" => $imageSizes,
					"description" => __('Select your image size to use.', 'chelsey-elements'),
					"std" => array('medium')
				),
			)
		)
	);
	
	vc_map( 
		array(
			"name" => __("Chelsey Portfolio Metro", 'chelsey-elements'),
			"base" => "portfoliometro",
			"icon" => 'chelsey-element-icon dashicons dashicons-layout',
			"category" => __('Chelsey Elements', 'chelsey-elements'),
			'description' => __('Show Portfolio in Metro Style.', 'chelsey-elements'),
			"params" => array(	
				array(
					"type" => "textfield",            
					"heading" => __("Post count", 'chelsey-elements'),
					"param_name" => "num",
					"value" => '3',
					'admin_label' => true,
					"description" => __("Enter number of posts to display (Note: Enter '-1' to display all posts).", 'chelsey-elements')            
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Style", 'chelsey-elements'),
					"param_name" => "style",
					"value" => array(
					   __('Classic Portfolio', 'chelsey-elements')=>'classic',
					   __('Floating Portfolio', 'chelsey-elements')=>'floating',
					),
					"description" => __("Select portfolio style.", 'chelsey-elements'),
					"std" => array('classic')
				),
				/*array(
					"type" => "dropdown",            
					"heading" => __("Posts per row", 'chelsey-elements'),
					"param_name" => "columns",
					"value" => array(
					   __('Two', 'chelsey-elements')=>'span6',
					   __('Three', 'chelsey-elements')=>'span4',
					   __('Four', 'chelsey-elements')=>'span3',
					   __('Five', 'chelsey-elements')=>'one_fifth',
					   __('Six', 'chelsey-elements')=>'span2',
					),
					"description" => __("Select posts count per row.", 'chelsey-elements'),
					"std" => array('span4')
				),*/
				array(
					"type" => "textfield",            
					"heading" => __("Category slug", 'chelsey-elements'),
					"param_name" => "cat_slug",
					"value" => '',
					"description" => __("This help you to retrieve items from specific category. More than one separate by commas.", 'chelsey-elements')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Post IDs", 'chelsey-elements'),
					"param_name" => "post_ids",
					"value" => '',
					"description" => __("Enter posts IDs to display only those records (Note: separate values by commas (,)).", 'chelsey-elements')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Sort order", 'chelsey-elements'),
					"param_name" => "order",
					"value" => array(
					   __('Descending', 'chelsey-elements')=>'DESC', 
					   __('Ascending', 'chelsey-elements')=>'ASC'
					),
					"description" => __('Select ascending or descending order.', 'chelsey-elements'),
					"std" => array('DESC')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Thumbnail size", 'chelsey-elements'),
					"param_name" => "thumbsize",
					"value" => $imageSizes,
					"description" => __('Select your image size to use.', 'chelsey-elements'),
					"std" => array('medium')
				),
				array(
		            "type" => "dropdown",            
		            "heading" => __("Pagination", 'chelsey-elements'),
		            "param_name" => "pagination",
		            "value" => array(__('Enable','chelsey-elements')=>'true', __('Disable', 'chelsey-elements')=>'false'),
		            "description" => __('Enable or Disable pagination for posts.', 'chelsey-elements'),
		            "std" => array('false')
		        ),
			)
		)
	);
	vc_map( 
		array(
			"name" => __("Chelsey Portfolio Pinterest", 'chelsey-elements'),
			"base" => "portfoliopinterst",
			"icon" => 'chelsey-element-icon dashicons dashicons-portfolio',
			"category" => __('Chelsey Elements', 'chelsey-elements'),
			'description' => __('Portfolio in Pinterest Style.', 'chelsey-elements'),
			"params" => array(	
				array(
					"type" => "textfield",            
					"heading" => __("Post count", 'chelsey-elements'),
					"param_name" => "num",
					"value" => '3',
					'admin_label' => true,
					"description" => __("Enter number of posts to display (Note: Enter '-1' to display all posts).", 'chelsey-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Category slug", 'chelsey-elements'),
					"param_name" => "cat_slug",
					"value" => '',
					"description" => __("This help you to retrieve items from specific category. More than one separate by commas.", 'chelsey-elements')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Posts per row", 'chelsey-elements'),
					"param_name" => "columns",
					"value" => array(
					   __('Two', 'chelsey-elements')=>'span6',
					   __('Three', 'chelsey-elements')=>'span4',
					   __('Four', 'chelsey-elements')=>'span3',
					   __('Five', 'chelsey-elements')=>'one_fifth',
					   __('Six', 'chelsey-elements')=>'span2',
					),
					"description" => __("Select posts count per row.", 'chelsey-elements'),
					"std" => array('span3')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Post IDs", 'chelsey-elements'),
					"param_name" => "post_ids",
					"value" => '',
					"description" => __("Enter posts IDs to display only those records (Note: separate values by commas (,)).", 'chelsey-elements')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Sort order", 'chelsey-elements'),
					"param_name" => "order",
					"value" => array(
					   __('Descending', 'chelsey-elements')=>'DESC', 
					   __('Ascending', 'chelsey-elements')=>'ASC'
					),
					"description" => __('Select ascending or descending order.', 'chelsey-elements'),
					"std" => array('DESC')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Thumbnail size", 'chelsey-elements'),
					"param_name" => "thumbsize",
					"value" => $imageSizes,
					"description" => __('Select your image size to use.', 'chelsey-elements'),
					"std" => array('medium')
				),
			)
		)
	);
	vc_map( 
		array(
			"name" => __("Chelsey Portfolio Interactive Links", 'chelsey-elements'),
			"base" => "portfoliointeractivelinks",
			"icon" => 'chelsey-element-icon dashicons dashicons-portfolio',
			"category" => __('Chelsey Elements', 'chelsey-elements'),
			'description' => __('Portfolio with Interactive Links.', 'chelsey-elements'),
			"params" => array(	
				array(
					"type" => "textfield",            
					"heading" => __("Post count", 'chelsey-elements'),
					"param_name" => "num",
					"value" => '3',
					'admin_label' => true,
					"description" => __("Enter number of posts to display (Note: Enter '-1' to display all posts).", 'chelsey-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Category slug", 'chelsey-elements'),
					"param_name" => "cat_slug",
					"value" => '',
					"description" => __("This help you to retrieve items from specific category. More than one separate by commas.", 'chelsey-elements')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Post IDs", 'chelsey-elements'),
					"param_name" => "post_ids",
					"value" => '',
					"description" => __("Enter posts IDs to display only those records (Note: separate values by commas (,)).", 'chelsey-elements')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Post excerpt count", 'chelsey-elements'),
					"param_name" => "excerpt_count",
					"value" => '32',
					"description" => __("Enter number of words in post excerpt. 0 to hide it.", 'chelsey-elements')            
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Sort order", 'chelsey-elements'),
					"param_name" => "order",
					"value" => array(
					   __('Descending', 'chelsey-elements')=>'DESC', 
					   __('Ascending', 'chelsey-elements')=>'ASC'
					),
					"description" => __('Select ascending or descending order.', 'chelsey-elements'),
					"std" => array('DESC')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Thumbnail size", 'chelsey-elements'),
					"param_name" => "thumbsize",
					"value" => $imageSizes,
					"description" => __('Select your image size to use.', 'chelsey-elements'),
					"std" => array('medium')
				),
			)
		)
	);
	vc_map( 
		array(
			"name" => __("Chelsey Hover Portfolio", 'chelsey-elements'),
			"base" => "portfoliohover",
			"icon" => 'chelsey-element-icon dashicons dashicons-portfolio',
			"category" => __('Chelsey Elements', 'chelsey-elements'),
			'description' => __('Portfolio with Following Hover Effect.', 'chelsey-elements'),
			"params" => array(	
				array(
					"type" => "textfield",            
					"heading" => __("Post count", 'chelsey-elements'),
					"param_name" => "num",
					"value" => '3',
					'admin_label' => true,
					"description" => __("Enter number of posts to display (Note: Enter '-1' to display all posts).", 'chelsey-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Category slug", 'chelsey-elements'),
					"param_name" => "cat_slug",
					"value" => '',
					"description" => __("This help you to retrieve items from specific category. More than one separate by commas.", 'chelsey-elements')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Post IDs", 'chelsey-elements'),
					"param_name" => "post_ids",
					"value" => '',
					"description" => __("Enter posts IDs to display only those records (Note: separate values by commas (,)).", 'chelsey-elements')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Sort order", 'chelsey-elements'),
					"param_name" => "order",
					"value" => array(
					   __('Descending', 'chelsey-elements')=>'DESC', 
					   __('Ascending', 'chelsey-elements')=>'ASC'
					),
					"description" => __('Select ascending or descending order.', 'chelsey-elements'),
					"std" => array('DESC')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Thumbnail size", 'chelsey-elements'),
					"param_name" => "thumbsize",
					"value" => $imageSizes,
					"description" => __('Select your image size to use.', 'chelsey-elements'),
					"std" => array('medium')
				),
			)
		)
	);
	vc_map( 
		array(
			"name" => __("Chelsey Portfolio Carousel", 'chelsey-elements'),
			"base" => "portfoliocarousel",
			"icon" => 'chelsey-element-icon dashicons dashicons-slides',
			"category" => __('Chelsey Elements', 'chelsey-elements'),
			'description' => __('Portfolio Carousel.', 'chelsey-elements'),
			"params" => array(	
				array(
					"type" => "textfield",            
					"heading" => __("Posts block title", 'chelsey-elements'),
					"param_name" => "block_title",
					"value" => '',
					'admin_label' => true,
					"description" => __("Enter posts block title e.g. 'Resent works'. Leave blank if you need not to display it.", 'chelsey-elements')           
				),	
				array(
					"type" => "textfield",            
					"heading" => __("Post count", 'chelsey-elements'),
					"param_name" => "num",
					"value" => '3',
					'admin_label' => true,
					"description" => __("Enter number of posts to display (Note: Enter '-1' to display all posts).", 'chelsey-elements')            
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Posts per row", 'chelsey-elements'),
					"param_name" => "columns",
					"value" => array(
					   __('Two', 'chelsey-elements')=>'span6',
					   __('Three', 'chelsey-elements')=>'span4',
					   __('Four', 'chelsey-elements')=>'span3',
					   __('Five', 'chelsey-elements')=>'one_fifth',
					   __('Six', 'chelsey-elements')=>'span2',
					),
					"description" => __("Select posts count per row.", 'chelsey-elements'),
					"std" => array('span4')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Category slug", 'chelsey-elements'),
					"param_name" => "cat_slug",
					"value" => '',
					"description" => __("This help you to retrieve items from specific category. More than one separate by commas.", 'chelsey-elements')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Post IDs", 'chelsey-elements'),
					"param_name" => "post_ids",
					"value" => '',
					"description" => __("Enter posts IDs to display only those records (Note: separate values by commas (,)).", 'chelsey-elements')
				),
				array(
					"type" => "textfield",            
					"heading" => __("Post excerpt count", 'chelsey-elements'),
					"param_name" => "excerpt_count",
					"value" => '32',
					"description" => __("Enter number of words in post excerpt. 0 to hide it.", 'chelsey-elements')            
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Sort order", 'chelsey-elements'),
					"param_name" => "order",
					"value" => array(
					   __('Descending', 'chelsey-elements')=>'DESC', 
					   __('Ascending', 'chelsey-elements')=>'ASC'
					),
					"description" => __('Select ascending or descending order.', 'chelsey-elements'),
					"std" => array('DESC')
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Thumbnail size", 'chelsey-elements'),
					"param_name" => "thumbsize",
					"value" => $imageSizes,
					"description" => __('Select your image size to use.', 'chelsey-elements'),
					"std" => array('medium')
				),
			)
		)
	);
	vc_map( 
		array(
			"name" => __("Chelsey Portfolio Info", 'chelsey-elements'),
			"base" => "portfolioinfo",
			"icon" => 'chelsey-element-icon dashicons dashicons-info',
			"category" => __('Chelsey Elements', 'chelsey-elements'),
			'description' => __('Portfolio Info.', 'chelsey-elements'),
			"params" => array(	
				array(
					"type" => "dropdown",            
					"heading" => __("Info Style", 'chelsey-elements'),
					"param_name" => "style",
					"value" => array(
					   __('Standart', 'chelsey-elements')=>'standart',
					   __('Left align', 'chelsey-elements')=>'left_align',
					),
					"std" => array('simple')
				),
				array(
		            "type" => "dropdown",            
		            "heading" => __("Show share icons", 'chelsey-elements'),
		            "param_name" => "show_sharebox",
		            "value" => array(__('Yes','chelsey-elements')=>'true', __('No', 'chelsey-elements')=>'false'),
		            "description" => __('Show share icons', 'chelsey-elements'),
		            "std" => array('true')
		        ),				
			)
		)
	);
	vc_map( 
		array(
			"name" => __("Chelsey Socials", 'chelsey-elements'),
			"base" => "chelseysocials",
			"icon" => 'chelsey-element-icon dashicons dashicons-share',
			"category" => __('Chelsey Elements', 'chelsey-elements'),
			'description' => __('Show social icons: facebook, twitter, pinterest, etc.', 'chelsey-elements'),
			"params" => array(		
				array(
					"type" => "dropdown",            
					"heading" => __("Size", 'chelsey-elements'),
					"param_name" => "size",
					"value" => array(
		            	esc_html__('Small','chelsey-elements') => 'small',
		            	esc_html__('Big','chelsey-elements') => 'big',
		            ),
					'admin_label' => true,
					"description" => __("Choose size for icons", 'chelsey-elements')            
				),
				array(
					"type" => "dropdown",            
					"heading" => __("Color Scheme", 'chelsey-elements'),
					"param_name" => "color_scheme",
					"value" => array(
		            	esc_html__('Light','chelsey-elements') => 'light',
		            	esc_html__('Dark','chelsey-elements') => 'dark',
		            ),
					'admin_label' => true,
					"description" => __("Choose color scheme", 'chelsey-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Facebook", 'chelsey-elements'),
					"param_name" => "facebook",
					'admin_label' => true,
					"value" => '',
					"description" => __("Enter link to your account (profile).", 'chelsey-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Twitter", 'chelsey-elements'),
					"param_name" => "twitter",
					'admin_label' => true,
					"value" => '',
					"description" => __("Enter link to your account (profile).", 'chelsey-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Pinterest", 'chelsey-elements'),
					"param_name" => "pinterest",
					'admin_label' => true,
					"value" => '',
					"description" => __("Enter link to your account (profile).", 'chelsey-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Instagram", 'chelsey-elements'),
					"param_name" => "instagram",
					'admin_label' => true,
					"value" => '',
					"description" => __("Enter link to your account (profile).", 'chelsey-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Tumblr", 'chelsey-elements'),
					"param_name" => "tumblr",
					'admin_label' => true,
					"value" => '',
					"description" => __("Enter link to your account (profile).", 'chelsey-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Behance", 'chelsey-elements'),
					"param_name" => "behance",
					'admin_label' => true,
					"value" => '',
					"description" => __("Enter link to your account (profile).", 'chelsey-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Dribbble", 'chelsey-elements'),
					"param_name" => "dribbble",
					'admin_label' => true,
					"value" => '',
					"description" => __("Enter link to your account (profile).", 'chelsey-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Youtube", 'chelsey-elements'),
					"param_name" => "youtube",
					'admin_label' => true,
					"value" => '',
					"description" => __("Enter link to your account (profile).", 'chelsey-elements')            
				),
				array(
					"type" => "textfield",            
					"heading" => __("Rss", 'chelsey-elements'),
					"param_name" => "rss",
					'admin_label' => true,
					"value" => '',
					"description" => __("Enter link to rss.", 'chelsey-elements')            
				),	
			)
		)
	);
	
	vc_map( 
		array(
			"name" => __("Chelsey Google Map", 'chelsey-elements'),
			"base" => "chelseygooglemap",
			"icon" => 'chelsey-element-icon dashicons dashicons-location',
			"category" => __('Chelsey Elements', 'chelsey-elements'),
			'description' => __('Display styled google map', 'chelsey-elements'),
			"params" => array(
				array(
					"type" => "textfield",            
					"heading" => __("Location", 'chelsey-elements'),
					"param_name" => "address",
					"value" => 'Ontario, CA, USA',
					"description" => __("Enter your location.", 'chelsey-elements'),
					'admin_label' => true,            
				),
				array(
		            "type" => "dropdown",            
		            "heading" => __("Style", 'chelsey-elements'),
		            "param_name" => "style",
		            "value" => array(
		            	esc_html__('Blue water','chelsey-elements') => 'style1',
		            	esc_html__('Simple grayscale','chelsey-elements') => 'style2',
		            	esc_html__('Light monochrome','chelsey-elements') => 'style3'
		            ),
		            "description" => __('Select google map style.', 'chelsey-elements'),
		            'admin_label' => true,
		        ),		
				array(
					"type" => "attach_image",            
					"heading" => __("Map marker", 'chelsey-elements'),
					"param_name" => "marker_icon",
					"value" => '',
					"description" => __("Select image for your map location icon. Leave blank to use default marker.", 'chelsey-elements')          
				),
				array(
					"type" => "textfield",            
					"heading" => __("Map height", 'chelsey-elements'),
					"param_name" => "map_height",
					"value" => '300px',
					"description" => __("Enter height for map. You can use px, %, em, etc", 'chelsey-elements'),
					'admin_label' => true,            
				),
			)
		)
	);
}
?>