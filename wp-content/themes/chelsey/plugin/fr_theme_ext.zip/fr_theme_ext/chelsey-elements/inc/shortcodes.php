<?php
if( !function_exists('ChelseyGridPosts') ){
	function ChelseyGridPosts($atts, $content = null){
	    wp_enqueue_script('isotope');
		wp_enqueue_script('infinite-scroll');
		extract(shortcode_atts(array(
	      	'num' => '3',
	      	'columns' => 'span4',
	      	'post_style' => 'style_1',
	      	'orderby' => 'date',
	      	'order' => 'DESC',
	      	'cat_slug' => '',
	      	'post_ids' => '',
	      	'pagination' => 'false',
	      	'thumbsize'		=> 'post-thumbnail',
	      	'text_align' => '',
	      	'excerpt_count'	=> '32',
	      	'show_sharebox' => 'true',
	    ), $atts));

	    global $post;
		if ( is_front_page() ) {
			$paged = (get_query_var('page')) ? get_query_var('page') : 1;
		} else {
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		}
		if($post_ids != ''){
			$post_ids = str_replace(' ', '', $post_ids);
			if (strpos($post_ids, ',') !== false){
				$post_ids = explode(',', $post_ids);
			} else {
				$post_ids = array($post_ids);
			}
		} else {
			$post_ids = array();
		}
		$show_sharebox = ($show_sharebox === 'true');
		$args = array(
			'post_type' => 'post',
			'posts_per_page' => $num,
			'post__in' => $post_ids,
			'paged' => $paged,
			'order'          => $order,
			'orderby'        => $orderby,
			'post_status'    => 'publish',	
		);
		if($cat_slug != '' && $cat_slug != 'all'){
			$str = str_replace(' ', '', $cat_slug);
			$arr = explode(',', $str);	  
			$args['tax_query'][] = array(
			  'taxonomy'  => 'category',
			  'field'   => 'slug',
			  'terms'   => $arr
			);
		}
		
		$more_link_text = 'Read More';
		$strip_teaser = '';
		static $post_section_id = 0;
		$out = '';
		++$post_section_id;
		query_posts( $args );
		if( have_posts() ) {
			$out .= '<div id="latest-posts">';
			$out .= '<div id="blog-posts-'.$post_section_id.'" class="row-fluid blog-posts masonry_layout">';
			while ( have_posts() ) {
				the_post();
				$tmpContent = get_the_content();
				$separator = '';
				if (get_theme_mod( 'chelsey_posts_headings_separator', true ) ) $separator = ' separator';
				$classes = join(' ', get_post_class($post->ID));
				$classes .= ' post';
					$classes = str_replace('sticky ', '', $classes);
					$out .= '<article class="entry post-size '.$columns.' '.$post_style.' '.$classes.'">';
												
							$out .= '<div class="post-content-container">';
							if( has_post_format('quote') ) {
								$out .= '<div class="post-content">';
									$out .= '<div class="post-excerpt">'.get_the_content( $more_link_text, $strip_teaser ).'</div>';	
								$out .= '</div>';
							}else if( has_post_format('link') ) {
								$out .= '<div class="frgn_post_mark"><i class="pe-7s-link"></i></div>';
								$out .= '<div class="post-content">';
									$out .= '<div class="post-excerpt">'.get_the_content( $more_link_text, $strip_teaser ).'</div>';	
								$out .= '</div>';
							}else{
								if( has_post_thumbnail() ) {
									$out .= '<div class="featured_box">';
										if( has_post_format('video') ) {
											 $out .= '<div class="frgn_post_format frgn_video"><i class="pe-7s-video"></i></div>';
										}
										if( has_post_format('gallery') ) {
											 $out .= '<div class="frgn_post_format frgn_video"><i class="pe-7s-albums"></i></div>';
										}
									$out .= '<a href="'.esc_url(get_the_permalink()).'" rel="bookmark">'.get_the_post_thumbnail($post->ID, $thumbsize).'</a></div>';
								}
								$out .= '<div class="post-content">';
								$out .= '<header class="entry-header">';
									$out .= '<span class="meta">'.get_the_category_list(',').'</span><span class="frgn_sep"></span><span class="meta date_time">' .get_the_time( get_option( 'date_format')) .'</span>';							
									$out .= '<h2 class="entry-title"><a href="'.get_the_permalink().'" title="'.esc_html__('Permalink to', 'chelsey-elements').' '.esc_attr(the_title_attribute('echo=0')).'" rel="bookmark">'.get_the_title().'</a></h2>';							
								$out .= '</header>';
								
								if( $excerpt_count > 0 ){
									$out .= '<div class="post-excerpt">'.ChelseyExcerpt($excerpt_count).'</div>';
								}
								
								//$out .= '<a class="readmore" href="'.esc_url(get_the_permalink()).'" rel="bookmark">View Post</a>';
								$out .= '</div>';
								if( $show_sharebox ){
									$out .= ChelseySharebox(get_the_ID(), false);
								}
							}
						$out .= '</div>';
					$out .= '</article>';
				
			}
			$out .= '</div>';
		}
		
		$out .= '<div class="page-load-status">
			  <p class="infinite-scroll-request">Loading...</p>
			  <p class="infinite-scroll-last">End of content</p>
			  <p class="infinite-scroll-error">No more pages to load</p>
			</div>';
		
		if( $pagination == 'true' && get_next_posts_link() ) {
			$out .= '<div id="pagination" class="hide">'.get_next_posts_link().'</div>';
			$out .= '<div class="loadmore-container"><a href="#" class="loadmore button"><span>'.esc_html__('Load More','Chelsey').'</span></a></div>';
		}
		
		$out .= '</div>';
		wp_reset_query();
		return $out;
	}
	add_shortcode('gridposts', 'ChelseyGridPosts');
}

if( !function_exists('ChelseyCarouselPosts') ){
	function ChelseyCarouselPosts($atts, $content = null){
		wp_enqueue_script('owl-carousel');
		wp_enqueue_style( 'owl-carousel' );
	    extract(shortcode_atts(array(
	      	'block_title' => '',
	      	'posts_count' => '3',
	      	'columns' => 'span4',
	      	'orderby' => 'date',
	      	'order' => 'DESC',
	      	'cat_slug' => '',
	      	'post_ids' => '',
	      	'thumbsize' => 'medium',
			'color_sheme' => '',
	    ), $atts));

	    global $post;
		if ( is_front_page() ) {
			$paged = (get_query_var('page')) ? get_query_var('page') : 1;
		} else {
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		}
		if($post_ids != ''){
			$post_ids = str_replace(' ', '', $post_ids);
			$post_ids = explode(',', $post_ids);
		} else {
			$post_ids = array();
		}
		$args = array(
			'post_type' => 'post',
			'posts_per_page' => $posts_count,
			'post__in' => $post_ids,
			//'paged' => $paged,
			'order'          => $order,
			'orderby'        => $orderby,
			'post_status'    => 'publish',
		);

		if($cat_slug != '' && $cat_slug != 'all'){
			$str = $cat_slug;
			$arr = explode(',', $str);
			$args['tax_query'][] = array(
			  'taxonomy'  => 'category',
			  'field'   => 'slug',
			  'terms'   => $arr
			);
		}
		switch ($columns) {
			case 'span6':
				$items = '2';
				break;
			case 'span4':
				$items = '3';
				break;
			case 'span3':
				$items = '4';
				break;
			case 'span2':
				$items = '6';
				break;
			default:
				$items = '5';
				break;
		}
		static $post_section_id = 0;
		$out = '';
		++$post_section_id;
		query_posts( $args );
		if( have_posts() ) {
			if($posts_count > $items){
				$columns = '';
				$owl_custom = 'jQuery(document).ready(function($){
					"use strict";
					setTimeout(function(){ var owl = $("#recent-posts-slider-'.$post_section_id.'").owlCarousel(
				    {
				        items: '.$items.',
				        margin: 0,
				        dots: false,
						nav: true,
				        navText: [\'<i class="pe-7s-angle-left"></i>\',\'<i class="pe-7s-angle-right"></i>\'],
				        autoplay: true,
				        responsiveClass:true,
				        loop: false,
				        smartSpeed: 450,
				        autoHeight: false,
						responsive : {
							0 : {
								items : 1,
							},
							480 : {
								items : 1,
							},
							768 : {
								items : 2,
							},
							1024 : {
								items : 3,
							},
							1440 : {
								items : '.$items.',
							}
						}';
					    $owl_custom .= '});
						$(window).load(function(){
							owl.trigger(\'refresh.owl.carousel\');
						});
					}, 10);
				});';
				wp_add_inline_script('owl-carousel', $owl_custom);
			}
			if($block_title != ''){
				$out .= '<div class="block-title title"><h3>'.esc_html($block_title).'</h3></div>';
			}
			$out .= '<div id="recent-posts-slider-'.$post_section_id.'" class="recent-posts  '.$color_sheme.' ">';
			while ( have_posts() ) {
				the_post();
				$out .= '<div class="recent-post-item clearfix '.$columns.' ">';
					if( has_post_thumbnail() ) {
						$out .= '<figure class="post-img"><a href="'.esc_url(get_the_permalink()).'" rel="bookmark">'.get_the_post_thumbnail($post->ID, $thumbsize).'</a></figure>';
					} else {
						$out .= '<figure class="post-img"><a href="'.esc_url(get_the_permalink()).'" rel="bookmark"><img src="https://placeholdit.imgix.net/~text?txtsize=42&txt=Your+image+here&w=470&h=390" alt="placeholder image"></a></figure>';
					}
					$out .= '<div class="post-more clearfix">';
						//$out .= '<span class="meta">'.get_the_category_list(',').'</span>';
						$out .= '<div class="title"><h3><a href="'.esc_url(get_the_permalink()).'" title="'.esc_html__('Permalink to', 'chelsey-elements').' '.esc_attr(the_title_attribute('echo=0')).'" rel="bookmark">'.esc_attr(get_the_title()).'</a></h3></div>';
						$out .= '<span class="meta date_time">' .get_the_time( get_option( 'date_format')) .'</span>';
					$out .= '</div>';
				$out .= '</div>';
			}
			$out .= '</div>';
			wp_reset_query();
		}
		return $out;
	}
	add_shortcode('carouselposts', 'ChelseyCarouselPosts');
}

if( !function_exists('ChelseyPortfolioMetro') ){
	function ChelseyPortfolioMetro($atts, $content = null){
		wp_enqueue_script('infinite-scroll');
		extract(shortcode_atts(array(
	      	'num' => '6',
	      	'columns' => 'span4',
	      	'style' => 'classic',
	      	'post_style' => 'style_1',
	      	'orderby' => 'date',
	      	'order' => 'DESC',
	      	'cat_slug' => '',
	      	'post_ids' => '',
	      	'pagination' => 'false',
	      	'thumbsize'		=> 'post-thumbnail',
	      	'text_align' => '',
	      	'excerpt_count'	=> '32',
	      	'show_sharebox' => 'true',
	    ), $atts));

	    global $post;
		if ( is_front_page() ) {
			$paged = (get_query_var('page')) ? get_query_var('page') : 1;
		} else {
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		}
		if($post_ids != ''){
			$post_ids = str_replace(' ', '', $post_ids);
			if (strpos($post_ids, ',') !== false){
				$post_ids = explode(',', $post_ids);
			} else {
				$post_ids = array($post_ids);
			}
		} else {
			$post_ids = array();
		}
		
		$args = array(
			'post_type' => 'post',
			'posts_per_page' => $num,
			'post__in' => $post_ids,
			'paged' => $paged,
			'order'          => $order,
			'orderby'        => $orderby,
			'post_status'    => 'publish',	
		);
		if($cat_slug != '' && $cat_slug != 'all'){
			$str = str_replace(' ', '', $cat_slug);
			$arr = explode(',', $str);	  
			$args['tax_query'][] = array(
			  'taxonomy'  => 'category',
			  'field'   => 'slug',
			  'terms'   => $arr
			);
		}
	
		static $post_section_id = 0;	
		
		$out = '';			
		++$post_section_id;
		query_posts( $args );
		if( have_posts() ) {
		
			/*$categories  = (is_array($cat_slug)) ? $cat_slug : explode(',', $cat_slug);
			$out .= '<div class="button-group filter-button-group">';
			$out .= '<button data-filter="*"><span>show all</span><span class="num"></span></button>';
			foreach($categories as $cat){
				$filter		= (isset($cat->slug) && $cat->slug !== '*' ) ? '.cat'.esc_attr($cat->term_id) : '*';
				$title = $cat->name;
				echo $title;
				$out .= '<button data-filter=".'.$cat.'" class="'.$cat.'">' . $cat. '</button>';
			}				
			$out .= '</div>';*/
		
		
			$out .= '<div id="frgn-portfolio-metro-'.$post_section_id.'" class="frgn-portfolio-list-holder-outer -container">';
			$out .= '<div class="portfolio_metro clearfix row '.$style.' '.$columns.'">';
			while ( have_posts() ) {
				the_post();
				$tmpContent = get_the_content();
				$separator = '';
				if (get_theme_mod( 'chelsey_posts_headings_separator', true ) ) $separator = ' separator';
				$classes = join(' ', get_post_class($post->ID));
				$classes .= ' post';			
				
				$post_width = rwmb_meta( 'chelsey_portfolio_layout' );				
				$post_height = rwmb_meta( 'chelsey_portfolio_height' );	
				
				if($style == 'floating') $post_move = 'data-bottom="transform:translateY(20%)" data-center-bottom="transform:translateY(0%)"';
				
				$cat_name = '';
				foreach( get_the_category() as $category ){ 
					$cat_name .= $category->name; 
				} 				
				
					$classes = str_replace('sticky ', '', $classes);
					$out .= '<article class="entry portfolio_metro_item '.$post_width.' '.$post_height.' '.$cat_name.'" '.$post_move.'>';
						
					$out .= '<div class="portfolio_wrap">';
					if( has_post_thumbnail() ) {
						$out .= '<div class="featured_box">';
						$out .= get_the_post_thumbnail($post->ID, $thumbsize).'</div>';						
					}	
						$out .= '<div class="portfolio_metro_inner">';
						$out .= '<header class="entry-header">';							
							$out .= '<span class="meta">'.get_the_category_list(',').'</span>';								
							$out .= '<h2 class="entry-title"><div class="frgn-title-decorative-letter"></div><a href="'.get_the_permalink().'" title="'.esc_html__('Permalink to', 'chelsey-elements').' '.esc_attr(the_title_attribute('echo=0')).'" rel="bookmark">'.get_the_title().'</a></h2>';
						$out .= '</header>';						
						$out .= '</div>';						
					$out .= '</div>';
					
				$out .= '</article>';
			} //while
			$out .= '</div>';
			$out .= '</div>';
		}
		
		$out .= '<div class="page-load-status">
			  <p class="infinite-scroll-request">Loading...</p>
			  <p class="infinite-scroll-last">End of content</p>
			  <p class="infinite-scroll-error">No more pages to load</p>
			</div>';
		
		if( $pagination == 'true' && get_next_posts_link() ) {
			$out .= '<div id="pagination" class="hide">'.get_next_posts_link().'</div>';
			$out .= '<div class="loadmore-container"><a href="#" class="loadmore button"><span>'.esc_html__('Load More','Chelsey').'</span></a></div>';
		}
		wp_reset_query();
		return $out;
	}
	add_shortcode('portfoliometro', 'ChelseyPortfolioMetro');
}

if( !function_exists('ChelseyPortfolioPinterest') ){
	function ChelseyPortfolioPinterest($atts, $content = null){
		extract(shortcode_atts(array(
	      	'num' => '6',
	      	'columns' => 'span4',
	      	'post_style' => 'style_1',
	      	'orderby' => 'date',
	      	'order' => 'DESC',
	      	'cat_slug' => '',
	      	'post_ids' => '',
	      	'pagination' => 'false',
	      	'thumbsize'		=> 'post-thumbnail',
	      	'text_align' => '',
	      	'excerpt_count'	=> '32',
	      	'show_sharebox' => 'true',
	    ), $atts));

	    global $post;
		if ( is_front_page() ) {
			$paged = (get_query_var('page')) ? get_query_var('page') : 1;
		} else {
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		}
		if($post_ids != ''){
			$post_ids = str_replace(' ', '', $post_ids);
			if (strpos($post_ids, ',') !== false){
				$post_ids = explode(',', $post_ids);
			} else {
				$post_ids = array($post_ids);
			}
		} else {
			$post_ids = array();
		}
		$args = array(
			'post_type' => 'post',
			'posts_per_page' => $num,
			'post__in' => $post_ids,
			'paged' => $paged,
			'order'          => $order,
			'orderby'        => $orderby,
			'post_status'    => 'publish',	
		);
		if($cat_slug != '' && $cat_slug != 'all'){
			$str = str_replace(' ', '', $cat_slug);
			$arr = explode(',', $str);	  
			$args['tax_query'][] = array(
			  'taxonomy'  => 'category',
			  'field'   => 'slug',
			  'terms'   => $arr
			);
		}
	
		$out = '';			
		++$post_section_id;
		query_posts( $args );
		if( have_posts() ) {		
		
			$out .= '<div id="frgn-portfolio-pinterest-'.$post_section_id.'" class="frgn-portfolio-list-holder-outer">';
			$out .= '<div class="portfolio_pinterest clearfix '.$columns.'">';
			while ( have_posts() ) {
				the_post();
				$tmpContent = get_the_content();
				$separator = '';
				if (get_theme_mod( 'chelsey_posts_headings_separator', true ) ) $separator = ' separator';
				$classes = join(' ', get_post_class($post->ID));
				$classes .= ' post';			
				
				$cat_name = '';
				foreach( get_the_category() as $category ){ 
					$cat_name .= $category->name; 
				} 				
				
					$classes = str_replace('sticky ', '', $classes);
					$out .= '<article class="entry portfolio_metro_item '.$cat_name.'">';
						
					$out .= '<div class="portfolio_wrap">';
					if( has_post_thumbnail() ) {
						$out .= '<div class="featured_box">';
						$out .= get_the_post_thumbnail($post->ID, $thumbsize).'</div>';						
					}	
						$out .= '<div class="portfolio_metro_inner">';
						$out .= '<header class="entry-header">';							
							$out .= '<span class="meta">'.get_the_category_list(',').'</span>';								
							$out .= '<h2 class="entry-title"><div class="frgn-title-decorative-letter"></div><a href="'.get_the_permalink().'" title="'.esc_html__('Permalink to', 'chelsey-elements').' '.esc_attr(the_title_attribute('echo=0')).'" rel="bookmark">'.get_the_title().'</a></h2>';
							$out .= '<div class="portfolio_metro_btn_holder"><a class="portfolio_metro_btn" href="'.get_the_permalink().'"></a></div>';
						$out .= '</header>';						
						$out .= '</div>';
					$out .= '</div>';
					
				$out .= '</article>';
			} //while
			$out .= '</div>';
			$out .= '</div>';
		}
		
		$out .= '<div class="page-load-status">
			  <p class="infinite-scroll-request">Loading...</p>
			  <p class="infinite-scroll-last">End of content</p>
			  <p class="infinite-scroll-error">No more pages to load</p>
			</div>';
		
		if( $pagination == 'true' && get_next_posts_link() ) {
			$out .= '<div id="pagination" class="hide">'.get_next_posts_link().'</div>';
			$out .= '<div class="loadmore-container"><a href="#" class="loadmore button"><span>'.esc_html__('Load More','Chelsey').'</span></a></div>';
		}
		wp_reset_query();
		return $out;
	}
	add_shortcode('portfoliopinterst', 'ChelseyPortfolioPinterest');
}

if( !function_exists('ChelseyPortfolioInteractiveLinks') ){
	function ChelseyPortfolioInteractiveLinks($atts, $content = null){
		extract(shortcode_atts(array(
	      	'num' => '6',
	      	'columns' => 'span4',
	      	'post_style' => 'style_1',
	      	'orderby' => 'date',
	      	'order' => 'DESC',
	      	'cat_slug' => '',
	      	'post_ids' => '',
	      	'pagination' => 'false',
	      	'thumbsize' => 'chelsey-interactive-links',
	      	'text_align' => '',
	      	'excerpt_count'	=> '32',
	      	'show_sharebox' => 'true',
	    ), $atts));

	    global $post;
		if ( is_front_page() ) {
			$paged = (get_query_var('page')) ? get_query_var('page') : 1;
		} else {
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		}
		if($post_ids != ''){
			$post_ids = str_replace(' ', '', $post_ids);
			if (strpos($post_ids, ',') !== false){
				$post_ids = explode(',', $post_ids);
			} else {
				$post_ids = array($post_ids);
			}
		} else {
			$post_ids = array();
		}
		$args = array(
			'post_type' => 'post',
			'posts_per_page' => $num,
			'post__in' => $post_ids,
			'paged' => $paged,
			'order'          => $order,
			'orderby'        => $orderby,
			'post_status'    => 'publish',	
		);
		if($cat_slug != '' && $cat_slug != 'all'){
			$str = str_replace(' ', '', $cat_slug);
			$arr = explode(',', $str);	  
			$args['tax_query'][] = array(
			  'taxonomy'  => 'category',
			  'field'   => 'slug',
			  'terms'   => $arr
			);
		}
	
		static $post_section_id = 0;
		$out = '';
		++$post_section_id;
		query_posts( $args );
		if( have_posts() ) {
			$out .= '<div id="frgn-portfolio-interactive-'.$post_section_id.'" class="frgn-interactive-links frgn-portfolio-interactive-holder">';
				while ( have_posts() ) {
					the_post();
					$tmpContent = get_the_content();
					$separator = '';
					if (get_theme_mod( 'chelsey_posts_headings_separator', true ) ) $separator = ' separator';
					$classes = join(' ', get_post_class($post->ID));
					$classes .= ' post';	

					$fullsize = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'chelsey-article-thumb');					
					
					$classes = str_replace('sticky ', '', $classes);
					$out .= '<article>';	
						if( has_post_thumbnail() ) {
							$out .= '<div class="featured_box">';
							$out .= get_the_post_thumbnail($post->ID, $thumbsize).'</div>';						
						}
						$out .= '';							
						$out .= '<h2 class="entry-title"><br /><a href="'.get_the_permalink().'" title="'.esc_html__('Permalink to', 'chelsey-elements').' '.esc_attr(the_title_attribute('echo=0')).'" rel="bookmark">'.get_the_title().'</a></h2>';					
					$out .= '</article>';
				} //while
			$out .= '</div>';
		}		
		wp_reset_query();
		return $out;
	}
	add_shortcode('portfoliointeractivelinks', 'ChelseyPortfolioInteractiveLinks');
}

if( !function_exists('ChelseyHoverPortfolio') ){
	function ChelseyHoverPortfolio($atts, $content = null){
		wp_enqueue_script('hoverdir');
		wp_enqueue_style( 'hoverdir-css' );
		extract(shortcode_atts(array(
	      	'num' => '6',
	      	'columns' => 'span4',
	      	'post_style' => 'style_1',
	      	'orderby' => 'date',
	      	'order' => 'DESC',
	      	'cat_slug' => '',
	      	'post_ids' => '',
	      	'pagination' => 'false',
	      	'thumbsize'		=> 'post-thumbnail',
	      	'text_align' => '',
	      	'excerpt_count'	=> '32',
	      	'show_sharebox' => 'true',
	    ), $atts));

	    global $post;
		if ( is_front_page() ) {
			$paged = (get_query_var('page')) ? get_query_var('page') : 1;
		} else {
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		}
		if($post_ids != ''){
			$post_ids = str_replace(' ', '', $post_ids);
			if (strpos($post_ids, ',') !== false){
				$post_ids = explode(',', $post_ids);
			} else {
				$post_ids = array($post_ids);
			}
		} else {
			$post_ids = array();
		}
		$args = array(
			'post_type' => 'post',
			'posts_per_page' => $num,
			'post__in' => $post_ids,
			'paged' => $paged,
			'order'          => $order,
			'orderby'        => $orderby,
			'post_status'    => 'publish',	
		);
		if($cat_slug != '' && $cat_slug != 'all'){
			$str = str_replace(' ', '', $cat_slug);
			$arr = explode(',', $str);	  
			$args['tax_query'][] = array(
			  'taxonomy'  => 'category',
			  'field'   => 'slug',
			  'terms'   => $arr
			);
		}
	
		static $post_section_id = 0;
		$out = '';
		++$post_section_id;
		query_posts( $args );
		if( have_posts() ) {
			$out .= '<ul id="da-thumbs" class="da-thumbs frgn-portfolio-hover">';
				while ( have_posts() ) {
					the_post();
					$tmpContent = get_the_content();
					$separator = '';
					if (get_theme_mod( 'chelsey_posts_headings_separator', true ) ) $separator = ' separator';
					$classes = join(' ', get_post_class($post->ID));
					$classes .= ' post';	

					$fullsize = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'chelsey-article-thumb');

					$cat_name = '';
					foreach( get_the_category() as $category ){ 
						$cat_name .= $category->name; 
					} 	
					
					$classes = str_replace('sticky ', '', $classes);
					$out .= '<li>';	
						
						$out .= '';							
						$out .= '<a href="'.get_the_permalink().'" title="'.esc_html__('Permalink to', 'chelsey-elements').' '.esc_attr(the_title_attribute('echo=0')).'" rel="bookmark">';
						if( has_post_thumbnail() ) {
							$out .= get_the_post_thumbnail($post->ID, $thumbsize);						
						}				
						$out .= '<div><header class="entry-header"><span class="meta">'.$cat_name.'</span><h2><span class="frgn-title-decorative-letter"></span>'.get_the_title().'</h2></header></div>';
						$out .= '</a>';					
					$out .= '</li>';
				} //while
			$out .= '</ul>';
		}		
		wp_reset_query();
		return $out;
	}
	add_shortcode('portfoliohover', 'ChelseyHoverPortfolio');
}

if( !function_exists('ChelseyPortfolioCarousel') ){
	function ChelseyPortfolioCarousel($atts, $content = null){
		wp_enqueue_script('owl-carousel');
		wp_enqueue_style( 'owl-carousel' );
		wp_enqueue_style( 'mousewheel' );
		extract(shortcode_atts(array(
			'block_title' => '',
	      	'num' => '6',
	      	'columns' => 'span4',
	      	'orderby' => 'date',
	      	'order' => 'DESC',
	      	'cat_slug' => '',
	      	'post_ids' => '',
	      	'pagination' => 'false',
	      	'thumbsize'		=> 'post-thumbnail',
	      	'text_align' => '',
	      	'excerpt_count'	=> '32',
	    ), $atts));

	    global $post;
		if ( is_front_page() ) {
			$paged = (get_query_var('page')) ? get_query_var('page') : 1;
		} else {
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		}
		if($post_ids != ''){
			$post_ids = str_replace(' ', '', $post_ids);
			if (strpos($post_ids, ',') !== false){
				$post_ids = explode(',', $post_ids);
			} else {
				$post_ids = array($post_ids);
			}
		} else {
			$post_ids = array();
		}
		$args = array(
			'post_type' => 'post',
			'posts_per_page' => $num,
			'post__in' => $post_ids,
			'paged' => $paged,
			'order'          => $order,
			'orderby'        => $orderby,
			'post_status'    => 'publish',	
		);
		if($cat_slug != '' && $cat_slug != 'all'){
			$str = str_replace(' ', '', $cat_slug);
			$arr = explode(',', $str);	  
			$args['tax_query'][] = array(
			  'taxonomy'  => 'category',
			  'field'   => 'slug',
			  'terms'   => $arr
			);
		}
	
		static $post_section_id = 0;
		$out = '';
		++$post_section_id;
		query_posts( $args );
		if( have_posts() ) {
			$out .= '<div id="frgn-portfolio-carousel-'.$post_section_id.'" class="frgn-portfolio-carousel-holder">';
			$out .= '<div class="frgn-portfolio-carousel-title"><h2>' .$block_title .'</h2></div>';	
			$out .= '<div class="owl-carousel frgn-portfolio-carousel">';	
				while ( have_posts() ) {
					the_post();
					$tmpContent = get_the_content();
					
					$classes = join(' ', get_post_class($post->ID));
					$classes .= ' post';						
					
					$classes = str_replace('sticky ', '', $classes);
					$out .= '<div class="owl-inner"><div class="overlay"></div>';						
						$out .= get_the_post_thumbnail($post->ID, $thumbsize);						 
						$out .= '<div class="frgn-portfolio-carousel-title-holder"><div class="slider-counter"></div>';
						$out .= '<span class="meta">'.get_the_category_list(',').'</span>';
						$out .= '<h2><a href="'.get_the_permalink().'" title="'.esc_html__('Permalink to', 'chelsey-elements').' '.esc_attr(the_title_attribute('echo=0')).'" rel="bookmark">'.get_the_title().'</a></h2></div>';
					$out .= '</div>';
					
				} //while
			
			$out .= '</div>';
			$out .= '</div>';
		}		
		wp_reset_query();
		return $out;
	}
	add_shortcode('portfoliocarousel', 'ChelseyPortfolioCarousel');
}
if( !function_exists('ChelseyPortfolioInfo') ){
	function ChelseyPortfolioInfo($atts, $content = null){
		extract(shortcode_atts(array(
	      	'style' => 'standart',
	      	'show_sharebox' => 'true',
	      	'post_ids' => '',
	      	'text_align' => '',
	    ), $atts));

	    global $post;
		
		$show_sharebox = ($show_sharebox === 'true');
		
			$out = '<div class="frgn-portfolio-info-holder">';
			$out .= '<div class="frgn-portfolio-info ' .$style. '">';	
				
					$tmpContent = get_the_content();					
					
					$project_client = rwmb_meta( 'chelsey_project_client' );				
					$project_skills = rwmb_meta( 'chelsey_project_skills' );
					
					$out .= '<div><h3>Clients:</h3><p class="portfolio_info">'.$project_client.'</p></div>';						
					$out .= '<div><h3>Skills:</h3><p class="portfolio_info">'.$project_skills.'</p></div>';						
					$out .= '<div><h3>Category:</h3><p class="portfolio_info">'.get_the_category_list(',').'</p></div>';
					if( $show_sharebox ){
						$out .= '<h3>Share:</h3>' .ChelseySharebox(get_the_ID(), false);
					}  					
					$out .= '</div>';
			
			$out .= '</div>';
			$out .= '</div>';
				
		wp_reset_query();
		return $out;
	}
	add_shortcode('portfolioinfo', 'ChelseyPortfolioInfo');
}

if(!function_exists('ChelseySocials')){
	function ChelseySocials( $atts, $content = null) {
	extract( shortcode_atts( array(
        'size'   => '',
        'color_scheme'   => 'light',
        'twitter'   => '',
        'forrst'  => '',
        'dribbble'  => '',
        'flickr'    => '',
        'facebook'  => '',
        'skype'   => '',
        'digg'  => '',
        'google_plus'  => '',
        'linkedin'  => '',
        'vimeo'  => '',
        'instagram' => '',
        'yahoo'  => '',
        'tumblr'  => '',
        'youtube'  => '',
        'picasa'  => '',
        'deviantart'  => '',
        'behance'  => '',
        'pinterest'  => '',
        'paypal'  => '',
        'delicious'  => '',
        'rss'  => ''
        ), $atts ) );

        $out = '<div class="social-icons text-left '.$size.' '.$color_scheme.'"><ul class="unstyled">';
		foreach ($atts as $key => $value) {
			switch ($key) {
				case 'twitter':
					if($twitter != "") {
					  $out .= '<li class="social-twitter"><a href="'.esc_url($twitter).'" target="_blank" title="'.esc_html__( 'Twitter', 'chelsey-elements').'">Tw</a></li>';
					}
					break;
				case 'facebook':
					if($facebook != "") {
					  $out .= '<li class="social-facebook"><a href="'.esc_url($facebook).'" target="_blank" title="'.esc_html__( 'Facebook', 'chelsey-elements').'">Fb</a></li>';
					}
				case 'forrst':
					if($forrst != "") {
					  $out .= '<li class="social-forrst"><a href="'.esc_url($forrst).'" target="_blank" title="'.esc_html__( 'Forrst', 'chelsey-elements').'"><i class="fab icon-forrst"></i></a></li>';
					}
					break;
				case 'yahoo':
					if($yahoo != "") {
					  $out .= '<li class="social-yahoo"><a href="'.esc_url($yahoo).'" target="_blank" title="'.esc_html__( 'Yahoo', 'chelsey-elements').'"><i class="fab fa-yahoo"></i></a></li>';
					}
					break;
				case 'vimeo':
					if($vimeo != "") {
					  $out .= '<li class="social-vimeo"><a href="'.esc_url($vimeo).'" target="_blank" title="'.esc_html__( 'Vimeo', 'chelsey-elements').'"><i class="fab fa-vimeo-square"></i></a></li>';
					}
					break;
				case 'linkedin':
					if($linkedin != "") {
					  $out .= '<li class="social-linkedin"><a href="'.esc_url($linkedin).'" target="_blank" title="'.esc_html__( 'LinkedIn', 'chelsey-elements').'"><i class="fab fa-linkedin"></i></a></li>';
					}
					break;
				case 'google_plus':
					if($google_plus != "") {
						$out .= '<li class="social-googleplus"><a href="'.esc_url($google_plus).'" target="_blank" title="'.esc_html__( 'Google plus', 'chelsey-elements').'"><i class="fab fa-google-plus"></i></a></li>';
					}
					break;
				case 'instagram':
					if($instagram != '') {
						$out .= '<li class="social-instagram"><a href="' .esc_url($instagram). '" target="_blank" title="'.esc_html__( 'Instagram', 'chelsey-elements').'">Ig</a></li>';
					}
					break;  
				case 'digg':
					if($digg != "") {
						$out .= '<li class="social-digg"><a href="'.esc_url($digg).'" target="_blank" title="'.esc_html__( 'Digg', 'chelsey-elements').'"><i class="fab fa-digg"></i></a></li>';
					}
					break;
				case 'skype':
					if($skype != "") {
						$out .= '<li class="social-skype"><a href="skype:'.$skype.'?call" title="'.esc_html__( 'Skype', 'chelsey-elements').'"><i class="fab fa-skype"></i></a></li>';
					}
					break;
				case 'flickr':
					if($flickr != "") { 
						$out .= '<li class="social-flickr"><a href="'.esc_url($flickr).'" target="_blank" title="'.esc_html__( 'Flickr', 'chelsey-elements').'"><i class="fab fa-flickr"></i></a></li>';
					}
					break;
				case 'dribbble':
					if($dribbble != "") {
						$out .= '<li class="social-dribbble"><a href="'.esc_url($dribbble).'" target="_blank" title="'.esc_html__( 'Dribbble', 'chelsey-elements').'">Dr</a></li>';
					}
					break;
				case 'tumblr':
					if($tumblr != "") {
						$out .= '<li class="social-tumblr"><a href="'.esc_url($tumblr).'" target="_blank" title="'.esc_html__( 'Tumblr', 'chelsey-elements').'">Tm</a></li>';
					}
				break;
				case 'youtube':
					if($youtube != "") {
						$out .= '<li class="social-youtube"><a href="'.esc_url($youtube).'" target="_blank" title="'.esc_html__( 'YouTube', 'chelsey-elements').'">Yt</a></li>';
					}
					break;
				case 'picasa':
					if($picasa != "") {
						$out .= '<li class="social-picasa"><a href="'.esc_url($picasa).'" target="_blank" title="'.esc_html__( 'Picasa', 'chelsey-elements').'">Pic</a></li>';
					}
					break;
				case 'deviantart':
					if($deviantart != "") {
						$out .= '<li class="social-deviantart"><a href="'.esc_url($deviantart).'" target="_blank" title="'.esc_html__( 'DeviantArt', 'chelsey-elements').'">Dev</a></li>';
					}
					break;
				case 'behance':
					if($behance != "") {
						$out .= '<li class="social-behance"><a href="'.esc_url($behance).'" target="_blank" title="'.esc_html__( 'Behance', 'chelsey-elements').'">Be</a></li>';
					}
					break;
				case 'pinterest':
					if($pinterest != "") {
						$out .= '<li class="social-pinterest"><a href="'.esc_url($pinterest).'" target="_blank" title="'.esc_html__( 'Pinterest', 'chelsey-elements').'">Pn</a></li>';
					}
					break;
				case 'paypal':
					if($paypal != "") {
						$out .= '<li class="social-paypal"><a href="'.esc_url($paypal).'" target="_blank" title="'.esc_html__( 'PayPal', 'chelsey-elements').'">Pay</a></li>';
					}
					break;
				case 'delicious':
					if($delicious != "") {
						$out .= '<li class="social-delicious"><a href="'.esc_url($delicious).'" target="_blank" title="'.esc_html__( 'Delicious', 'chelsey-elements').'">Del</a></li>';
					}
					break;
				case 'rss':
				    if($rss != "") {
				      $out .= '<li class="social-rss"><a href="'.esc_url($rss).'" target="_blank" title="'.esc_html__( 'RSS', 'chelsey-elements').'">Rss</a></li>';
				    }
				    break;
				default:
				# code...
				break;
			}
		}
		$out .= '</ul></div>';
        return $out;
	}
	add_shortcode('chelseysocials', 'ChelseySocials');
}
if(!function_exists('ChelseyInstagramPost')){
	function ChelseyInstagramPost($atts, $content = null) {
		extract( shortcode_atts( array(
	        'media_url' => ''
        ), $atts ) );
        $api = wp_remote_get("http://api.instagram.com/oembed?url=".$media_url);   
		$apiObj = json_decode($api['body'],true);
		if ( !isset($apiObj['author_name']) ) {
	        // error handling
	        $out = esc_html__("Something went wrong: please, check your media url", 'chelsey-elements');

	    } else {
	    	$author_name = $apiObj['author_name'];
			$author_url = $apiObj['author_url'];
			$matches = explode('/p/', $media_url); 
			$matches = explode('/', $matches[1]);
			$media_id = $matches[0]; 
			if(strlen($media_id) < 9 ) {
				$media_id = 'BN6ni5KA7sj';
			}
	        $out = '<div class="instagram-item-post">
					<a href="'.esc_attr($media_url).'" target="_blank">
						<figure class="image instagram-image">
							<img src="https://instagram.com/p/'.esc_attr($media_id).'/media/?size=l">
						</figure>
					</a>
					<div class="instagram-meta">
						<div class="instagram-logo">
							<a href="'.esc_url($author_url).'" target="_blank">
								<i class="fa fa-instagram"></i>
								<span class="name">@'.$author_name.'</span>
							</a>
						</div>
						<a href="'.esc_attr($media_url).'" target="_blank">
						<div class="instagram-stats">
							<i class="fa fa-heart"></i>
						</div>
						</a>
					</div>
				</div>';
	    }
		return $out;
	}
	add_shortcode('chelseyinstapost', 'ChelseyInstagramPost');
}
if(!function_exists('ChelseyGoogleMap')){
	function ChelseyGoogleMap($atts, $content = null) {
		extract( shortcode_atts( array(
	        'address' => 'Ontario, CA, USA',
	        'style' => 'style1',
	        'marker_icon' => '',
	        'map_height' => ''
        ), $atts ) );
        $out = '';
        if($address == ''){
        	return;
        }
        if($marker_icon != ''){
        	$marker_icon = wp_get_attachment_image_url($marker_icon, 'full');
        	$icon = 'icon:"'.esc_url($marker_icon).'",';
        } else {
        	$icon = '';
        }
        switch ($style) {
        	case 'style2':
        		$style_data = '[{"featureType":"water","elementType":"geometry","stylers":[{"color":"#e9e9e9"},{"lightness":17}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":20}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#ffffff"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#ffffff"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":18}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":16}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":21}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#dedede"},{"lightness":21}]},{"elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#ffffff"},{"lightness":16}]},{"elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#333333"},{"lightness":40}]},{"elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#f2f2f2"},{"lightness":19}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#fefefe"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#fefefe"},{"lightness":17},{"weight":1.2}]}]';
        		break;
        	case 'style3':
        		$style_data = '[{"featureType":"administrative","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"visibility":"on"}]},{"featureType":"administrative","elementType":"labels","stylers":[{"visibility":"on"},{"color":"#716464"},{"weight":"0.01"}]},{"featureType":"administrative.country","elementType":"labels","stylers":[{"visibility":"on"}]},{"featureType":"landscape","elementType":"all","stylers":[{"visibility":"simplified"}]},{"featureType":"landscape.natural","elementType":"geometry","stylers":[{"visibility":"simplified"}]},{"featureType":"landscape.natural.landcover","elementType":"geometry","stylers":[{"visibility":"simplified"}]},{"featureType":"poi","elementType":"all","stylers":[{"visibility":"simplified"}]},{"featureType":"poi","elementType":"geometry.fill","stylers":[{"visibility":"simplified"}]},{"featureType":"poi","elementType":"geometry.stroke","stylers":[{"visibility":"simplified"}]},{"featureType":"poi","elementType":"labels.text","stylers":[{"visibility":"simplified"}]},{"featureType":"poi","elementType":"labels.text.fill","stylers":[{"visibility":"simplified"}]},{"featureType":"poi","elementType":"labels.text.stroke","stylers":[{"visibility":"simplified"}]},{"featureType":"poi.attraction","elementType":"geometry","stylers":[{"visibility":"on"}]},{"featureType":"road","elementType":"all","stylers":[{"visibility":"on"}]},{"featureType":"road.highway","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"road.highway","elementType":"geometry","stylers":[{"visibility":"on"}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"visibility":"on"}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"visibility":"simplified"},{"color":"#a05519"},{"saturation":"-13"}]},{"featureType":"road.local","elementType":"all","stylers":[{"visibility":"on"}]},{"featureType":"transit","elementType":"all","stylers":[{"visibility":"simplified"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"visibility":"simplified"}]},{"featureType":"transit.station","elementType":"geometry","stylers":[{"visibility":"on"}]},{"featureType":"water","elementType":"all","stylers":[{"visibility":"simplified"},{"color":"#84afa3"},{"lightness":52}]},{"featureType":"water","elementType":"geometry","stylers":[{"visibility":"on"}]},{"featureType":"water","elementType":"geometry.fill","stylers":[{"visibility":"on"}]}]';
        		break;
        	default:
        		$style_data = '[{"featureType":"administrative","elementType":"labels.text.fill","stylers":[{"color":"#444444"}]},{"featureType":"landscape","elementType":"all","stylers":[{"color":"#f2f2f2"}]},{"featureType":"poi","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"all","stylers":[{"saturation":-100},{"lightness":45}]},{"featureType":"road.highway","elementType":"all","stylers":[{"visibility":"simplified"}]},{"featureType":"road.arterial","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"all","stylers":[{"color":"#46bcec"},{"visibility":"on"}]}]';
        		break;
        }
        $out .= '<div class="map-container"><div id="map" style="height:'.$map_height.'"></div></div>';
        $out .= '<script type="text/javascript">
			var map;
			function initMap() {
			  var styles = '.$style_data.';
			  map = new google.maps.Map(document.getElementById(\'map\'), {
			    center: {
			    	lat: -34.397, 
			    	lng: 150.644
			    },
			    zoom: 10,
			    navigationControl:!1,
			    mapTypeControl:!1,
			    scaleControl:!1,
			    streetViewControl:!1,
			  });
			  map.setOptions({styles: styles});
				var address = "'.$address.'";
				var geocoder = new google.maps.Geocoder();
				geocoder.geocode({
				  \'address\': address
				}, 
				function(results, status) {
				  if(status == google.maps.GeocoderStatus.OK) {
				     new google.maps.Marker({
				        position: results[0].geometry.location,
				        '.$icon.'
				        map: map
				     });
				     map.setCenter(results[0].geometry.location);
				  }
				});
			}
    	</script>
    	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC9WKQKuRSRfuUFo8olfNjo012aX_n4CBs&libraries=places,geometry&callback=initMap&v=3.31"></script>';

		return $out;
	}
	add_shortcode('chelseygooglemap', 'ChelseyGoogleMap');
}

add_filter( 'widget_text', 'shortcode_unautop', 7);
add_filter( 'widget_text', 'do_shortcode', 7);
add_filter( 'the_content', 'do_shortcode', 120);

// Remove Empty Paragraphs
add_filter("the_content", "the_content_filter");
function the_content_filter($content) {
	// array of custom shortcodes requiring the fix 
	$block = join("|", array('post_slider'));
	$array = array(
		'<p>[' => '[', 
		']</p>' => ']', 
		']<br />' => ']',
		']<br>' => ']',	
		'<br>[' => '[',
		'<p></p>' => '',
		'<p><script' => '<script',
		'<p><style' => '<style',
		'</style></p>' => '</style>',
		'</script><br />' => '</script>',
		'</script></p>' => '</script>'
	);
	$content = strtr($content, $array);
	// opening tag
	$rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]", $content); 
	// closing tag
	$rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]", $rep);
	return $rep;
}
?>