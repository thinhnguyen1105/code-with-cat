<?php

class widget_instagram extends WP_Widget { 
	
	// Widget Settings
	public function __construct() {
		$widget_ops = array('description' => __('Display your latest Instagram Photos', 'frgn-extension') );
		$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'instagram' );
		parent::__construct( 'instagram', __('Chelsey Instagram', 'frgn-extension'), $widget_ops, $control_ops );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance) {		
		extract( $args );
		$title = apply_filters('widget_title', $instance['title']);
		$accessToken = apply_filters('access_token', $instance['access_token']);
		$pics = apply_filters('pics', $instance['pics']);
		$pics_per_row = apply_filters('pics_per_row', $instance['pics_per_row']);
		$hide_items = $instance['hide_items'];
		$hide_link = $instance['hide_link'];
		$suf = rand(1,999);
		$row_class='';	
		echo ''.$before_widget; 
		if ( $title !='' )	echo ''.$before_title . $title . $after_title;
		//check if cache needs update
		$instagram_last_cache_time = get_option('louie_instagram_last_cache_time'.$accessToken);
		$instagram_last_picstoshow = get_option('louie_instagram_last_picstoshow'.$accessToken);
		$diff_items = $pics != $instagram_last_picstoshow ? true : false;
		$diff = time() - $instagram_last_cache_time;
		$crt = 3600;
		switch ($pics_per_row) {
        	case '1':
        		$row_class='col-sm-12';
        		break;
        	case '2':
        		$row_class='col-sm-6';
        		break;
        	case '4':
        		$row_class='col-sm-3';
        		break;
        	case '6':
        		$row_class='col-sm-2';
        		break;
        	default:
        		$row_class='col-sm-4';
        		break;
        }
		if($diff >= $crt || empty($instagram_last_cache_time) || $diff_items){
		    // get remote data
		    $result = wp_remote_get( "https://api.instagram.com/v1/users/self/media/recent/?access_token={$accessToken}&count={$pics}" );
		    if(is_array($result) && !empty($result['body'])){
		    	$result = json_decode( $result['body'] );
			    if ( is_wp_error( $result ) ) {
			        // error handling
			        $error_message = $result->get_error_message();
			        echo "Something went wrong: ".$error_message;

			    } elseif( isset($result->meta->error_message) ) {
			    	echo "Something went wrong: ".$result->meta->error_message;

			    } else {
			        // processing further
			        $main_data = array();
			        //print_r($result);
			        $username = '';
			        $n         = 0;
			        // get username and actual thumbnail
			        if( is_array($result->data) || is_object($result->data) ){
			        	foreach ( $result->data as $d ) {
				        	$username = $d->user->full_name;
				            $main_data[ $n ]['user']      = $d->user->full_name;
				            $main_data[ $n ]['user_url']   = '//instagram.com/'.$d->user->username;
				            $main_data[ $n ]['thumbnail'] = $d->images->low_resolution->url;
				            $main_data[ $n ]['full'] = $d->images->standard_resolution->url;
				            $main_data[ $n ]['caption'] = isset($d->caption->text) ? $d->caption->text : '';
				            $n++;
				        }
			        }
			    }
		    }
		    //save tweets to wp option 		
			update_option('louie_instagram_items'.$accessToken, serialize($main_data));							
			update_option('louie_instagram_last_cache_time'.$accessToken, time());
			update_option('louie_instagram_last_picstoshow'.$accessToken, $pics);
		}
		$frgn_instagram_items = maybe_unserialize(get_option('louie_instagram_items'.$accessToken));
		if(!empty($frgn_instagram_items) && is_array($frgn_instagram_items)){
			// create main string, pictures embedded in links
		        $items = '<div class="instagram-items">';
		        foreach ( $frgn_instagram_items as $data ) {
		        	$username = $data['user'];
		        	$user_url = $data['user_url'];
		            $items .= '<div class="'.$row_class.' instagram-item"><a href="'.esc_url($data['full']).'" data-lightbox="lightbox-insta" data-caption="'.esc_attr($data['caption']).'"><img src="'.esc_url($data['thumbnail']).'" alt="'.esc_attr($data['user']).' pictures"></a></div>';
		        }
		        $items .= '</div>';
		    if(!$hide_items){
		    	echo $items;
		    }
		    if(!$hide_link){
	        	echo '<a class="insta-follow-link" href="'.$user_url.'"><span class="icon-insta"><i class="fa fa-instagram"></i></span>'.esc_html__('Follow', 'frgn-extension-elements').' '.$username.' '.esc_html__('instagram', 'frgn-extension-elements').'</a>';
		    }
			echo '<div class="insta-follow-link-sidebar"><a href="'.$user_url.'"><i class="fab fa-instagram"></i></a></div>';
		}
		echo ''.$after_widget; 
	}
	// Update
	function update( $new_instance, $old_instance ) {  
		$instance = $old_instance; 
		
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['access_token'] = strip_tags( $new_instance['access_token'] );
		$instance['pics'] = strip_tags( $new_instance['pics'] );
		$instance['pics_per_row'] = strip_tags( $new_instance['pics_per_row'] );
		$instance['hide_items'] = $new_instance['hide_items'];
		$instance['hide_link'] = $new_instance['hide_link'];
		if($old_instance['access_token'] != $new_instance['access_token']){
			delete_option('louie_instagram_last_cache_time'.$old_instance['access_token']);
		}
		return $instance;
	}
	
	// Backend Form
	function form($instance) {
		
		$defaults = array( 'title' => 'Instagram Widget', 'pics' => '4', 'access_token' => '', 'pics_per_row' => '2', 'hide_link' => '', 'hide_items' => '' ); // Default Values
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>
        
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>">Widget Title:</label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" value="<?php echo esc_attr($instance['title']); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'access_token' )); ?>">Access Token:</label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'access_token' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'access_token' )); ?>" value="<?php echo esc_attr($instance['access_token']); ?>" /><br /><a target="_blank" href="https://instagram.com/oauth/authorize/?client_id=1677ed07ddd54db0a70f14f9b1435579&redirect_uri=http://instagram.pixelunion.net&response_type=token"><?php _e('Get your Access Token','frgn-extension'); ?></a>
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'pics' )); ?>">Number of Items:</label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id( 'pics' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'pics' )); ?>" value="<?php echo esc_attr($instance['pics']); ?>" />
		</p>
		<p>
		<?php 
			$selected2 = '';
			$selected3 = '';
			$selected4 = '';
			$selected5 = '';
			$selected6 = '';
			if(isset($instance['pics_per_row'])){
				switch ($instance['pics_per_row']) {
					case '1':
						$selected6 = 'selected="selected"';
						break;
					case '2':
						$selected2 = 'selected="selected"';
						break;
					case '3':
						$selected3 = 'selected="selected"';
						break;
					case '4':
						$selected4 = 'selected="selected"';
						break;
					case '6':
						$selected5 = 'selected="selected"';
						break;
				}
			} ?>
			<label for="<?php echo esc_attr($this->get_field_id( 'pics_per_row' )); ?>">Number of Items:</label>
			<select class="widefat" id="<?php echo esc_attr($this->get_field_id( 'pics_per_row' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'pics_per_row' )); ?>">
				<option value="1" <?php echo esc_attr($selected6); ?>>One item per row</option>
				<option value="2" <?php echo esc_attr($selected2); ?>>Two items per row</option>
				<option value="3" <?php echo esc_attr($selected3); ?>>Three items per row</option>
				<option value="4" <?php echo esc_attr($selected4); ?>>Four items per row</option>
				<option value="6" <?php echo esc_attr($selected5); ?>>Six items per row</option>
			</select>
		</p>
    <?php }
}

// Add Widget
function widget_instagram_init() {
	register_widget('widget_instagram');
}
add_action('widgets_init', 'widget_instagram_init');

?>