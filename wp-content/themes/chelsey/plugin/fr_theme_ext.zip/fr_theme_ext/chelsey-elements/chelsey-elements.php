<?php
add_action( 'plugins_loaded', 'chelsey_plugin_load_textdomain' );
/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 */
function chelsey_plugin_load_textdomain() {
  load_plugin_textdomain( 'chelsey-elements', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}

$dir = plugin_dir_path( __FILE__ );
define( 'CHELSEY_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );

include_once ( trailingslashit( $dir ).'inc/shortcodes.php' );

/* Include Meta Box Script */
include_once(trailingslashit( $dir ).'inc/meta-boxes.php');
if(class_exists('WPBakeryVisualComposerAbstract')) {
	include_once( trailingslashit( $dir ).'inc/vc-shortcodes.php');
}

function chelsey_shortcodes_scripts() {  
	//wp_register_script('owl-carousel', CHELSEY_PLUGIN_URL . 'js/owl.carousel.min.js', array('jquery'), '2.3.4', true);
	wp_register_script('isotope', CHELSEY_PLUGIN_URL . 'js/isotope.min.js', array('jquery'), '3.0.0', true);
	wp_register_script('infinite-scroll', CHELSEY_PLUGIN_URL . 'js/infinite-scroll.pkgd.min.js', array('jquery'), '3.0.0', true);
	wp_register_script('mousewheel', CHELSEY_PLUGIN_URL . 'js/mousewheel.min.js', array('jquery'), '3.0.0', true);
	wp_register_script('hoverdir', CHELSEY_PLUGIN_URL . 'js/jquery.hoverdir.js', array('jquery'), '1.1.0', true);
}
add_action( 'wp_enqueue_scripts', 'chelsey_shortcodes_scripts' );
function chelsey_shortcodes_styles() {  
	//wp_register_style( 'owl-carousel', CHELSEY_PLUGIN_URL . 'css/owl.carousel.css', array(), '2.3.4', 'all' );
	wp_register_style( 'hoverdir-css', CHELSEY_PLUGIN_URL . 'css/hoverdir.css', array(), '1.0.0', 'all' );
}
add_action( 'wp_enqueue_scripts', 'chelsey_shortcodes_styles', 5);

if(!function_exists('rwmb_meta')){
	function rwmb_meta($key) {
		return get_post_meta(get_the_ID(), $key);
	}
}

if(!function_exists('ChelseySharebox')){
	function ChelseySharebox($postID, $echo = false){
		if($postID != ''){
			$permalink = esc_url(get_permalink($postID));
			$title = esc_attr(get_the_title($postID));
			$description = esc_attr(get_the_title($postID));
		} else if(is_front_page()){
			$permalink = esc_url(home_url());
			$title = esc_attr(get_bloginfo('name'));
			$description = esc_attr(get_bloginfo('description'));
		} else {
			$permalink = esc_url(get_permalink($postID));
			$title = esc_attr(get_the_title($postID));
			$description = esc_attr(get_the_title($postID));
		}

		$out = '<div class="sharebox">';
			$out .= '<div class="social-icons">';
				$out .= '<ul class="unstyled">';
					if( get_theme_mod('chelsey_sharing_facebook',true) ) $out .= '<li class="social-facebook"><a href="//www.facebook.com/sharer.php?u='.esc_url($permalink).'&amp;t='.str_replace(' ', '+', $title).'" title="'.esc_html__( 'Share to Facebook', 'chelsey-elements').'" target="_blank">Fb</a></li>';
					if( get_theme_mod('chelsey_sharing_twitter',true) ) $out .= '<li class="social-twitter"><a href="//twitter.com/home?status='.str_replace(' ', '+', $title).'+'.esc_url($permalink).'" title="'.esc_html__( 'Share to Twitter', 'chelsey-elements').'" target="_blank">Tw</a></li>';	
					if( get_theme_mod('chelsey_sharing_pinterest',true) ) $out .= '<li class="social-pinterest"><a href="//pinterest.com/pin/create/link/?url='.esc_url($permalink).'&amp;media='.wp_get_attachment_url( get_post_thumbnail_id($postID) ).'&amp;description='.str_replace(" ", "+", $description).'" title="'.esc_html__( 'Share to Pinterest', 'chelsey-elements').'" target="_blank">Pin</a></li>';
					if( get_theme_mod('chelsey_sharing_linkedin',false) ) $out .= '<li class="social-linkedin"><a href="http://linkedin.com/shareArticle?mini=true&amp;url='.esc_url($permalink).'&amp;title='.str_replace(' ', '+', $title).'" title="'.esc_html__( 'Share to LinkedIn', 'chelsey').'" target="_blank">Lin</a></li>';
					if( get_theme_mod('chelsey_sharing_googleplus',false) ) $out .= '<li class="social-googleplus"><a href="http://plus.google.com/share?url='.esc_url($permalink).'&amp;title='.str_replace(' ', '+', $title).'" title="'.esc_html__( 'Share To Google+', 'chelsey').'" target="_blank">G+</a></li>';
					if( get_theme_mod('chelsey_sharing_email',false) ) $out .= '<li class="social-email"><a href="mailto:?subject='.str_replace(' ', '+', $title).'&amp;body='.esc_url($permalink).'" title="'.esc_html__( 'Share with E-Mail', 'chelsey').'" target="_blank"><i class="fa fa-envelope"></i></a></li>';
				$out .= '</ul>';
			$out .= '</div>';
		$out .= '</div>';
		if($echo){
			echo $out;
		} else {
			return $out;
		}
	}
}
if(!function_exists('chelsey_get_the_content')){
	function chelsey_get_the_content() {
		$content = get_the_content();
		$content = apply_filters('the_content', $content);
		$content = str_replace(']]>', ']]&gt;', $content);
		return $content;
	}
}
if(!function_exists('chelsey_post_has_more_link')){
	function chelsey_post_has_more_link( $post_id ) {
		$post = get_post( $post_id );
		$content = $post->post_content;
		$data_array = get_extended( $content );
		return '' !== $data_array['extended'];
	}
}
add_action('admin_head', 'chelsey_custom_fonts');
function chelsey_custom_fonts() {
  $chelsey_icon_style = '.chelsey-element-icon {
      width:32px;
      height:32px;
      line-height:32px !important;
      border-radius:4px;
      background-image:none !important;
      background-color:#2b2735;
      color:#ffffff;
      font-size:22px !important;
      text-align:center;
    }';
  wp_add_inline_style('js_composer', $chelsey_icon_style);
}
if(!function_exists('ChelseyExcerpt')){
	function ChelseyExcerpt($limit) {
		$excerpt = explode(' ', get_the_excerpt(), $limit);
		if (count($excerpt)>=$limit) {
			array_pop($excerpt);
			$excerpt = implode(" ",$excerpt);
		} else {
			$excerpt = implode(" ",$excerpt);
		} 
		$excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
		return $excerpt;
	}
}
?>